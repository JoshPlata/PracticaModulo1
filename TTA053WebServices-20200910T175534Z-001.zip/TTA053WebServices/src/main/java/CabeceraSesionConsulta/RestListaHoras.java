
package CabeceraSesionConsulta;

import java.util.Date;
import java.util.List;

public class RestListaHoras {
    
    private List<Date> horasDisponible;

    public List<Date> getHorasDisponible() {
        return horasDisponible;
    }

    public void setHorasDisponible(List<Date> horasDisponible) {
        this.horasDisponible = horasDisponible;
    }
    
    
}
