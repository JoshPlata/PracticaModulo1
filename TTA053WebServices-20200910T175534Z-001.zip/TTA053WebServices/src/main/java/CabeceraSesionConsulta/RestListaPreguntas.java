
package CabeceraSesionConsulta;

import Entidades.Pregunta;
import java.util.List;

public class RestListaPreguntas {
    
    private List<Pregunta> listaPreguntas;

    public List<Pregunta> getListaPreguntas() {
        return listaPreguntas;
    }

    public void setListaPreguntas(List<Pregunta> listaPreguntas) {
        this.listaPreguntas = listaPreguntas;
    }
    
}
