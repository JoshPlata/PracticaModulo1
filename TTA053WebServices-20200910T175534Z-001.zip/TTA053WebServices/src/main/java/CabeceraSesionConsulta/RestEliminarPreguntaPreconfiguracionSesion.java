
package CabeceraSesionConsulta;

import java.util.List;

public class RestEliminarPreguntaPreconfiguracionSesion {
    
    private List<String> listPregunta;
    private String idSesionConsulta;

    public List<String> getListPregunta() {
        return listPregunta;
    }

    public void setListPregunta(List<String> listPregunta) {
        this.listPregunta = listPregunta;
    }

    public String getIdSesionConsulta() {
        return idSesionConsulta;
    }

    public void setIdSesionConsulta(String idSesionConsulta) {
        this.idSesionConsulta = idSesionConsulta;
    }
    
}
