
package CabeceraSesionConsulta;

import CabecerasSesion.CabeceraHistorial;

public class RestCabeceraSesionConsulta {

private CabeceraHistorial cabeceraHistorial;    

    public CabeceraHistorial getCabeceraHistorial() {
        return cabeceraHistorial;
    }

    public void setCabeceraHistorial(CabeceraHistorial cabeceraHistorial) {
        this.cabeceraHistorial = cabeceraHistorial;
    }
}
