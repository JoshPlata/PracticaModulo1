
package CabeceraSesionConsulta;

import Entidades.Monitoreo;
import java.util.List;

public class RestListaMonitoreos {
    
    private List<Monitoreo> preguntaMonitoreo;

    public List<Monitoreo> getPreguntaMonitoreo() {
        return preguntaMonitoreo;
    }

    public void setPreguntaMonitoreo(List<Monitoreo> preguntaMonitoreo) {
        this.preguntaMonitoreo = preguntaMonitoreo;
    }
    
}
