
package CabeceraSesionConsulta;

import Entidades.SesionConsulta;
import java.util.List;

public class RestListaSesionesConsulta {
    
    private List<SesionConsulta> listaSesionConsulta;

    public List<SesionConsulta> getListaSesionConsulta() {
        return listaSesionConsulta;
    }

    public void setListaSesionConsulta(List<SesionConsulta> listaSesionConsulta) {
        this.listaSesionConsulta = listaSesionConsulta;
    }
    
}
