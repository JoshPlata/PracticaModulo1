package com.tta053.ws.rest.usuario;

import Cabeceras.CabeceraUsuario;
import Entidades.GenUsuario;
import Procesos.RN.Usuario.ProcesoRNSesionUsuario;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WSSesion {//,{idAplicaion},{idRol},{contrasena}
      @RequestMapping(value = "/Sesion/InicioSesion/{correo},{contrasena}", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)//, method = RequestMethod.GET
      public int inicioSesion(@PathVariable("correo")String correo,@PathVariable("contrasena")String contrasena)
        {
          try{
              
               ProcesoRNSesionUsuario iniSesion=new ProcesoRNSesionUsuario();
               //correo,contrasena,idAplicacion,idRol
               return iniSesion.iniciarSesion(correo,contrasena,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000001");
          }catch(Exception ex)
          {
              ex.getMessage();
              ex.getStackTrace();
              return 1000;
          }
          //return 1;

	}
      @RequestMapping(value = "/Sesion/Prueba/", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
      public void prueba(@RequestBody GenUsuario usuario)
      {
          System.out.println(usuario.getApp());
      }
      
      
      @RequestMapping(value = "/Sesion/ObtenerCabecera/'{correo}'", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
      public CabeceraUsuario ObtenerCabecera(@PathVariable("correo")String correo)
      {
          try{
              ProcesoRNSesionUsuario iniSesion=new ProcesoRNSesionUsuario();
              return iniSesion.ObtenerCabecera(correo);
          }catch(Exception ex)
          {
              ex.printStackTrace();
              return new CabeceraUsuario();//null;
          }
      }

      @RequestMapping(value="/Sesion/CerrarSesion/'{idCuenta}'",method =RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
      public int cerrarSesion(@PathVariable("idCuenta")String idCuenta)
      {
          
            ProcesoRNSesionUsuario pU =new ProcesoRNSesionUsuario();
          try{
          
              pU.cerrarSesion(idCuenta);
              return 1;
          }catch(Exception he)
          {
              return 0;
          }
      } 
      ///Sesion/RecuperarContrasena/NuevaContrasena/{idCuenta}
      @RequestMapping(value="/Sesion/GenerarCodigo/RecuperarContrasena/'{correo}'",method =RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
      public void GenerarCodigoRecuperacionContrasena(@PathVariable("correo")String correo)
      {
          try{
          ProcesoRNSesionUsuario pRNUsuario=new ProcesoRNSesionUsuario();
          boolean estado=pRNUsuario.genRecuperarContrasena(correo);
          
          }catch(Exception ex)
          {
              ex.getStackTrace();
          }
      }
      @RequestMapping(value="/prueba/{texto}",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
      public GenUsuario prueba(@PathVariable("texto")String texto )
      {
          System.out.println("Valor:"+texto.length());
          System.out.println("Valor:"+texto);
          
          boolean h="hola".equals(texto);
          if(texto.equals("hola"))
          {
              return new GenUsuario();
          }
          else
          {
              GenUsuario usuario=new GenUsuario();
              usuario.setNombre("Bere");
              
              return usuario;
          }
          
      }
              
      @RequestMapping(value="/Sesion/ModificarUsuario/", method= RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
      public boolean modificarUsuario(@RequestBody GenUsuario usuario)
      {
          ProcesoRNSesionUsuario rn= new ProcesoRNSesionUsuario();
          
          if(usuario!=null)return rn.modificarUsuario(usuario);
          return false;
      }
      
      
}
