package com.tta053.ws.rest.Psicologo;

import CabeceraEspecialRest.CabeceraHistorialString;
import CabeceraEspecialRest.CabeceraSesionConsultaString;
import CabeceraEspecialRest.PreguntaString;
import CabeceraEspecialRest.RestCabeceraSesionConsultaString;
import CabeceraEspecialRest.SesionConsultaString;
import CabeceraSesionConsulta.RestEliminarPreguntaPreconfiguracionSesion;
import CabeceraSesionConsulta.RestListaHoras;
import CabeceraSesionConsulta.RestListaMonitoreos;
import CabeceraSesionConsulta.RestListaPreguntas;
import CabeceraSesionConsulta.RestListaSesionesConsulta;
import CabeceraSesionConsulta.RestCabeceraSesionConsulta;
import CabecerasSesion.CabeceraHistorial;
import CabecerasSesion.CabeceraSesionConsulta;
import Entidades.Historial;
import Entidades.Monitoreo;
import Entidades.Pregunta;
import Entidades.SesionConsulta;
import Procesos.RN.SesionConsulta.CabeceraSesionConsultaRN;
import Procesos.RN.SesionConsulta.HistorialDiagnosticoRN;
import Procesos.RN.SesionConsulta.SesionConsultaRN;
import com.sun.javafx.scene.control.skin.VirtualFlow;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WSSesionConsulta {

    private CabeceraSesionConsultaRN rnCabeceraSesionConsulta = new CabeceraSesionConsultaRN();
    private CabeceraSesionConsultaRN rnCabeceraSesionConsultaString = new CabeceraSesionConsultaRN();
    private HistorialDiagnosticoRN rnHistorialDiagnostico = new HistorialDiagnosticoRN();
    private SesionConsultaRN rnSesionConsulta = new SesionConsultaRN();

    //Probado, creado en el Rest del movil
    @RequestMapping(value = "/Usuario/Psicologo/SesionConsulta/obtenerCabeceraSesionConsulta/{idPaciente}",
            method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public RestCabeceraSesionConsultaString obtenerCabeceraSesionConsulta(@PathVariable("idPaciente") String idPaciente) {

            return mapeoRestCabeceraString(idPaciente);
    }

    //SinProbar, creado en el Rest del movil
    @RequestMapping(value = "/Usuario/Psicologo/SesionConsulta/agregarDiagnosticoEnHistorial/{diagnostico},{resumenDiagnostico},{idPaciente}",
            method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean agregarDiagnosticoEnHistorial(@PathVariable("diagnostico") String diagnostico,
            @PathVariable("resumenDiagnostico") String resumenDiagnostico, @PathVariable("idPaciente") String idPaciente) {

        return rnHistorialDiagnostico.AgregarDiagnosticoEnHistorial(diagnostico, resumenDiagnostico, idPaciente);

    }

    //Probado
    @RequestMapping(value = "/Usuario/Psicologo/SesionConsulta/obtenerHistorial/{idPaciente}",
            method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public Historial obtenerHistorial(@PathVariable("idPaciente") String idPaciente) {
        return rnHistorialDiagnostico.obtenerHistorial(idPaciente);
    }

    //Sin Probar, creado en el Rest del movil
    @RequestMapping(value = "/Usuario/Psicologo/SesionConsulta/crearSesionConsulta/",
            method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean crearSesionConsulta(@RequestBody SesionConsulta sesionConsulta) {

        return rnSesionConsulta.crearSesionConsulta(sesionConsulta);
    }

    //Sin Probar, creado en el Rest del movil
    //Se ejecutará sólo para cambiar status de la sesión , objetivo cumplido , análisis , tiempo y descrición
    //De la sesión que se tuvo con el paciente
    @RequestMapping(value = "/Usuario/Psicologo/SesionConsulta/modificarSesionConsulta/",
            method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean modificarSesionConsulta(@RequestBody SesionConsulta sesionConsulta) {
        return rnSesionConsulta.modificarSesionConsulta(sesionConsulta);
    }
    
    //Probado, creado en el Rest del movil
    @RequestMapping(value = "/Usuario/Psicologo/SesionConsulta/eliminarSesionConsulta/{idSesionConsulta}",
            method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean eliminarSesionConsulta(@PathVariable("idSesionConsulta") String idSesionConsulta) {
        return rnSesionConsulta.eliminarSesionConsulta(idSesionConsulta);
    }
    
    //Probado pero falta validar que si pueda ver las horas, creado en el Rest del movil
    @RequestMapping(value = "/Usuario/Psicologo/SesionConsulta/validarHoraCitaSesion/{idPsicologo},{fecha}",
            method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public RestListaHoras validarHoraCitaSesion(@PathVariable("idPsicologo") String idPsicologo,
            @PathVariable("fecha") String fecha) throws ParseException {
        RestListaHoras listaHoras = new RestListaHoras();
        listaHoras.setHorasDisponible(rnSesionConsulta.validarHoraCitaSesion(idPsicologo, fecha));
        return listaHoras;
    }

    //Probado, creado en el Rest del movil
    @RequestMapping(value = "/Usuario/Psicologo/SesionConsulta/obtenerCitasPorPaciente/{idPaciente}",
            method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public RestListaSesionesConsulta obtenerCitasPorPaciente(@PathVariable("idPaciente") String idPaciente) {
        RestListaSesionesConsulta listaSesionesConsulta = new RestListaSesionesConsulta();
        listaSesionesConsulta.setListaSesionConsulta(rnSesionConsulta.obtenerCitasPorPaciente(idPaciente));
        return listaSesionesConsulta;
    }

    //Probado???, creado en el Rest del movil
    @RequestMapping(value = "/Usuario/Psicologo/SesionConsulta/iniciarPreconfiguracionSesion/",
            method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean iniciarPreconfiguracionSesion(@RequestBody RestListaPreguntas listaPreguntas) {
        return rnSesionConsulta.iniciarPreconfiguracionSesion(listaPreguntas.getListaPreguntas());
    }

    //Probado???, creado en el Rest del movil
    @RequestMapping(value = "/Usuario/Psicologo/SesionConsulta/modificarPreconfiguracionSesion/",
            method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean modificarPreconfiguracionSesion(@RequestBody RestListaPreguntas listaPreguntas) {
        return rnSesionConsulta.modificarPreconfiguracionSesion(listaPreguntas.getListaPreguntas());
    }

    //Probado, creado en el Rest del movil
    @RequestMapping(value = "/Usuario/Psicologo/SesionConsulta/elimarPreguntasPreconfiguracionSesion/",
            method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean elimarPreguntasPreconfiguracionSesion(@RequestBody RestEliminarPreguntaPreconfiguracionSesion eliminarPreguntaPreconfiguracionSesion) {
        return rnSesionConsulta.elimarPreguntasPreconfiguracionSesion(eliminarPreguntaPreconfiguracionSesion.getListPregunta(),
                eliminarPreguntaPreconfiguracionSesion.getIdSesionConsulta());
    }

    //Probado???, creado en el Rest del movil
    @RequestMapping(value = "/Usuario/Psicologo/SesionConsulta/listaPreguntasPreconfiguracionSesion/{idSesionConsulta}",
            method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public RestListaPreguntas listaPreguntasPreconfiguracionSesion(@PathVariable("idSesionConsulta") String idSesionConsulta) {
        RestListaPreguntas listaPreguntas = new RestListaPreguntas();
        listaPreguntas.setListaPreguntas(rnSesionConsulta.listaPreguntasPreconfiguracionSesion(idSesionConsulta));
        return listaPreguntas;
    }

    //Probado???, creado en el Rest del movil
    @RequestMapping(value = "/Usuario/Psicologo/SesionConsulta/crearMonitoreo/",
            method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean crearMonitoreo(@RequestBody RestListaMonitoreos listaMonitoreos) {
        return rnSesionConsulta.crearMonitoreo(listaMonitoreos.getPreguntaMonitoreo());
    }

    //Probado???, creado en el Rest del movil
    @RequestMapping(value = "/Usuario/Psicologo/SesionConsulta/listarMonitoreos/",
            method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public RestListaMonitoreos listarMonitoreos(@RequestBody RestListaPreguntas listaPreguntas) {
        RestListaMonitoreos listaMonitoreos = new RestListaMonitoreos();
        listaMonitoreos.setPreguntaMonitoreo(rnSesionConsulta.listarMonitoreos(listaPreguntas.getListaPreguntas()));
        return listaMonitoreos;
    }

    public RestCabeceraSesionConsultaString mapeoRestCabeceraString(String idPaciente) {

        RestCabeceraSesionConsultaString rcscs = new RestCabeceraSesionConsultaString();
        CabeceraHistorial cabeceraHistorial = rnCabeceraSesionConsulta.obtenerCabeceraSesionConsulta(idPaciente);
        CabeceraHistorialString cabeceraHistorialString = new CabeceraHistorialString();
        if (cabeceraHistorial != null) {
            List<CabeceraSesionConsulta> cabeceraSesiones = cabeceraHistorial.getListaCabeceraSesiones();
            if (cabeceraSesiones != null && cabeceraSesiones.size() > 0) {
                List<CabeceraSesionConsultaString> listcscs = new ArrayList<>();

                for (CabeceraSesionConsulta ex : cabeceraSesiones) {

                    CabeceraSesionConsultaString cscs = new CabeceraSesionConsultaString();
                    List<Pregunta> listaPregunta = ex.getListaPregunta();
                        List<PreguntaString> listaPreguntaString = new ArrayList<PreguntaString>();

                        SesionConsultaString sesionConsultaString = new SesionConsultaString();
                        sesionConsultaString.setDescripcion(ex.getSesionConsulta().getDescripcion());
                        sesionConsultaString.setFecha(ex.getSesionConsulta().getFecha());
                        sesionConsultaString.setHistorial(ex.getSesionConsulta().getHistorial());
                        sesionConsultaString.setStatusSesion(ex.getSesionConsulta().getStatusSesion());
                        sesionConsultaString.setHora(String.valueOf(ex.getSesionConsulta().getHora()));
                        sesionConsultaString.setIdPacientefk(ex.getSesionConsulta().getIdPacientefk());
                        sesionConsultaString.setIdPsicologofk(ex.getSesionConsulta().getIdPsicologofk());
                        sesionConsultaString.setObjetivo(ex.getSesionConsulta().getObjetivo());
                        sesionConsultaString.setResumen(ex.getSesionConsulta().getResumen());
                        sesionConsultaString.setObjetivoCumplido(ex.getSesionConsulta().getObjetivoCumplido());
                        sesionConsultaString.setIdSesionConsulta(ex.getSesionConsulta().getIdSesionConsulta());
                        sesionConsultaString.setTiempo(String.valueOf(ex.getSesionConsulta().getTiempo()));

                        if(listaPregunta != null && listaPregunta.size() > 0){
                        for (Pregunta ax : listaPregunta) {

                            PreguntaString pregunta = new PreguntaString();

                            SesionConsultaString scs = new SesionConsultaString();
                            scs.setDescripcion(ax.getSesionConsulta().getDescripcion());
                            scs.setFecha(ax.getSesionConsulta().getFecha());
                            scs.setHistorial(ax.getSesionConsulta().getHistorial());
                            scs.setStatusSesion(ax.getSesionConsulta().getStatusSesion());
                            scs.setHora(String.valueOf(ax.getSesionConsulta().getHora()));
                            scs.setIdPacientefk(ax.getSesionConsulta().getIdPacientefk());
                            scs.setIdPsicologofk(ax.getSesionConsulta().getIdPsicologofk());
                            scs.setObjetivo(ax.getSesionConsulta().getObjetivo());
                            scs.setResumen(ax.getSesionConsulta().getResumen());
                            scs.setObjetivoCumplido(ax.getSesionConsulta().getObjetivoCumplido());
                            scs.setIdSesionConsulta(ax.getSesionConsulta().getIdSesionConsulta());
                            scs.setTiempo(String.valueOf(ax.getSesionConsulta().getTiempo()));

                            pregunta.setSesionConsulta(scs);
                            pregunta.setIdPregunta(ax.getIdPregunta());
                            pregunta.setNum(ax.getNum());
                            pregunta.setPregunta(ax.getPregunta());
                            pregunta.setTiempo(String.valueOf(ax.getTiempo()));
                            pregunta.setRespuestaPaciente(ax.getRespuestaPaciente());
                            pregunta.setAnalisis(ax.getAnalisis());

                            listaPreguntaString.add(pregunta);
                        }
                        
                        cscs.setListaPreguntaString(listaPreguntaString);
                        cscs.setListaMonitoreo(ex.getListaMonitoreo());
                        }
                        cscs.setSesionConsultaString(sesionConsultaString); 
                        listcscs.add(cscs);
                    
                }
              cabeceraHistorialString.setListaCabeceraSesionesString(listcscs);
            }
                
            cabeceraHistorialString.setHistorialPaciente(cabeceraHistorial.getHistorialPaciente());
            cabeceraHistorialString.setDiagnosticoPaciente(cabeceraHistorial.getDiagnosticoPaciente());

                if (cabeceraHistorialString != null) {
                    //La bandera tendra true si ya tiene un historial.
                    rcscs.setCabeceraHistorialString(cabeceraHistorialString);
                    rcscs.setBandera(true);
                }
            
        }
        if (cabeceraHistorialString == null) {
            //La bandera tendra false si no tiene historial.
            rcscs.setCabeceraHistorialString(cabeceraHistorialString);
            rcscs.setBandera(false);
        }
        return rcscs;
    }
    
    /*
    //Probado, creado en el Rest del movil
    @RequestMapping(value = "/Usuario/Psicologo/SesionConsulta/obtenerCitasPorPaciente/{idPaciente}",
            method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public RestListaSesionesConsulta obtenerCitasPorPaciente(@PathVariable("idPaciente") String idPaciente) {
        RestListaSesionesConsulta listaSesionesConsulta = new RestListaSesionesConsulta();
        listaSesionesConsulta.setListaSesionConsulta(rnSesionConsulta.obtenerCitasPorPaciente(idPaciente));
        return listaSesionesConsulta;
    }*/
}
