package com.tta053.ws;

import Procesos.RN.Usuario.ProcesoRNSesionUsuario;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ContrasenaController {

    @RequestMapping(value = "/Sesion/RecuperarContrasena/'{idContrasena}','{idCuenta}','{correo}'", method = RequestMethod.GET)
    public String verRecuperarContrasena(ModelMap map, @PathVariable("idContrasena") String idContrasena,
            @PathVariable("idCuenta") String idCuenta,@PathVariable("correo")String correo ){
        map.addAttribute("idCuenta", idCuenta);
        map.addAttribute("idContrasena", idContrasena);
        map.addAttribute("correo",correo);
        
        ProcesoRNSesionUsuario rnSesion = new ProcesoRNSesionUsuario();
        if (rnSesion.validaRecuperarContrasena(idCuenta, idContrasena,correo)) {

            return "recuperarContrasena";
        }

        return "Error_Generic";
    }

    @RequestMapping(value = "/Sesion/RecuperarContrasena/NuevaContrasena/'{idCuenta}','{correo}'", method = RequestMethod.POST)
    public String NuevaContrasena(@RequestParam("password1") String password1,
            @RequestParam("password2") String password2, @PathVariable("idCuenta") String idCuenta,
            @PathVariable("correo") String correo) {

        if (password1.equals(password2)) {
            try {
                ProcesoRNSesionUsuario proceso = new ProcesoRNSesionUsuario();
                if(proceso.ModificarContrasena(idCuenta,password1,correo))
                {
                return "ContraNuevaExito";
                }
                else
                {
                   return "Error_Generic";
                }
                
            } catch (Exception ex) {
                return "Error_Generic";
            }

        } else {
            return "Error_Generic";
        }

    }

    @RequestMapping(value="/Holiwi/perro",method = RequestMethod.GET)
    public @ResponseBody String holiwi()
    {
        return "<h1>Holiwi</h1>";
    }
}
