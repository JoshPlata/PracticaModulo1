package com.tta053.ws.rest.Paciente;

import EntidadesCabeceras.RestCabeceraDiarioPaciente;
import Procesos.RN.Paciente.Diario.ProcesoRNDiarioEstados;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.http.MediaType;
import static org.springframework.http.RequestEntity.method;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WSDiarioPaciente {

    @RequestMapping(value = "/Usuario/Paciente/Diario/AgregarEstado/'{idPaciente}','{estado}','{actividad}','{comentario}'",
            method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean agregarEstado(@PathVariable("idPaciente") String idPaciente,
             @PathVariable("estado") String estado, @PathVariable("actividad") String actividad,
             @PathVariable("comentario") String comentario) {
        boolean status = false;

        ProcesoRNDiarioEstados pR = new ProcesoRNDiarioEstados();
        status = pR.agregarDiarioPaciente(idPaciente, estado, actividad, comentario);

        return status;
    }

    @RequestMapping(value = "/Usuario/Paciente/Diario/ListaTodosEstados/'{idPaciente}'",
            method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public RestCabeceraDiarioPaciente listaEstadosPorId(@PathVariable("idPaciente") String idPaciente) {
        boolean status = false;
        RestCabeceraDiarioPaciente restCabecera=new RestCabeceraDiarioPaciente();
        ProcesoRNDiarioEstados pR = new ProcesoRNDiarioEstados();
        restCabecera.setCabeceraDiarioPaciente(pR.mostrarDiarioPaciente(idPaciente));

        return restCabecera;
    }

    @RequestMapping(value = "/Usuario/Paciente/Diario/ListaEstadosMes/'{idPaciente}','{mes}','{anio}'",
            method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public RestCabeceraDiarioPaciente listaEstadosPorMes(@PathVariable("idPaciente") String idPaciente,
            @PathVariable("mes") int mes, @PathVariable("anio") int anio) {
        boolean status = false;
       RestCabeceraDiarioPaciente restCabecera=new RestCabeceraDiarioPaciente();
       
        ProcesoRNDiarioEstados pR = new ProcesoRNDiarioEstados();
        restCabecera.setCabeceraDiarioPaciente(pR.mostrarDiarioPacienteMes(idPaciente, mes, anio));

        return restCabecera;
    }

    @RequestMapping(value = "/Usuario/Paciente/Diario/ListaEstadosRango/'{idPaciente}','{ini}','{fin}'",
            method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public RestCabeceraDiarioPaciente listaEstadosPorRango(@PathVariable("idPaciente") String idPaciente,
            @PathVariable("ini") String ini, @PathVariable("fin") String fin) {
        boolean status = false;
        RestCabeceraDiarioPaciente restCabecera=new RestCabeceraDiarioPaciente();
        
        try {

            
            ProcesoRNDiarioEstados pR = new ProcesoRNDiarioEstados();
            SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
            Date newIni = formatter.parse(ini);
            Date newFin = formatter.parse(fin);

            restCabecera.setCabeceraDiarioPaciente(pR.mostrarDiarioPacienteRango(idPaciente, newIni, newFin));

            return restCabecera;
        } catch (ParseException ex) {
            Logger.getLogger(WSDiarioPaciente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return restCabecera;
    }
}
