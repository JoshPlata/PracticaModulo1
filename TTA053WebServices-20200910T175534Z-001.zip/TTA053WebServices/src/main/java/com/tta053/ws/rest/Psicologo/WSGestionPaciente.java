package com.tta053.ws.rest.Psicologo;

import Cabeceras.CabeceraUsuario;
import Entidades.Paciente;
import Entidades.Tutor;
import EntidadesCabeceras.ListaPacientes;
import Models.PacienteAdd;
import Procesos.RN.Psicologo.ProcesoRNGestionPaciente;
import java.util.ArrayList;
import java.util.List;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class WSGestionPaciente {
    
@ResponseBody 
@RequestMapping(value="/Usuario/Psicologo/ObtenerPaciente/{idUsuario}",method=RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
public CabeceraUsuario obtenerPaciente(@PathVariable("idUsuario") String idUsuario)
{
    //ResponseEntity<CabeceraUsuario>
    CabeceraUsuario cabeceraPaciente=null;
    try
    {
        
        ProcesoRNGestionPaciente pGP=new ProcesoRNGestionPaciente();
        cabeceraPaciente=pGP.ObtenerCabeceraPaciente(idUsuario);
        
    }catch(Exception ex)
    {
    
        if(ex!=null);
    }
    finally{
        
        //return new ResponseEntity(cabeceraPaciente, HttpStatus.OK);
        return cabeceraPaciente;
    }
}

@RequestMapping(value="/Usuario/Psicologo/ObtenerPacientes/{idPsicologo}",method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
public ListaPacientes obtenerListaPacientes(@PathVariable("idPsicologo")String idPsicologo)
{
    List<CabeceraUsuario<Paciente>> listCabeceraPacientes=new ArrayList<CabeceraUsuario<Paciente>>();
    ListaPacientes lPacientes=new ListaPacientes();
   
    try{
        ProcesoRNGestionPaciente pGP=new ProcesoRNGestionPaciente();
        listCabeceraPacientes=pGP.ObtenerListaCabecerasPaciente(idPsicologo);
        lPacientes.setListaPacientes(listCabeceraPacientes);
    }catch(Exception ex)
    {
        
    }
    finally{
        
      return lPacientes;
    }
}

@RequestMapping(value="/Usuario/Psicologo/AgregarPaciente/",method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
public boolean agregarPaciente(@RequestBody PacienteAdd pacienteAdd)
{
    boolean estado=false;
    try{
        ProcesoRNGestionPaciente pGP=new ProcesoRNGestionPaciente();
        estado=pGP.AgregarPaciente(pacienteAdd.getUsuario(), pacienteAdd.getPsicologo(), pacienteAdd.getPaciente(),pacienteAdd.getTutor()); 
    }catch(Exception ex)
    {
        
    }finally
    {
        return estado;//new ResponseEntity(estado, HttpStatus.OK);
    }

}
@RequestMapping(value="/Usuario/Psicologo/ModificarPaciente/",method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
public boolean modificarPaciente(@RequestBody Paciente paciente)
{
    boolean estado=false;
    try{
        ProcesoRNGestionPaciente pGP=new ProcesoRNGestionPaciente();
        estado=pGP.ModificarPaciente(paciente);
    }catch(Exception e)
    {
    }
    finally{
        return estado;
    }
}
@RequestMapping(value="/Usuario/Psicologo/ModificarTutor/",method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
public boolean modificarTutor(@RequestBody Tutor tutor)
{
    boolean estado=false;
    try{
        ProcesoRNGestionPaciente pGP=new ProcesoRNGestionPaciente();
        pGP.ModificarInfoTutorPaciente(tutor);
        estado=true;
    }
    catch(Exception ex)
    {}
    finally
    {
        return estado;
    }

}
@RequestMapping(value="/Usuario/Psicologo/DesactivarPaciente/'{idUsuario}'",method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
public boolean desactivarPaciente(@PathVariable("idUsuario")String idUsuario)
{
    boolean estado=false;
    try{
        
        ProcesoRNGestionPaciente pGP=new ProcesoRNGestionPaciente();
        pGP.DesactivarPaciente(idUsuario);
        estado=true;
    }catch(Exception ex)
    {
    }finally
    {
        return estado;
      
    }
}
@RequestMapping(value="/Usuario/Psicologo/ActivarPaciente/'{idUsuario}'",method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
public boolean activarPaciente(@PathVariable("idUsuario")String idUsuario)
{   
    boolean estado=false;
    try{
        ProcesoRNGestionPaciente pGP=new ProcesoRNGestionPaciente();
        pGP.ActivarPaciente(idUsuario);
        estado=true;
    }catch(Exception ex)
    {
    }finally
    {
        return estado;
    }
}

    
}
