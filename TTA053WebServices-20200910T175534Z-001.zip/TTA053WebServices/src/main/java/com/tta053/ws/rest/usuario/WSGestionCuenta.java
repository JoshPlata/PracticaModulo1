package com.tta053.ws.rest.usuario;

import Entidades.GenUsuario;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

public class WSGestionCuenta {

    @RequestMapping(value = "/ws/User/WSGestionCuenta/", method = RequestMethod.POST,headers = "Accept=application/json")
      public void prueba(@RequestBody GenUsuario usuario)
      {   
          System.out.println(usuario.getApp());
      }
    
}
