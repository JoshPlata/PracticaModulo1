package CabeceraEspecialRest;

import java.util.List;

import Entidades.Monitoreo;

public class CabeceraSesionConsultaString {

    private SesionConsultaString sesionConsultaString;
    private List<PreguntaString> listaPreguntaString;
    private List<Monitoreo> listaMonitoreo;

    public SesionConsultaString getSesionConsultaString() {
        return sesionConsultaString;
    }

    public void setSesionConsultaString(SesionConsultaString sesionConsultaString) {
        this.sesionConsultaString = sesionConsultaString;
    }

    public List<PreguntaString> getListaPreguntaString() {
        return listaPreguntaString;
    }

    public void setListaPreguntaString(List<PreguntaString> listaPreguntaString) {
        this.listaPreguntaString = listaPreguntaString;
    }

    public List<Monitoreo> getListaMonitoreo() {
        return listaMonitoreo;
    }

    public void setListaMonitoreo(List<Monitoreo> listaMonitoreo) {
        this.listaMonitoreo = listaMonitoreo;
    }
}
