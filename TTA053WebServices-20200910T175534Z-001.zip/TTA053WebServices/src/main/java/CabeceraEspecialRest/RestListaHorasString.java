
package CabeceraEspecialRest;

import java.util.Date;
import java.util.List;

public class RestListaHorasString {
    
    private List<String> horasDisponible;

    public List<String> getHorasDisponible() {
        return horasDisponible;
    }

    public void setHorasDisponible(List<String> horasDisponible) {
        this.horasDisponible = horasDisponible;
    }
    
    
}
