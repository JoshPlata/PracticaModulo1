package CabeceraEspecialRest;

import java.util.List;

import Entidades.Diagnostico;
import Entidades.Historial;

public class CabeceraHistorialString {


    private List<CabeceraSesionConsultaString> listaCabeceraSesionesString;
    private Historial historialPaciente;
    private Diagnostico diagnosticoPaciente;

    public List<CabeceraSesionConsultaString> getListaCabeceraSesionesString() {
        return listaCabeceraSesionesString;
    }

    public void setListaCabeceraSesionesString(List<CabeceraSesionConsultaString> listaCabeceraSesionesString) {
        this.listaCabeceraSesionesString = listaCabeceraSesionesString;
    }

    public Historial getHistorialPaciente() {
        return historialPaciente;
    }

    public void setHistorialPaciente(Historial historialPaciente) {
        this.historialPaciente = historialPaciente;
    }

    public Diagnostico getDiagnosticoPaciente() {
        return diagnosticoPaciente;
    }

    public void setDiagnosticoPaciente(Diagnostico diagnosticoPaciente) {
        this.diagnosticoPaciente = diagnosticoPaciente;
    }
}
