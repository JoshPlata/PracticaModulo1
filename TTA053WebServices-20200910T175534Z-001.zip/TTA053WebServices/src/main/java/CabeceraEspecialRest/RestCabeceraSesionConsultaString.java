
package CabeceraEspecialRest;

public class RestCabeceraSesionConsultaString {
    
    private boolean bandera;

    public boolean isBandera() {
        return bandera;
    }

    public void setBandera(boolean bandera) {
        this.bandera = bandera;
    }
    
    public CabeceraHistorialString getCabeceraHistorialString() {
        return cabeceraHistorialString;
    }

    public void setCabeceraHistorialString(CabeceraHistorialString cabeceraHistorialString) {
        this.cabeceraHistorialString = cabeceraHistorialString;
    }

    private CabeceraHistorialString cabeceraHistorialString;


}
