package EntidadesCabeceras;
import Cabeceras.*;
import Entidades.*;
import java.util.List;
public class ListaPacientes {
    public List<CabeceraUsuario<Paciente>> getListaPacientes() {
        return listaPacientes;
    }

    public void setListaPacientes(List<CabeceraUsuario<Paciente>> listaPacientes) {
        this.listaPacientes = listaPacientes;
    }

    private List<CabeceraUsuario<Paciente>> listaPacientes;


}