/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EntidadesCabeceras;

import CabeceraDiario.CabeceraDiarioPaciente;

/**
 *
 * @author stile
 */
public class RestCabeceraDiarioPaciente {
    CabeceraDiarioPaciente cabeceraDiarioPaciente;

    public CabeceraDiarioPaciente getCabeceraDiarioPaciente() {
        return cabeceraDiarioPaciente;
    }

    public void setCabeceraDiarioPaciente(CabeceraDiarioPaciente cabeceraDiarioPaciente) {
        this.cabeceraDiarioPaciente = cabeceraDiarioPaciente;
    }
}
