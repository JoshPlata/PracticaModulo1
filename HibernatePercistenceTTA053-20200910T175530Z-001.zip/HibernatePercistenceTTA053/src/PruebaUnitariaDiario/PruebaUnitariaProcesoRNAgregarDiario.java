/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PruebaUnitariaDiario;

import Entidades.*;
import Procesos.RN.Paciente.Diario.ProcesoRNDiarioEstados;
import java.util.Date;

/**
 *
 * @author stile
 */
public class PruebaUnitariaProcesoRNAgregarDiario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ProcesoRNDiarioEstados estados = new ProcesoRNDiarioEstados();
        String estado = "4";
        String comentario = "4";
        String accion = "4";
        
        System.out.println(estados.agregarDiarioPaciente("585a5ccd-90b4-401e-926b-cb565927184d",estado,accion,comentario));
    
    }
    
}
