/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PruebaUnitariaDiario;

import DAOSMOD2.CRUD_DiaPaciente;
import Entidades.*;
import InstanciarHibernate.HibernateUtil;
import java.util.Date;
import java.util.List;
import org.hibernate.HibernateException;

/**
 *
 * @author stile
 */
public class PruebaUnitariaDiaPaciente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //crearDiaPaciente();
        //buscarDiaPaciente();
        listaDiaPaciente();
    }
    
    public static void crearDiaPaciente(){
        CRUD_DiaPaciente crudDiaPaciente = new CRUD_DiaPaciente();
        crudDiaPaciente.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
        crudDiaPaciente.setTx(crudDiaPaciente.getSesion().beginTransaction());
        
        DiarioPaciente DiarioP = new DiarioPaciente();
        DiarioP.setIdDiarioPaciente("7429cd25-cf1b-4f33-90df-e6377b8185d0");
        
        DiaPaciente DiaPaciente = new DiaPaciente();
        DiaPaciente.setDiarioPaciente(DiarioP);
        
        
        DiaPaciente.setFecha(new Date());
        
         try{
            
            crudDiaPaciente.CrearDiaPaciente(DiaPaciente);
            crudDiaPaciente.getTx().commit();
        }
        catch(HibernateException he)
        {
            if(crudDiaPaciente.getTx()!=null)
            {
                crudDiaPaciente.getTx().rollback();
            }
            
        }finally{
            if(crudDiaPaciente.getSesion()!=null)
            {
                crudDiaPaciente.getSesion().close();
            }
        
        }        
        HibernateUtil.shutdown();
    }
    
    public static void buscarDiaPaciente(){
        CRUD_DiaPaciente crudDiaPaciente = new CRUD_DiaPaciente();
        crudDiaPaciente.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
        crudDiaPaciente.setTx(crudDiaPaciente.getSesion().beginTransaction());
        
        DiaPaciente DiaPaciente = new DiaPaciente();;
        
         try{
            DiaPaciente = crudDiaPaciente.ObtenerDiaPaciente("8168cdd6-9300-49c3-9ead-67e8d16bb779");
            System.out.println("\nID Dia: " + DiaPaciente.getIdDiaPaciente() 
                    + "\nID Diario: " + DiaPaciente.getDiarioPaciente().getIdDiarioPaciente() 
                    + "\nFecha: " + DiaPaciente.getFecha());
        }
        catch(HibernateException he)
        {
            if(crudDiaPaciente.getTx()!=null)
            {
                crudDiaPaciente.getTx().rollback();
            }
            
        }finally{
            if(crudDiaPaciente.getSesion()!=null)
            {
                crudDiaPaciente.getSesion().close();
            }
        
        }        
        HibernateUtil.shutdown();
    }
    
    public static List<DiaPaciente> listaDiaPaciente(){
        CRUD_DiaPaciente crudDiaPaciente = new CRUD_DiaPaciente();
        crudDiaPaciente.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
        crudDiaPaciente.setTx(crudDiaPaciente.getSesion().beginTransaction());
        
        List<DiaPaciente>  DiaPacienteL = null;
        
         try{
            DiaPacienteL = crudDiaPaciente.ListaDiaPaciente("7429cd25-cf1b-4f33-90df-e6377b8185d0");
            for(DiaPaciente a: DiaPacienteL){    
                System.out.println("\nID Dia: " + a.getIdDiaPaciente() 
                    + "\nID Diario: " + a.getDiarioPaciente().getIdDiarioPaciente() 
                    + "\nFecha: " + a.getFecha());
            }
        }
        catch(HibernateException he)
        {
            if(crudDiaPaciente.getTx()!=null)
            {
                crudDiaPaciente.getTx().rollback();
            }
            
        }finally{
            if(crudDiaPaciente.getSesion()!=null)
            {
                crudDiaPaciente.getSesion().close();
            }
        
        }        
        HibernateUtil.shutdown();
        return DiaPacienteL;
    }
}
