package PruebaUnitariaDiario;

import DAOSMOD2.*;
import Entidades.*;
import InstanciarHibernate.HibernateUtil;
import org.hibernate.HibernateException;

public class PruebaUnitariaDiarioPaciente {

    public static void main(String[] args) {

       //pruebaCrearDiario();
       //pruebaActualizarDiario();
        pruebaBuscarDiario("150c3833-dd56-45ce-9b38-53a5e0ed7a9a");
    }
    
    
    public static void pruebaCrearDiario()
    {
     //150c3833-dd56-45ce-9b38-53a5e0ed7a9a
        CRUD_DiarioPaciente crudDiario = new CRUD_DiarioPaciente();
        crudDiario.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
        crudDiario.setTx(crudDiario.getSesion().beginTransaction());    
        DiarioPaciente diarioPaciente=new DiarioPaciente();
        diarioPaciente.setIdPaciente("150c3833-dd56-45ce-9b38-53a5e0ed7a9a");
        diarioPaciente.setNombre("Diario TCC");
        
        try{
            
            crudDiario.CrearDiarioPaciente(diarioPaciente);
            crudDiario.getTx().commit();
        }
        catch(HibernateException he)
        {
            if(crudDiario.getTx()!=null)
            {
                crudDiario.getTx().rollback();
            }
            
        }finally{
            if(crudDiario.getSesion()!=null)
            {
                crudDiario.getSesion().close();
            }
        
        }        
        HibernateUtil.shutdown();
    }
    
    public static void pruebaActualizarDiario()
    {
     //150c3833-dd56-45ce-9b38-53a5e0ed7a9a
        CRUD_DiarioPaciente crudDiario = new CRUD_DiarioPaciente();
        crudDiario.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
        crudDiario.setTx(crudDiario.getSesion().beginTransaction());    
        DiarioPaciente diarioPaciente=new DiarioPaciente();
        diarioPaciente.setIdDiarioPaciente("7429cd25-cf1b-4f33-90df-e6377b8185d0");
        diarioPaciente.setIdPaciente("150c3833-dd56-45ce-9b38-53a5e0ed7a9a");
        diarioPaciente.setNombre("Diario POPO");
        
        try{
            
            crudDiario.ActualizarDiariopPaciente(diarioPaciente);
            crudDiario.getTx().commit();
        }
        catch(HibernateException he)
        {
            if(crudDiario.getTx()!=null)
            {
                crudDiario.getTx().rollback();
            }
            
        }finally{
            if(crudDiario.getSesion()!=null)
            {
                crudDiario.getSesion().close();
            }
        
        }        
        HibernateUtil.shutdown();
    }
    
    public static void pruebaBuscarDiario(String idPaciente)
    {
     //150c3833-dd56-45ce-9b38-53a5e0ed7a9a
        CRUD_DiarioPaciente crudDiario = new CRUD_DiarioPaciente();
        crudDiario.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
        crudDiario.setTx(crudDiario.getSesion().beginTransaction());    
        DiarioPaciente diarioPaciente = new DiarioPaciente();
        
        try{
            
            diarioPaciente = crudDiario.ObtenerDiarioPaciente(idPaciente);
            System.out.println("\nID Diario: " + diarioPaciente.getIdDiarioPaciente() +
                    "\nNombre: " + diarioPaciente.getNombre() + 
                    "\nID PAciente: " + diarioPaciente.getIdPaciente());
        }
        catch(HibernateException he)
        {
            if(crudDiario.getTx()!=null)
            {
                crudDiario.getTx().rollback();
            }
            
        }finally{
            if(crudDiario.getSesion()!=null)
            {
                crudDiario.getSesion().close();
            }
        
        }        
        HibernateUtil.shutdown();
    }
    
    public static void pruebaEliminarDiario(String idPaciente)
    {
     //150c3833-dd56-45ce-9b38-53a5e0ed7a9a
        CRUD_DiarioPaciente crudDiario = new CRUD_DiarioPaciente();
        crudDiario.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
        crudDiario.setTx(crudDiario.getSesion().beginTransaction());    
        DiarioPaciente diarioPaciente = new DiarioPaciente();
        
        try{
            
            diarioPaciente = crudDiario.ObtenerDiarioPaciente(idPaciente);
            System.out.println("\nID Diario: " + diarioPaciente.getIdDiarioPaciente() +
                    "\nNombre: " + diarioPaciente.getNombre() + 
                    "\nID PAciente: " + diarioPaciente.getIdPaciente());
        }
        catch(HibernateException he)
        {
            if(crudDiario.getTx()!=null)
            {
                crudDiario.getTx().rollback();
            }
            
        }finally{
            if(crudDiario.getSesion()!=null)
            {
                crudDiario.getSesion().close();
            }
        
        }        
        HibernateUtil.shutdown();
    }
    
}
