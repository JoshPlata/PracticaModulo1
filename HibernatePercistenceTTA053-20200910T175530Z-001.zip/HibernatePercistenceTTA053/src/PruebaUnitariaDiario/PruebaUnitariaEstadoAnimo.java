/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PruebaUnitariaDiario;

import DAOSMOD2.CRUD_EstadoAnimo;
import Entidades.*;
import InstanciarHibernate.HibernateUtil;
import java.util.List;
import org.hibernate.HibernateException;

/**
 *
 * @author stile
 */
public class PruebaUnitariaEstadoAnimo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //crearDiaPaciente();
        //eliminarDiaPaciente();
        //modificarDiaPaciente();
        obtenerDiaPaciente();
    }
    
    public static void crearDiaPaciente(){
        CRUD_EstadoAnimo crudEstadoAnimo = new CRUD_EstadoAnimo();
        crudEstadoAnimo.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
        crudEstadoAnimo.setTx(crudEstadoAnimo.getSesion().beginTransaction());
        
        EstadoAnimo EstadoA = new EstadoAnimo();
        EstadoA.setNombre("Triste");
        DiaPaciente DiaPa = new DiaPaciente();
        DiaPa.setIdDiaPaciente("8168cdd6-9300-49c3-9ead-67e8d16bb779");
        EstadoA.setDiaPaciente(DiaPa);
        
         try{
            
            crudEstadoAnimo.CrearEstadoAnimo(EstadoA);
            crudEstadoAnimo.getTx().commit();
        }
        catch(HibernateException he)
        {
            if(crudEstadoAnimo.getTx()!=null)
            {
                crudEstadoAnimo.getTx().rollback();
            }
            
        }finally{
            if(crudEstadoAnimo.getSesion()!=null)
            {
                crudEstadoAnimo.getSesion().close();
            }
        
        }        
        HibernateUtil.shutdown();
    }
    
    public static void eliminarDiaPaciente(){
        CRUD_EstadoAnimo crudEstadoAnimo = new CRUD_EstadoAnimo();
        crudEstadoAnimo.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
        crudEstadoAnimo.setTx(crudEstadoAnimo.getSesion().beginTransaction());
        
         try{
            
            crudEstadoAnimo.EliminarEstadoAnimo("3271dedc-09fb-4f0e-982b-d19a284442d3");
            crudEstadoAnimo.getTx().commit();
        }
        catch(HibernateException he)
        {
            if(crudEstadoAnimo.getTx()!=null)
            {
                crudEstadoAnimo.getTx().rollback();
            }
            
        }finally{
            if(crudEstadoAnimo.getSesion()!=null)
            {
                crudEstadoAnimo.getSesion().close();
            }
        
        }        
        HibernateUtil.shutdown();
    }
    
    public static void modificarDiaPaciente(){
        CRUD_EstadoAnimo crudEstadoAnimo = new CRUD_EstadoAnimo();
        crudEstadoAnimo.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
        crudEstadoAnimo.setTx(crudEstadoAnimo.getSesion().beginTransaction());
        
        EstadoAnimo EstadoA = new EstadoAnimo();
        EstadoA.setNombre("Alegre");
        EstadoA.setIdEstadoAnimo("705508d2-fb83-4348-8c4e-c9bb4bcb5110");
        DiaPaciente DiaPa = new DiaPaciente();
        DiaPa.setIdDiaPaciente("8168cdd6-9300-49c3-9ead-67e8d16bb779");
        EstadoA.setDiaPaciente(DiaPa);
        
         try{
            
            crudEstadoAnimo.ActualizarEstadoAnimo(EstadoA);
            crudEstadoAnimo.getTx().commit();
        }
        catch(HibernateException he)
        {
            if(crudEstadoAnimo.getTx()!=null)
            {
                crudEstadoAnimo.getTx().rollback();
            }
            
        }finally{
            if(crudEstadoAnimo.getSesion()!=null)
            {
                crudEstadoAnimo.getSesion().close();
            }
        
        }        
        HibernateUtil.shutdown();
    }
    
    public static void obtenerDiaPaciente(){
        CRUD_EstadoAnimo crudEstadoAnimo = new CRUD_EstadoAnimo();
        crudEstadoAnimo.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
        crudEstadoAnimo.setTx(crudEstadoAnimo.getSesion().beginTransaction());
        
        EstadoAnimo EstadoA = new EstadoAnimo();
        
        try{
            EstadoA = crudEstadoAnimo.ObtenerEstadoAnimo("705508d2-fb83-4348-8c4e-c9bb4bcb5110");
            System.out.println("\nID Estado: " + EstadoA.getIdEstadoAnimo() +
                    "\nNombre: " + EstadoA.getNombre() +
                    "\nID Dia Paciente: " + EstadoA.getDiaPaciente().getIdDiaPaciente());
        }
        catch(HibernateException he)
        {
            if(crudEstadoAnimo.getTx()!=null)
            {
                crudEstadoAnimo.getTx().rollback();
            }
            
        }finally{
            if(crudEstadoAnimo.getSesion()!=null)
            {
                crudEstadoAnimo.getSesion().close();
            }
        
        }        
        HibernateUtil.shutdown();
    }
    
    public static void listaDiaPaciente(){
        CRUD_EstadoAnimo crudEstadoAnimo = new CRUD_EstadoAnimo();
        crudEstadoAnimo.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
        crudEstadoAnimo.setTx(crudEstadoAnimo.getSesion().beginTransaction());
        
        List<EstadoAnimo> EstadoA = null;
        
        try{
            EstadoA = crudEstadoAnimo.ListaEstadosAnimoPorDia("8168cdd6-9300-49c3-9ead-67e8d16bb779");
            for(EstadoAnimo e: EstadoA){
            System.out.println("\nID Estado: " + e.getIdEstadoAnimo() +
                    "\nNombre: " + e.getNombre() +
                    "\nID Dia Paciente: " + e.getDiaPaciente().getIdDiaPaciente());
            }
        }
        catch(HibernateException he)
        {
            if(crudEstadoAnimo.getTx()!=null)
            {
                crudEstadoAnimo.getTx().rollback();
            }
            
        }finally{
            if(crudEstadoAnimo.getSesion()!=null)
            {
                crudEstadoAnimo.getSesion().close();
            }
        
        }        
        HibernateUtil.shutdown();
    }
    
    public static void listaPPDiaPaciente(){
        CRUD_EstadoAnimo crudEstadoAnimo = new CRUD_EstadoAnimo();
        crudEstadoAnimo.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
        crudEstadoAnimo.setTx(crudEstadoAnimo.getSesion().beginTransaction());
        
        List<EstadoAnimo> EstadoA = null;
        
        try{
            EstadoA = crudEstadoAnimo.ListaEstadosAnimoPacientePorPaciente("150c3833-dd56-45ce-9b38-53a5e0ed7a9a");
            for(EstadoAnimo e: EstadoA){
            System.out.println("\nID Estado: " + e.getIdEstadoAnimo() +
                    "\nNombre: " + e.getNombre() +
                    "\nID Dia Paciente: " + e.getDiaPaciente().getIdDiaPaciente());
            }
        }
        catch(HibernateException he)
        {
            if(crudEstadoAnimo.getTx()!=null)
            {
                crudEstadoAnimo.getTx().rollback();
            }
            
        }finally{
            if(crudEstadoAnimo.getSesion()!=null)
            {
                crudEstadoAnimo.getSesion().close();
            }
        
        }        
        HibernateUtil.shutdown();
    }
}
