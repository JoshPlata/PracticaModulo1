/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PruebaUnitariaDiario;

import CabeceraDiario.CabeceraDia;
import CabeceraDiario.CabeceraDiarioPaciente;
import DAOSMOD2.*;
import Entidades.*;
import InstanciarHibernate.HibernateUtil;
import Procesos.RN.Paciente.Diario.ProcesoRNDiarioEstados;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import net.bytebuddy.matcher.FilterableList;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author stile
 */
public class PruebaUnitariaRNCabeceraDiarioPaciente {
    
    public static void main(String [] args){
        
        ProcesoRNDiarioEstados procesoRNDiarioEstados = new ProcesoRNDiarioEstados();
//        RestCabeceraDiarioPaciente restCabeceraDiarioPaciente = procesoRNDiarioEstados.mostrarDiarioPaciente("585a5ccd-90b4-401e-926b-cb565927184d");
       
    CabeceraDiarioPaciente CabeceraDiarioPaciente = 
            procesoRNDiarioEstados.mostrarDiarioPacienteMes("585a5ccd-90b4-401e-926b-cb565927184d"
                ,5,2018);
        if(CabeceraDiarioPaciente!=null);
        
//        CabeceraDiarioPaciente diarioPacienteC = new CabeceraDiarioPaciente();
//        CabeceraDia diasEstadosAccionesC = new CabeceraDia();
//        
//        Session sesion = HibernateUtil.getSessionFactory().getCurrentSession();
//        Transaction Tx = sesion.beginTransaction();
//        
//        CRUD_DiarioPaciente crudDiarioPaciente = new CRUD_DiarioPaciente();
//        crudDiarioPaciente.setSesion(sesion);
//        crudDiarioPaciente.setTx(Tx);
//        
//        CRUD_DiaPaciente crudDiaPaciente = new CRUD_DiaPaciente();
//        crudDiaPaciente.setSesion(sesion);
//        crudDiaPaciente.setTx(Tx);
//        
//        CRUD_EstadoAnimo crudEstadoAnimo = new CRUD_EstadoAnimo();
//        crudEstadoAnimo.setSesion(sesion);
//        crudEstadoAnimo.setTx(Tx);
//        
//        CRUD_AccionRealizada crudAccionRealizada = new CRUD_AccionRealizada();
//        crudAccionRealizada.setSesion(sesion);
//        crudAccionRealizada.setTx(Tx);
//        
//        DiarioPaciente diarioPaciente = crudDiarioPaciente.ObtenerDiarioPaciente("585a5ccd-90b4-401e-926b-cb565927184d");
//        diarioPacienteC.setDiario(diarioPaciente);
//        
//        List<DiaPaciente> listaDiasPaciente = crudDiaPaciente.ListaDiaPaciente(diarioPaciente.getIdDiarioPaciente());
//        List<CabeceraDia> listaCabeceraDia = new ArrayList<CabeceraDia>();
//        
//        for(int i=0; i < listaDiasPaciente.size() ; i++){
//            String id = listaDiasPaciente.get(i).getIdDiaPaciente();
//            List<EstadoAnimo> estadosAnimo = crudEstadoAnimo.ListaEstadosAnimoPorDia(id);
//            List<AccionRealizada> acciones = new ArrayList<AccionRealizada>();
//                    //= crudAccionRealizada.obtenerAccionesEstados(idEstadoAnimo);
//            for(int j=0; j<estadosAnimo.size();j++){
//                acciones.add(crudAccionRealizada.obtenerAccionesEstados(estadosAnimo.get(j).getIdEstadoAnimo()));
//            }
//            CabeceraDia cabeceraDia = new CabeceraDia();
//            cabeceraDia.setDia(listaDiasPaciente.get(i));
//            cabeceraDia.setAccionesEstado(acciones);
//            cabeceraDia.setEstadosDia(estadosAnimo);
//            listaCabeceraDia.add(cabeceraDia);
//        }
//        diarioPacienteC.setDias(listaCabeceraDia);
    }
}
