/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PruebaUnitariaDiario;

import DAOSMOD2.*;
import Entidades.*;
import InstanciarHibernate.HibernateUtil;
import org.hibernate.HibernateException;

/**
 *
 * @author stile
 */
public class PruebaUnitariaAccionRealizada {
    
    public static void main(String[] args) {
        //crearAccionRealizada();
        //eliminarAccionRealizada();
        buscarAccionRealizada();
    }
    
    public static void crearAccionRealizada(){
        CRUD_AccionRealizada crudAccionRealizada = new CRUD_AccionRealizada();
        crudAccionRealizada.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
        crudAccionRealizada.setTx(crudAccionRealizada.getSesion().beginTransaction());
        
        AccionRealizada AccionR = new AccionRealizada(new EstadoAnimo());
        
        AccionR.setComentario("Mi mama me pego.");
        AccionR.setAccion("Rompi su jarron de Puebla.");
        EstadoAnimo EstadoA = new EstadoAnimo();
        EstadoA.setIdEstadoAnimo("705508d2-fb83-4348-8c4e-c9bb4bcb5110");
        AccionR.setEstadoAnimo(EstadoA);
           
        try{
            crudAccionRealizada.CrearAccionRealizada(AccionR);
            crudAccionRealizada.getTx().commit();
        }
        catch(HibernateException he)
        {
            if(crudAccionRealizada.getTx()!=null)
            {
                crudAccionRealizada.getTx().rollback();
            }
            
        }finally{
            if(crudAccionRealizada.getSesion()!=null)
            {
                crudAccionRealizada.getSesion().close();
            }
        
        }        
        HibernateUtil.shutdown();
    }
    
    //Pendiente
    /*public static void eliminarAccionRealizada(){
        CRUD_AccionRealizada crudAccionRealizada = new CRUD_AccionRealizada();
        crudAccionRealizada.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
        crudAccionRealizada.setTx(crudAccionRealizada.getSesion().beginTransaction());
           
        try{
            crudAccionRealizada.EliminarAccionRealizada("412cebb3-99d1-48b1-9a43-6c6818c34737");
            crudAccionRealizada.getTx().commit();
        }
        catch(HibernateException he)
        {
            if(crudAccionRealizada.getTx()!=null)
            {
                crudAccionRealizada.getTx().rollback();
            }
            
        }finally{
            if(crudAccionRealizada.getSesion()!=null)
            {
                crudAccionRealizada.getSesion().close();
            }
        
        }        
        HibernateUtil.shutdown();
    }
    */
    public static void buscarAccionRealizada(){
        CRUD_AccionRealizada crudAccionRealizada = new CRUD_AccionRealizada();
        crudAccionRealizada.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
        crudAccionRealizada.setTx(crudAccionRealizada.getSesion().beginTransaction());
        AccionRealizada AccionR = new AccionRealizada();
        
        try{
            AccionR = crudAccionRealizada.ObtenerAccionRealizada("412cebb3-99d1-48b1-9a43-6c6818c34737");
            System.out.println("\nID Accion: " + AccionR.getIdAccionRealizada() + 
                    "\nID Estado: " + AccionR.getEstadoAnimo().getIdEstadoAnimo() +
                    "\nAccion: " + AccionR.getAccion() +
                    "\nComentario: " + AccionR.getComentario());
        }
        catch(HibernateException he)
        {
            if(crudAccionRealizada.getTx()!=null)
            {
                crudAccionRealizada.getTx().rollback();
            }
            
        }finally{
            if(crudAccionRealizada.getSesion()!=null)
            {
                crudAccionRealizada.getSesion().close();
            }
        
        }        
        HibernateUtil.shutdown();
    }
    
    public static void actualizarAccionRealizada(){
        
    }
    
}
