/*
    En esta clase vamos a instanciar Un Usuario Administrador por default
Instancias:

   2 apliaciones Paciente, Psicologo
   3 roles Principales del Sistema:Administrador,Psicólogo, Paciente
   


*/
package InicializacionContexto;

import DAOSMOD1.CRUD_Aplicacion;
import DAOSMOD1.CRUD_Rol;
import Entidades.GenAplicacion;
import Entidades.GenRol;
import InstanciarHibernate.HibernateUtil;
import org.hibernate.HibernateException;

public class IncializarPreConfiguracionApp {

    
    public static void main(String[] args) {
    //Agregar Roles
    
      CRUD_Rol crudRol=new CRUD_Rol();
      CRUD_Aplicacion crudAplicacion=new CRUD_Aplicacion();

    try{
 
        
        crudRol.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
        crudRol.setTx(crudRol.getSesion().beginTransaction());
        crudAplicacion.setSesion(crudRol.getSesion());
        crudAplicacion.setTx(crudRol.getTx());
        // 00000000-0000-0000-0000-000000000000
        crudRol.CrearRol(new GenRol("00000000-0000-0000-0000-000000000000","Administrador","Administrador del Sistema de Paciente y Psicologo"));
        crudRol.CrearRol(new GenRol("00000000-0000-0000-0000-000000000001","Psicologo","Este Rol es para los Psicólogos que tienen acceso al Sistema"));
        crudRol.CrearRol(new GenRol("00000000-0000-0000-0000-000000000002","Paciente","Este Rol es para todos los pacientes de cada Psicólogo Registrado"));
        
        crudAplicacion.CrearAplicacion(new GenAplicacion("00000000-0000-0000-0000-000000000000","AppPsicologo","Es la aplicación a la que tendrán acceso los psicologos"));
        crudAplicacion.CrearAplicacion(new GenAplicacion("00000000-0000-0000-0000-000000000001","AppPaciente","Es la aplicación a la que tendrán acceso los pacientes que halla registrado cada psicólogo"));
        crudAplicacion.getTx().commit();
    
    
    }catch(HibernateException he)
    {
        if(crudRol.getTx()!=null&&crudAplicacion.getTx()!=null)
        {
            crudRol.getTx().rollback();
            crudAplicacion.getTx().rollback();
        }
    }
    finally
    {
    
        if(crudRol.getSesion()!=null&&crudAplicacion.getSesion()!=null)
        {
            crudRol.getSesion().close();
            crudAplicacion.getSesion().close();                  
        }
    }
     HibernateUtil.shutdown();

     }
    
}
