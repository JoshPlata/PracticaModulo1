
package InstanciarHibernate;

import net.sf.ehcache.hibernate.HibernateUtil;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class InstanciaHibernate {

    private SessionFactory sessionFactory; 
    public Session sesion; 
    public Transaction tx;
    public boolean estado;
    
    
    
    public void iniciaOperacion() throws HibernateException 
    {
        if(estado==true)
        {
            
        }
        else
        {
            estado=true;
            sessionFactory = new Configuration().configure().buildSessionFactory();
            tx=null;
            sesion=sessionFactory.openSession();
            tx=sesion.beginTransaction();
        }
        
    }  

    public void manejaExcepcion(HibernateException he) throws HibernateException 
    { 
        if(tx!=null)tx.rollback();
        he.printStackTrace();
        throw new HibernateException("Ocurrió un error en la capa de acceso a datos", he); 
    } 
    public void finalizarOperacion()throws HibernateException 
    {
        tx.commit();
        sesion.close();
        estado=false;
    }
}
