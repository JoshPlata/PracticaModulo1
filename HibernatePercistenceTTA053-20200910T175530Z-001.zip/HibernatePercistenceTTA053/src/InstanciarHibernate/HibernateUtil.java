/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InstanciarHibernate;

import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.model.naming.ImplicitNamingStrategyJpaCompliantImpl;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.ServiceRegistry;

public class HibernateUtil {

    //private static StandardServiceRegistry registry;
    private static SessionFactory sessionfabrica;
    private static ServiceRegistry registro;

    public static SessionFactory getSessionFactory() {
        if (sessionfabrica == null) {
            try {
         
                StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder()
                        .configure("hibernate.cfg.xml")
                        .build();
                Metadata metadata = new MetadataSources(standardRegistry)
                        //.addAnnotatedClass(GenUsuario.class)
                        // You can add more entity classes here like above
                        //Se puede Agregar el Paquete completo o por Archivo
                        //.addResource("Entidades/GenUsuario.hbm.xmls")
                        .addPackage("Entidades")
                        .getMetadataBuilder()
                        .applyImplicitNamingStrategy(ImplicitNamingStrategyJpaCompliantImpl.INSTANCE)
                        .build();

                sessionfabrica = metadata.getSessionFactoryBuilder().build();
                //session = sessionFactory.openSession();

            } catch (Exception e) {
                if (registro != null) {
                    StandardServiceRegistryBuilder.destroy(registro);
                }
                e.printStackTrace();
            }
        }
        return sessionfabrica;
    }

    public static void shutdown() {
        if (registro != null) {
            StandardServiceRegistryBuilder.destroy(registro);
        }
    }
}
