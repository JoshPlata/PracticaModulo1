package CabecerasSesion;

import java.util.List;

import Entidades.Monitoreo;
import Entidades.Pregunta;
import Entidades.SesionConsulta;

public class CabeceraSesionConsulta {

    private SesionConsulta sesionConsulta;
    private List<Pregunta> listaPregunta;
    private List<Monitoreo> listaMonitoreo;

    public SesionConsulta getSesionConsulta() {
        return sesionConsulta;
    }

    public void setSesionConsulta(SesionConsulta sesionConsulta) {
        this.sesionConsulta = sesionConsulta;
    }

    public List<Pregunta> getListaPregunta() {
        return listaPregunta;
    }

    public void setListaPregunta(List<Pregunta> listaPregunta) {
        this.listaPregunta = listaPregunta;
    }

    public List<Monitoreo> getListaMonitoreo() {
        return listaMonitoreo;
    }

    public void setListaMonitoreo(List<Monitoreo> listaMonitoreo) {
        this.listaMonitoreo = listaMonitoreo;
    }
}
