package CabecerasSesion;

import java.util.List;

import Entidades.Diagnostico;
import Entidades.Historial;

public class CabeceraHistorial {

    public List<CabeceraSesionConsulta> getListaCabeceraSesiones() {
        return listaCabeceraSesiones;
    }

    public void setListaCabeceraSesiones(List<CabeceraSesionConsulta> listaCabeceraSesiones) {
        this.listaCabeceraSesiones = listaCabeceraSesiones;
    }

    private List<CabeceraSesionConsulta> listaCabeceraSesiones;

    public Historial getHistorialPaciente() {
        return historialPaciente;
    }

    public void setHistorialPaciente(Historial historialPaciente) {
        this.historialPaciente = historialPaciente;
    }

    public Diagnostico getDiagnosticoPaciente() {
        return diagnosticoPaciente;
    }

    public void setDiagnosticoPaciente(Diagnostico diagnosticoPaciente) {
        this.diagnosticoPaciente = diagnosticoPaciente;
    }

    private Historial historialPaciente;
    private Diagnostico diagnosticoPaciente;

}
