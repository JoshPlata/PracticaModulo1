package DAOSMOD1;

import Entidades.Dia;
import InstanciarHibernate.HibernateUtil;
import java.util.Date;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class CRUD_Dia {
private Session sesion;
  private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    }  
  public CRUD_Dia()
  {
     }
  
public void CrearDia(Dia dia) {
     sesion.save(dia);
}

public Dia ObtenerDia(Date fecha) {
        Dia dia = null;
        dia = (Dia) sesion.createQuery("from Dia where fecha='"+fecha+"'").uniqueResult();
        return dia;
    }

    public List<Dia> ListaDias(String idAgenda) {
        List<Dia> listaDias = null;
        listaDias = sesion.createQuery("from Dia where agenda.idAgenda='"+idAgenda+"'").list();
        return listaDias;
    }
}
