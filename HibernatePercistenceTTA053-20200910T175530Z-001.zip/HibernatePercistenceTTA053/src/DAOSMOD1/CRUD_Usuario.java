
package DAOSMOD1;

import Entidades.GenUsuario;
import InstanciarHibernate.HibernateUtil;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class CRUD_Usuario {
    //Creamos Un Uauario
  
  private Session session;
  private Transaction tx;

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    }
  
  
  public CRUD_Usuario()
  {
  }
  public Session getSesion()
  {
      return session;
  }
  public void setSesion(Session sesion)
  {
      this.session=sesion;
  }
    public boolean CrearUsuario(GenUsuario usuario) {
        boolean estado=false;
               
       if(this.ObtenerUsuarioporCorreo(usuario.getCorreo())==null)
        {
            session.save(usuario);
            estado=true;
        }     
        return estado;
    }

    //Eliminamos Un Usuario
    public void EliminarUsuario(String idUsuario) {
            GenUsuario usuario = (GenUsuario) session.get(GenUsuario.class, idUsuario);
            session.delete(usuario);
    }

    public void ActualizarUsuario(GenUsuario usuario) 
    {
        session.update(usuario);
    }

    public GenUsuario ObtenerUsuario(String IdUsuario) {
        GenUsuario usuario = null;
        
        usuario=(GenUsuario)session.createQuery("SELECT u FROM GenUsuario u "
                + "where u.idUsuario='"+IdUsuario+"'").uniqueResult();
        //usuario = (GenUsuario) session.get(GenUsuario.class, IdUsuario);
        
        return usuario;
    }

    public List<GenUsuario> ListaUsuarios() {
        List<GenUsuario> listapersona = null;
        
           
            listapersona = session.createQuery("from GenUsuario").list();
        return listapersona;
    }
    
    //Este metodo si nos regresa null esque el correo no existe registrado previamente
    //Tambien podemos traer un Usuario
    public GenUsuario ObtenerUsuarioporCorreo(String correo)
    {
        GenUsuario usuario=null;
        usuario= (GenUsuario)session.createQuery("select u from GenUsuario u "
                
                + "where u.correo='"+correo+"'").uniqueResult();
        return usuario;
    }
    public boolean VerificarUsuarioContrasena(String correo,String contrasena)
    {
        boolean estado=false;
        GenUsuario usuario=null;
         usuario = (GenUsuario)session.createQuery("from GenUsuario where correo='"+correo+"' AND contrasena='"+contrasena+"'");
         if(usuario!=null)
         {
             estado=true;
         }
        return estado;
    }
    
}
