package DAOSMOD1;

import Entidades.Diagnostico;
import Entidades.Paciente;
import InstanciarHibernate.HibernateUtil;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class CRUD_Diagnostico {
 private Session sesion;
  private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    }    
  public CRUD_Diagnostico()
  {
  }
    public void CrearDiagnostico(Diagnostico diagnostico) {
          sesion.save(diagnostico);    
    }
    //Eliminamos Un Usuario
    public void EliminarDiagnostico(String idDiagnostico) {
            Diagnostico diagnostico = (Diagnostico) sesion.get(Diagnostico.class, idDiagnostico);
            sesion.delete(diagnostico);
    }

    public void ActualizarDiagnostico(Diagnostico diagnostico) {
           sesion.update(diagnostico);
          }

    public Diagnostico ObtenerDiagnostico(String IdDiagnostico) {
        Diagnostico diagnostico = null;
        diagnostico= (Diagnostico) sesion.get(Diagnostico.class, IdDiagnostico);
        return diagnostico;
    }

    public Diagnostico ObtenerDiagnosticoPorPaciente(String idPaciente)
    {
        Diagnostico diagnostico=(Diagnostico)sesion.createQuery("from Diagnostico where historials.paciente.idPaciente='"+idPaciente+"'").uniqueResult();
        
        return diagnostico;
    }
    
}
