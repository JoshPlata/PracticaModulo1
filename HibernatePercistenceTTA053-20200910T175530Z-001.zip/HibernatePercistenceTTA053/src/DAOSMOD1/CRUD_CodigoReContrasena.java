package DAOSMOD1;

import Entidades.GenCodigoReContrasena;
import InstanciarHibernate.HibernateUtil;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class CRUD_CodigoReContrasena {
    
     private Session sesion;
  private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    }   
  public CRUD_CodigoReContrasena()
  {
  }
     public void CrearCodigoReContrasena(GenCodigoReContrasena codigo) {
           
            sesion.save(codigo);
    }

    //Eliminamos Un Usuario
    public void EliminarCodigoReContrasena(String idCodigo) {
            GenCodigoReContrasena codigo = (GenCodigoReContrasena)sesion.get(GenCodigoReContrasena.class, idCodigo);
            sesion.delete(codigo);
        }

    public void ActualizarCodigoReContrasena(GenCodigoReContrasena codigo) {
            sesion.update(codigo);
    }

    public GenCodigoReContrasena ObtenerCodigoReContrasena(String IdCodigo) {
        GenCodigoReContrasena codigo = null;
            codigo  = (GenCodigoReContrasena) sesion.get(GenCodigoReContrasena.class, IdCodigo);
        return codigo;
    }
    public List<GenCodigoReContrasena> ObtenerCodigoReContrasenaPoridCuenta(String idCuenta) {
        List<GenCodigoReContrasena> codigoReContrasena = null;
            codigoReContrasena  = sesion.createQuery("from GenCodigoReContrasena where genCuenta.idCuenta='"+idCuenta+"'").list();
        return codigoReContrasena;
    }
    
    public List<GenCodigoReContrasena> ListaCodigoReContrasena() {
        List<GenCodigoReContrasena> listacodigo = null;
            listacodigo = sesion.createQuery("from GenCodigoReContrasena").list();
       return listacodigo;
    }
    
    
}
