package DAOSMOD1;

import Entidades.Psicologo;
import InstanciarHibernate.HibernateUtil;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class CRUD_Psicologo {
    private Session sesion;
       private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    }
    public CRUD_Psicologo()
  {
   }
     public void CrearPsicologo(Psicologo psicologo) {
            sesion.save(psicologo);
    }

    //Eliminamos Un Usuario
    public void EliminarPsicologo(String idPsicologo) {
       Psicologo psicologo = (Psicologo) sesion.get(Psicologo.class, idPsicologo);
       sesion.delete(psicologo);
    }

    public void ActualizarPsicologo(Psicologo usuario) {
        sesion.update(usuario);
    }

    public Psicologo ObtenerPsicologo(String IdPsicologo) {
        Psicologo psicologo = null;
        psicologo = (Psicologo) sesion.get(Psicologo.class, IdPsicologo);
     
        return psicologo;
    }

    public List<Psicologo> ListaPsicologo() {
        List<Psicologo> listaPsicologo = null;
        listaPsicologo = sesion.createQuery("from Psicologo").list();
       
        return listaPsicologo;
    }
    public Psicologo ObtenerPsicologoporIdUser(String idUsuario)
    {
        Psicologo psicologo=(Psicologo)sesion.createQuery("from Psicologo where genUsuario.id='"+idUsuario+"'").uniqueResult();
        
        return psicologo;
    }
    
}
