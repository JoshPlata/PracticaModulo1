
package DAOSMOD1;

import Entidades.GenCuentaAplicacion;
import Entidades.GenCuentaAplicacionId;
import Entidades.GenRolUsuario;
import InstanciarHibernate.HibernateUtil;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class CRUD_CuentaAplicacion {
   
  public CRUD_CuentaAplicacion()
  {
  } 
  private Session sesion;
  private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    }   
    

  public void CrearCuentaAplicacion(GenCuentaAplicacionId cuentaAplicacionId) {
        
            GenCuentaAplicacion cuentaAplicacion=new GenCuentaAplicacion();
            cuentaAplicacion.setId(cuentaAplicacionId);
            sesion.save(cuentaAplicacion);
        
    }

    //Eliminamos Un Rol al Usuario
    public void EliminarCuentaAplicacion(GenCuentaAplicacionId cuentaAplicacionId) {
        
            GenCuentaAplicacion cuentaAplicacion=new GenCuentaAplicacion();
            cuentaAplicacion.setId(cuentaAplicacionId);
            sesion.delete(cuentaAplicacion); 
    }

    public void ActualizarCuentaAplicacion(GenCuentaAplicacionId cuentaAplicacionId) {
            GenCuentaAplicacion cuentaAplicacion=new GenCuentaAplicacion();
            cuentaAplicacion.setId(cuentaAplicacionId);
            sesion.update(cuentaAplicacion);
    }

    public GenCuentaAplicacion ObtenerCuentaAplicacion(GenCuentaAplicacionId cuentaAplicacionId) {
        
         GenCuentaAplicacion cuentaAplicacion=null;
         cuentaAplicacion = (GenCuentaAplicacion) sesion.get(GenCuentaAplicacion.class, cuentaAplicacionId);
        return cuentaAplicacion;
    }

    public List<GenCuentaAplicacion> ListaCuentaAplicacion(String IdCuenta) {
        List<GenCuentaAplicacion> listaCuentaAplicacion = null;
        listaCuentaAplicacion = sesion.createQuery(
        "SELECT ca FROM GenCuentaAplicacion ca "
                  + "JOIN FETCH ca.id "
                  + "JOIN FETCH ca.genAplicacion "
                  + "JOIN FETCH ca.genCuenta "
                  + "where ca.id.idCuentafk='"+IdCuenta+"'").list();
            return listaCuentaAplicacion;
    }   
}
