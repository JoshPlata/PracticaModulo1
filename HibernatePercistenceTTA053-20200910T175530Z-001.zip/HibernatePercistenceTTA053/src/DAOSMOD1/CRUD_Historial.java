package DAOSMOD1;


import Entidades.Historial;
import InstanciarHibernate.HibernateUtil;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class CRUD_Historial {
  
       private Session sesion;
  private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    } 
    public CRUD_Historial()
  {
   }
    public void CrearHistorial(Historial historial) {
           sesion.save(historial);
    }
    public void ActualizarHistorial(Historial historial) {
           sesion.update(historial);
          }

    public Historial ObtenerHistorial(String IdHistorial) {
       Historial historial = null;
            historial = (Historial) sesion.get(Historial.class, IdHistorial);
        return historial;
    }
    public Historial ObtenerHistorialPaciente(String IdPaciente) {
       Historial historial = null;
       String query="from Historial where paciente.idPaciente='"+IdPaciente+"'";
       historial = (Historial)sesion.createQuery(query).uniqueResult();
       return historial;
    }
    
}
