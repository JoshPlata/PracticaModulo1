
package DAOSMOD1;

import Entidades.Sesion;
import InstanciarHibernate.HibernateUtil;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class CRUD_Sesion {
 private Session sesion;
       private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    } 
  public CRUD_Sesion()
  {
  }
     public void CrearSesion(Sesion sesion) {
          this.sesion.save(sesion);
    }

    //Eliminamos Un Usuario
    public void EliminarSesion(String idSesion) {
            Sesion ses = (Sesion) sesion.get(Sesion.class, idSesion);
            sesion.delete(ses);
    }

    public void ActualizarSesion(Sesion ses) {
       sesion.update(ses);
    }

    public Sesion ObtenerSesion(String IdSesion) {
        Sesion ses = null;
        ses = (Sesion)sesion.get(Sesion.class, IdSesion);
        
        return ses;
    }
    public List<Sesion> ObtenerSesionesIdCuenta(String IdCuenta)
    {
        List<Sesion> listSesion = null;
        listSesion = sesion.createQuery("from Sesion where genCuenta.idCuenta='"+ IdCuenta +"'").list();
        
        return listSesion;
    
    }
    

    public List<Sesion> ListaSesiones() {
        List<Sesion> listasesiones = null;
        listasesiones = sesion.createQuery("from Sesion").list();
        return listasesiones;
    }
    
    
    
    
}
