package DAOSMOD1;

import Entidades.Pendientes;
import InstanciarHibernate.HibernateUtil;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class CRUD_Pendientes {
  
     private Session sesion;
       private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    } 
  
    public CRUD_Pendientes()
  {
  }
    public void CrearPendiente(Pendientes pendiente) {
        sesion.save(pendiente);
    }

    //Eliminamos Un Usuario
    public void EliminarPendiente(String idPendientes) {
            Pendientes pendiente = (Pendientes) sesion.get(Pendientes.class, idPendientes);         
            sesion.delete(pendiente);
    }

    public void ActualizarPendiente(Pendientes pendiente) 
    {
            sesion.update(pendiente);
    }

    public Pendientes ObtenerPendiente(String IdPendientes) {
        Pendientes pendiente = null;
        pendiente = (Pendientes) sesion.get(Pendientes.class, IdPendientes);
        
        return pendiente;
    }
    public List<Pendientes> ListaTodosPendientesDia(String idDia) {
        List<Pendientes> listaPendientes = null;
        listaPendientes = sesion.createQuery("from Pendientes where dia.idDiafk='"+idDia+"'").list();
        return listaPendientes;
    }

}
