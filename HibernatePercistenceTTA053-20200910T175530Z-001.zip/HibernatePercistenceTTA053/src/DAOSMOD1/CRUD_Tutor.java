
package DAOSMOD1;

import Entidades.Tutor;
import InstanciarHibernate.HibernateUtil;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class CRUD_Tutor {
  private Session sesion;
       private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    }  
  public CRUD_Tutor()
  {
  }
    public void CrearTutor(Tutor tutor) {
         sesion.save(tutor);
    }
    
    public void ActualizarTutor(Tutor tutor) 
    {
           sesion.update(tutor);
    }

    public Tutor ObtenerTutor(String IdTutor) {
        Tutor tutor = null;
        tutor = (Tutor) sesion.get(Tutor.class, IdTutor);
        
        return tutor;
    }

    public Tutor ObtenerTutorPorPaciente(String IdPaciente) {
        Tutor tutor = null;
        tutor = (Tutor)sesion.get(Tutor.class, IdPaciente);
        return tutor;
    }
    //Este metodo si nos regresa null esque el correo no existe registrado previamente
    //Tambien podemos traer un Usuario
}
