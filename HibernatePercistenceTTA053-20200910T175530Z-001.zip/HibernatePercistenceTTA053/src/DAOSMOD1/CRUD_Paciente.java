package DAOSMOD1;


import Entidades.GenUsuario;
import Entidades.Paciente;
import Entidades.Pendientes;
import Entidades.Psicologo;
import InstanciarHibernate.HibernateUtil;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class CRUD_Paciente {
    
   public CRUD_Paciente()
  {
  }
   private Session sesion;
       private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    } 
  
    public void CrearPendiente(Pendientes pendiente) {
        sesion.save(pendiente);
    }
  

   public void CrearPaciente(Paciente paciente) {
          sesion.save(paciente);
           
    }

    //Eliminamos Un Usuario
    public void EliminarPaciente(String idPaciente) {
            Paciente paciente = (Paciente)sesion.get(Paciente.class, idPaciente);
            sesion.delete(paciente);
    }

    public void ActualizarPaciente(Paciente paciente) {
            sesion.update(paciente);
          }

    public Paciente ObtenerPaciente(String idPaciente) {
        Paciente paciente = null;
        //paciente = (Paciente) sesion.get(Paciente.class, IdPaciente);
        paciente=(Paciente)sesion.createQuery("SELECT p FROM Paciente p "
                + "JOIN FETCH p.genUsuario "
                + "JOIN FETCH p.psicologo "
                + "JOIN FETCH p.psicologo.genUsuario"
                + "WHERE idPaciente='"+idPaciente+"'").uniqueResult();
        return paciente;
    }

    public List<Paciente> ListaPacientes() {
        List<Paciente> listapacientes = null;
        listapacientes =sesion.createQuery("SELECT p FROM Paciente p "
                + "JOIN FETCH p.genUsuario "
                  + "JOIN FETCH p.psicologo").list();
     
        return listapacientes;
    }
    public List<Paciente> ListaPacientesPorIdPsicologo(String IdPsicologo) {
        List<Paciente> listapacientes = new ArrayList<Paciente>();
        listapacientes =sesion.createQuery("SELECT p FROM Paciente p "
                  + "JOIN FETCH p.genUsuario "
                  + "JOIN FETCH p.psicologo "
                 // + "JOIN FETCH p.psicologo.paciente.genUsuario"
                  + "where p.psicologo.idPsicologo='"+IdPsicologo+"'").list();
        //EL FETCH SE PUEDE USAR solo con Objetos
        
        return listapacientes;
    }
    public Paciente ObtenerPacienteporIdUser(String idUsuario)
    {
        Paciente paciente=(Paciente)sesion.createQuery("SELECT p FROM Paciente p "
                  + "JOIN FETCH p.genUsuario "
                  + "LEFT JOIN FETCH p.psicologo "
                  //+"JOIN FETCH p.psicologo.paciente.genUsuario"
                  + "where p.genUsuario.id='"+idUsuario+"'").uniqueResult();
        //paciente.setGenUsuario(new GenUsuario());
        return paciente;
    }
    
    
}
