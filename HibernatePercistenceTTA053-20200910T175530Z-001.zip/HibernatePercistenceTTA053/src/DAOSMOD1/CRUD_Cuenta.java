package DAOSMOD1;

import Entidades.GenCuenta;
import Entidades.GenUsuario;
import InstanciarHibernate.HibernateUtil;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class CRUD_Cuenta {
  private Session sesion;
  private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    }   
  public CRUD_Cuenta()
  {
  }
  public void CrearCuenta(GenCuenta cuenta) {
            sesion.save(cuenta);
    }

    //Eliminamos Un Usuario
    public void EliminarCuenta(String idCuenta) {
            GenCuenta cuenta = (GenCuenta) sesion.get(GenCuenta.class, idCuenta);
            sesion.delete(cuenta);
    }

    public void ActualizarCuenta(GenCuenta cuenta) {
        sesion.update(cuenta);
    }

    public GenCuenta ObtenerCuenta(String IdCuenta) {
        GenCuenta cuenta = null;
            cuenta = (GenCuenta) sesion.createQuery("from GenCuenta where idCuenta='"+IdCuenta+"'").uniqueResult();
            //conexion.sesion.get(GenCuenta.class, IdCuenta);
        return cuenta;
    }

    public List<GenCuenta> ListaCuentas() {
        List<GenCuenta> listacuentas = null;
            listacuentas = sesion.createQuery("from GenCuenta").list();
        
        return listacuentas;
    }
    public GenCuenta ObtenerCuentaUsuario(String idUsuario)
    {
        GenCuenta cuenta=null;
        cuenta=(GenCuenta)sesion.createQuery("from GenCuenta where genUsuario.idUsuario='"+idUsuario+"'").uniqueResult();
    
        return cuenta;
    }
    
    
}
