
package DAOSMOD1;

import Entidades.GenRol;
import InstanciarHibernate.HibernateUtil;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class CRUD_Rol {

   
  public CRUD_Rol()
  {
   }
 private Session sesion;
       private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    }   
    public void CrearRol(GenRol rol) {
            sesion.save(rol);
    }

    //Eliminamos Un Rol
    public void EliminarTRol(String IdRol) {
        
           GenRol rol = (GenRol) sesion.get(GenRol.class, IdRol);
           sesion.delete(rol);
    }

    public void ActualizarRol(GenRol rol) {
        sesion.update(rol);
    }

    public GenRol ObtenerRol(String IdRol) {
        GenRol rol = null;
        //rol=(GenRol) conexion.sesion.createQuery("from GenRol where idRol='"+IdRol+"'").uniqueResult();
        rol = (GenRol)sesion.get(GenRol.class, IdRol);
        return rol;
    }

    public List<GenRol> ListaRoles() {
        List<GenRol> listaroles = null;
            listaroles = sesion.createQuery("from GenRol").list();
        return listaroles;
    }
    
    
}
