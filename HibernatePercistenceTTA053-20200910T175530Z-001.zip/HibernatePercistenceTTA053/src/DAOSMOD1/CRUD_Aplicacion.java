
package DAOSMOD1;

import Entidades.GenAplicacion;
import Entidades.GenUsuario;
import InstanciarHibernate.HibernateUtil;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class CRUD_Aplicacion {
 
     private Session sesion;
  private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    }  
  public CRUD_Aplicacion()
  {
  }
 
  public void CrearAplicacion(GenAplicacion aplicacion) {
            sesion.save(aplicacion);
    }

    //Eliminamos Un Usuario
    public void EliminarAplicacion(String idAplicacion) {
            GenAplicacion Aplicacion = (GenAplicacion) sesion.get(GenAplicacion.class, idAplicacion);
            sesion.delete(Aplicacion);
        }

    public void ActualizarAplicacion(GenAplicacion Aplicacion) {
            sesion.update(Aplicacion);
    }

    public GenAplicacion ObtenerAplicacion(String IdAplicacion) {
        GenAplicacion Aplicacion  = null;
            Aplicacion = (GenAplicacion) sesion.get(GenAplicacion.class, IdAplicacion);
        return Aplicacion;
    }

    public List<GenAplicacion> ListaAplicaciones() {
        List<GenAplicacion> listaAplicaciones = null;
           
            listaAplicaciones = sesion.createQuery("from GenAplicacion").list();
        return listaAplicaciones;
    }
    
    
    
}
