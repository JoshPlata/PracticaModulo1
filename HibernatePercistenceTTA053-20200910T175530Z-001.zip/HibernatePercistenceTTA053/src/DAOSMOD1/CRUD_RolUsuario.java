
package DAOSMOD1;

import Entidades.GenRol;
import Entidades.GenRolUsuario;
import Entidades.GenRolUsuarioId;
import Entidades.GenUsuario;
import InstanciarHibernate.HibernateUtil;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class CRUD_RolUsuario {
 private Session sesion;
       private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    }   
    public void CrearRol(GenRol rol) {
            sesion.save(rol);
    } 
  public CRUD_RolUsuario()
  {
  }
    //Crea Nadamás con respecto a la relación
 public void CrearRolUsuario(GenRolUsuarioId rolUsuarioId) {
        
            GenRolUsuario rolUsuario=new GenRolUsuario();
            rolUsuario.setId(rolUsuarioId);
            sesion.save(rolUsuario);
}

    //Eliminamos Un Rol al Usuario
    public void EliminarRolUsuario(GenRolUsuarioId rolUsuarioId) {
        
            GenRolUsuario rolUsuario=new GenRolUsuario();
            rolUsuario.setId(rolUsuarioId);
            sesion.delete(rolUsuario); 
    }

    public void ActualizarRolUsuario(GenRolUsuarioId rolUsuarioId) {
        
            GenRolUsuario rolUsuario=new GenRolUsuario();
            rolUsuario.setId(rolUsuarioId);
            sesion.update(rolUsuario);
    }

    public GenRolUsuario ObtenerRolUsuario(GenRolUsuarioId rolUsuarioId) {
        
        GenRolUsuario usuarioRol=null;
            usuarioRol = (GenRolUsuario) sesion.get(GenRolUsuario.class,rolUsuarioId);
         return usuarioRol;
    }

    public List<GenRolUsuario> ListaRolUsuario(String IdUsuario) {
        List<GenRolUsuario> listaRolPersona = null;
        
          //listaRolPersona = conexion.sesion.createQuery("SELECT u.id,u.genRol,u.genUsuario FROM GenRolUsuario u WHERE u.id.idUsuariofk='"+IdUsuario+"'").list();
          
          listaRolPersona= (List<GenRolUsuario>)sesion.createQuery(
          "SELECT a FROM GenRolUsuario a "
                  + "JOIN FETCH a.id "
                  + "JOIN FETCH a.genRol "
                  + "JOIN FETCH a.genUsuario "
                  + "where a.id.idUsuariofk='"+IdUsuario+"'").list();
          //"SELECT a FROM Author a JOIN FETCH a.books WHERE a.id = 1"
          //"SELECT u.id,u.genRol,u.genUsuario FROM GenRolUsuario u where u.id.idUsuariofk='"+IdUsuario+"'"
          //listaRolPersona = conexion.sesion.createQuery("from GenRolUsuario where genUsuario.idUsuario='"+IdUsuario+"'").list();
        return listaRolPersona;
    }   

}
