
package PruebasUnitariasSesion;

import DAOSMOD3.CRUD_Monitoreo;
import Entidades.Monitoreo;
import Entidades.Pregunta;
import InstanciarHibernate.HibernateUtil;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class PruebaUnitariaMonitoreo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //agregarMonitoreo();
        consultarMonitoreo();
    }
    
    public static void agregarMonitoreo()
    {
     Monitoreo monitoreo = new Monitoreo();
     monitoreo.setPromedioGeneral(8.0);
     monitoreo.setPromedioSenial1(1.0);
     monitoreo.setPromedioSenial2(2.0);
     monitoreo.setPromedioSenial3(3.0);
     monitoreo.setPromedioSenial4(4.0);
     Pregunta ask = new Pregunta();
     ask.setIdPregunta("5b9cd082-fe61-43f0-8a6f-d5c79e69ddc7");
     monitoreo.setPregunta(ask);
     Session sesion ;
     Transaction tx;
     CRUD_Monitoreo crudMonitoreo = new CRUD_Monitoreo();
     
     try
        {
            sesion = HibernateUtil.getSessionFactory().getCurrentSession();
            tx = sesion.beginTransaction();
            crudMonitoreo.setSesion(sesion);
            crudMonitoreo.setTx(tx);
            crudMonitoreo.CrearMonitoreo(monitoreo);
            crudMonitoreo.getTx().commit();
        }
        
        catch(HibernateException he)
        {
            if(crudMonitoreo.getTx()!=null)
                    {
                        crudMonitoreo.getTx().rollback();
                    }
        }
        
        finally
        {
            
         if(crudMonitoreo.getSesion()!=null)
                    {
                        crudMonitoreo.getSesion().close();    
                    }      
        }
        HibernateUtil.shutdown();
    }
    
    public static void consultarMonitoreo()
    {
        Monitoreo monitoreo = new Monitoreo();
     monitoreo.setPromedioGeneral(8.0);
     monitoreo.setPromedioSenial1(1.0);
     monitoreo.setPromedioSenial2(2.0);
     monitoreo.setPromedioSenial3(3.0);
     monitoreo.setPromedioSenial4(4.0);
     Pregunta ask = new Pregunta();
     ask.setIdPregunta("5b9cd082-fe61-43f0-8a6f-d5c79e69ddc7");
     monitoreo.setPregunta(ask);
     Session sesion ;
     Transaction tx;
     CRUD_Monitoreo crudMonitoreo = new CRUD_Monitoreo();
     Monitoreo monitor = new Monitoreo();
     
     try
        {
            sesion = HibernateUtil.getSessionFactory().getCurrentSession();
            tx = sesion.beginTransaction();
            crudMonitoreo.setSesion(sesion);
            crudMonitoreo.setTx(tx);
            crudMonitoreo.CrearMonitoreo(monitoreo);
            monitor = crudMonitoreo.ObtenerMonitoreo("bae9ccf8-48ca-4ccd-b977-aad27a995c87");
        }
        
        catch(HibernateException he)
        {
            if(crudMonitoreo.getTx()!=null)
                    {
                        crudMonitoreo.getTx().rollback();
                    }
        }
        
        finally
        {
            
         if(crudMonitoreo.getSesion()!=null)
                    {
                        crudMonitoreo.getSesion().close();    
                    }      
        }
        HibernateUtil.shutdown();
    }
}