
package PruebasUnitariasSesion;

import DAOSMOD3.CRUD_Diagnostico;
import Entidades.Diagnostico;
import InstanciarHibernate.HibernateUtil;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class PruebaUnitariaDiagnostico {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        consultarDiagnosticoPaciente();
        
    }
    
    public static void agregarDiagnosticoPaciente()
    {
        Diagnostico diagnostico = new Diagnostico();
        diagnostico.setDiagnostico("Diagnostico de prueba2");
        diagnostico.setResumenDiagnostico("Resumen dsgsdfjgdfgksjddfgsdf");
        
        Session sesion ;
        Transaction tx;
        CRUD_Diagnostico crudDiagnostico= new CRUD_Diagnostico();
        
        try{
            sesion = HibernateUtil.getSessionFactory().getCurrentSession();
            tx = sesion.beginTransaction();
            crudDiagnostico.setSesion(sesion);
            crudDiagnostico.setTx(tx);
            crudDiagnostico.CrearDiagnostico(diagnostico);
            crudDiagnostico.getTx().commit();
            }
        catch(HibernateException he)
                {
                    if(crudDiagnostico.getTx()!=null)
                    {
                        crudDiagnostico.getTx().rollback();
                    }
                    
                }
        
        finally
        {
            if(crudDiagnostico.getSesion()!=null)
                    {
                        crudDiagnostico.getSesion().close();    
                    }      
        }
        HibernateUtil.shutdown();
        
    }
    
    public static void consultarDiagnosticoPaciente()
    {
        Diagnostico diagnostico = new Diagnostico();
        diagnostico.setDiagnostico("Diagnostico de prueba2");
        diagnostico.setResumenDiagnostico("Resumen dsgsdfjgdfgksjddfgsdf");
        
        Session sesion ;
        Transaction tx;
        CRUD_Diagnostico crudDiagnostico= new CRUD_Diagnostico();
        Diagnostico diag;
        try{
            sesion = HibernateUtil.getSessionFactory().getCurrentSession();
            tx = sesion.beginTransaction();
            crudDiagnostico.setSesion(sesion);
            crudDiagnostico.setTx(tx);
            diag=crudDiagnostico.ObtenerDiagnostico("b5f5c589-6fc4-4fde-821a-38c01f8633b2");
            }
        catch(HibernateException he)
                {
                    if(crudDiagnostico.getTx()!=null)
                    {
                        crudDiagnostico.getTx().rollback();
                    }
                    
                }
        
        finally
        {
            
            if(crudDiagnostico.getSesion()!=null)
                    {
                        crudDiagnostico.getSesion().close();    
                    }      
        }
        HibernateUtil.shutdown();
        
    }
    
}