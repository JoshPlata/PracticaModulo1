
package PruebasUnitariasSesion;

import DAOSMOD3.CRUD_Pregunta;
import Entidades.*;
import InstanciarHibernate.HibernateUtil;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class PruebaUnitariaPregunta {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        agregarPregunta();
        //consultarPregunta();
    }

    public static void agregarPregunta() {
        Pregunta pregunta = new Pregunta();
        // pregunta.set("9114-498e-a979-977955749086");
        pregunta.setPregunta("Error probando3");
        pregunta.setNum(1);
        SesionConsulta seco = new SesionConsulta();
        seco.setIdSesionConsulta("120a675f-c096-42a2-8def-03e90561c661");
        pregunta.setSesionConsulta(seco);
        Session sesion;
        Transaction tx;
        CRUD_Pregunta crudPregunta = new CRUD_Pregunta();

        try {
            sesion = HibernateUtil.getSessionFactory().getCurrentSession();
            tx = sesion.beginTransaction();
            crudPregunta.setSesion(sesion);
            crudPregunta.setTx(tx);
            crudPregunta.CrearPregunta(pregunta);
            crudPregunta.getTx().commit();
        } catch (HibernateException he) {
            if (crudPregunta.getTx() != null) {
                crudPregunta.getTx().rollback();
            }
        } finally {

            if (crudPregunta.getSesion() != null) {
                crudPregunta.getSesion().close();
            }
        }
        HibernateUtil.shutdown();
    }

    public static void consultarPregunta() {
        Pregunta pregunta = new Pregunta();
        //pregunta.setIdPreconfiguracionSesionfk("9114-498e-a979-977955749086");
        pregunta.setPregunta("Cuanto es 1 mas 1");
        pregunta.setNum(1);
        SesionConsulta seco = new SesionConsulta();
        seco.setIdSesionConsulta("5e5e0d94-9114-498e-a979-977955749086");
        pregunta.setSesionConsulta(seco);
        Session sesion;
        Transaction tx;
        CRUD_Pregunta crudPregunta = new CRUD_Pregunta();
        Pregunta question;

        try {
            sesion = HibernateUtil.getSessionFactory().getCurrentSession();
            tx = sesion.beginTransaction();
            crudPregunta.setSesion(sesion);
            crudPregunta.setTx(tx);
            crudPregunta.CrearPregunta(pregunta);
            question = crudPregunta.ObtenerPregunta("5b9cd082-fe61-43f0-8a6f-d5c79e69ddc7");

        } catch (HibernateException he) {
            if (crudPregunta.getTx() != null) {
                crudPregunta.getTx().rollback();
            }
        } finally {

            if (crudPregunta.getSesion() != null) {
                crudPregunta.getSesion().close();
            }
        }
        HibernateUtil.shutdown();
    }
}
