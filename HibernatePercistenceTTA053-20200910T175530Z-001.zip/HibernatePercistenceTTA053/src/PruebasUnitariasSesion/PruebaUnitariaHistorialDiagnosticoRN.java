
package PruebasUnitariasSesion;

import Entidades.*;
import Procesos.RN.SesionConsulta.HistorialDiagnosticoRN;


public class PruebaUnitariaHistorialDiagnosticoRN {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
    
        HistorialDiagnosticoRN rn = new HistorialDiagnosticoRN();
        Diagnostico diagnostico = new Diagnostico();
        diagnostico.setDiagnostico("Paciente con TDAH");
        diagnostico.setResumenDiagnostico("TDAH desde los 5 años");
        //rn.AgregarDiagnosticoEnHistorial(diagnostico, "43201998-b453-442a-8b94-b38f521a97c7");
        
        rn.obtenerHistorial("43201998-b453-442a-8b94-b38f521a97c7");
        
    }
    
}