
package PruebasUnitariasSesion;


import Entidades.Historial;
import DAOSMOD3.CRUD_Historial;
import Entidades.Diagnostico;
import InstanciarHibernate.HibernateUtil;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class PruebaUnitariaHistorial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
//        agregarHistorial();
        consultarHistorial();
    }
    
    public static void agregarHistorial()
    {
        Historial historial = new Historial();
        historial.setIdPacientefk("31acccee-a7e9-4dde-b71b-c46832a477d6");
        Diagnostico diagnostico=new Diagnostico();
        //diagnostico.setResumenDiagnostico("blablabla");
        diagnostico.setIdDiagnostico("32acccee-a7e9-4dde-b71b-c46832a477d6");
        //diagnostico.setDiagnostico("asdads");
        historial.setDiagnostico(diagnostico);
        
        Session sesion ;
        Transaction tx;
        CRUD_Historial crudHistorial= new CRUD_Historial();
        
        try
        {
            sesion = HibernateUtil.getSessionFactory().getCurrentSession();
            tx = sesion.beginTransaction();
            crudHistorial.setSesion(sesion);
            crudHistorial.setTx(tx);
            crudHistorial.CrearHistorial(historial);
            crudHistorial.getTx().commit();
        }
        
        catch(HibernateException he)
        {
            if(crudHistorial.getTx()!=null)
                    {
                        crudHistorial.getTx().rollback();
                    }
        }
        
        finally
        {
            
         if(crudHistorial.getSesion()!=null)
                    {
                        crudHistorial.getSesion().close();    
                    }      
        }
        HibernateUtil.shutdown();
    }
    
    public static void consultarHistorial()
    {
        Historial historial = new Historial();
        historial.setIdPacientefk("31acccee-a7e9-4dde-b71b-c46832a477d6");
        Diagnostico diagnostico=new Diagnostico();
        //diagnostico.setResumenDiagnostico("blablabla");
        diagnostico.setIdDiagnostico("32acccee-a7e9-4dde-b71b-c46832a477d6");
        //diagnostico.setDiagnostico("asdads");
        historial.setDiagnostico(diagnostico);
        
        Session sesion ;
        Transaction tx;
        CRUD_Historial crudHistorial= new CRUD_Historial();
        Historial hist;
        
        try
        {
            sesion = HibernateUtil.getSessionFactory().getCurrentSession();
            tx = sesion.beginTransaction();
            crudHistorial.setSesion(sesion);
            crudHistorial.setTx(tx);
            crudHistorial.CrearHistorial(historial);
            hist = crudHistorial.ObtenerHistorial("2ee4bf86-6fa8-4c68-85f5-db5e1c0d31cb");
        }
        
        catch(HibernateException he)
        {
            if(crudHistorial.getTx()!=null)
                    {
                        crudHistorial.getTx().rollback();
                    }
        }
        
        finally
        {
            
         if(crudHistorial.getSesion()!=null)
                    {
                        crudHistorial.getSesion().close();    
                    }      
        }
        HibernateUtil.shutdown();
    }
}