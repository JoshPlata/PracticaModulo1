
package PruebasUnitariasSesion;

import DAOSMOD3.CRUD_AnalisisNeuronal;
import Entidades.*;
import InstanciarHibernate.HibernateUtil;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class PruebaUnitariaAnalisisNeuronal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
//        agregarAnalisisNeuronal();
          consultarAnalisisNeuronal();
    }
    
    public static void agregarAnalisisNeuronal(){
    
        AnalisisNeuronal ananeuro = new AnalisisNeuronal();
        ananeuro.setSenial1(1.0);
        ananeuro.setSenial2(2.0);
        ananeuro.setSenial3(3.0);
        ananeuro.setSenial4(4.0);
        Pregunta ask = new Pregunta();
        ask.setIdPregunta("5b9cd082-fe61-43f0-8a6f-d5c79e69ddc7");
        ananeuro.setPregunta(ask);
         Session sesion ;
        Transaction tx;
        CRUD_AnalisisNeuronal crudAnal = new CRUD_AnalisisNeuronal();
        
        try
        {
            sesion = HibernateUtil.getSessionFactory().getCurrentSession();
            tx = sesion.beginTransaction();
            crudAnal.setSesion(sesion);
            crudAnal.setTx(tx);
            crudAnal.CrearAnalisisNeuronal(ananeuro);
//            crudAnal.getTx().commit();
        }
        
        catch(HibernateException he)
        {
            if(crudAnal.getTx()!=null)
                    {
                        crudAnal.getTx().rollback();
                    }
        }
        
        finally
        {
            
         if(crudAnal.getSesion()!=null)
                    {
                        crudAnal.getSesion().close();    
                    }      
        }
        HibernateUtil.shutdown();
    }
    
    public static void consultarAnalisisNeuronal(){
    
        AnalisisNeuronal ananeuro = new AnalisisNeuronal();
        ananeuro.setSenial1(1.0);
        ananeuro.setSenial2(2.0);
        ananeuro.setSenial3(3.0);
        ananeuro.setSenial4(4.0);
        Pregunta ask = new Pregunta();
        ask.setIdPregunta("5b9cd082-fe61-43f0-8a6f-d5c79e69ddc7");
        ananeuro.setPregunta(ask);
         Session sesion ;
        Transaction tx;
        CRUD_AnalisisNeuronal crudAnal = new CRUD_AnalisisNeuronal();
        AnalisisNeuronal anito = new AnalisisNeuronal();
        
        try
        {
            sesion = HibernateUtil.getSessionFactory().getCurrentSession();
            tx = sesion.beginTransaction();
            crudAnal.setSesion(sesion);
            crudAnal.setTx(tx);
            crudAnal.CrearAnalisisNeuronal(ananeuro);
            anito = crudAnal.ObtenerAnalisisNeuronal("6187b1a6-b6dd-41ee-aa6c-9235c497e4ef");
        }
        
        catch(HibernateException he)
        {
            if(crudAnal.getTx()!=null)
                    {
                        crudAnal.getTx().rollback();
                    }
        }
        
        finally
        {
            
         if(crudAnal.getSesion()!=null)
                    {
                        crudAnal.getSesion().close();    
                    }      
        }
        HibernateUtil.shutdown();
    }
    
    
    
}