/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PruebasUnitariasSesion;

import Procesos.RN.SesionConsulta.SesionConsultaRN;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 *
 * @author stile
 */
public class PruebaUnitariaCitaCalendar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ParseException {
        
        SesionConsultaRN scrn = new SesionConsultaRN();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); //Para declarar valores en nuevos objetos date, usa el mismo formato date que usaste al crear las fechas 
        Date fechaActual = sdf.parse("2018-06-17");
        scrn.obtenerSesionesConsultaPorPsicologo("111657ef-ec1e-42f3-b049-4c36c6eb99d9",fechaActual);
        
    }
    
}
