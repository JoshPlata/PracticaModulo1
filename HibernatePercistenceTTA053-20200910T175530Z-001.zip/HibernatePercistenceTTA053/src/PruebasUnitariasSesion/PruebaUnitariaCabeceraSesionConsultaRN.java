/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PruebasUnitariasSesion;

import CabecerasSesion.CabeceraHistorial;
import Procesos.RN.SesionConsulta.CabeceraSesionConsultaRN;

/**
 *
 * @author stile
 */
public class PruebaUnitariaCabeceraSesionConsultaRN {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CabeceraSesionConsultaRN cabeceraSesionConsultaRN = new CabeceraSesionConsultaRN();
        CabeceraHistorial cabeceraHistorial = cabeceraSesionConsultaRN.obtenerCabeceraSesionConsulta("43201998-b453-442a-8b94-b38f521a97c7");
        if(cabeceraHistorial != null);
    }
    
}
