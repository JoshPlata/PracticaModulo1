
package PruebasUnitariasSesion;

import DAOSMOD3.*;
import Entidades.*;
import InstanciarHibernate.HibernateUtil;
import Procesos.RN.SesionConsulta.SesionConsultaRN;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javafx.beans.binding.ListExpression;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class PruebaUnitariaSesionConsulta {

    public static void main(String[] args) {
       
          //agregarSesionConsulta();
          //consultarSesionConsulta();
          //obtenerSesiones();
          //preconfiguracionSesion();preconfiguracionSesion();preconfiguracionSesion();
          //modificarPreconfiguracionSesion();
          //eliminarPregunta();
          //obtenerListaPreguntas("8b224ba6-782e-4187-a76e-a9a023ad5725");c
          //crearMonitoreoPregunta();
          listaMonitoreos();
          
    }
    
    public static void preconfiguracionSesion(){
        SesionConsultaRN sesionConsultaRN = new SesionConsultaRN();
        SesionConsulta sesionConsulta = new SesionConsulta();
        sesionConsulta.setIdSesionConsulta("8b224ba6-782e-4187-a76e-a9a023ad5725");
        List<Pregunta> listaPreguntas = new ArrayList<>();
        
        Pregunta pregunta1 = new Pregunta();
        pregunta1.setNum(1);
        pregunta1.setPregunta("Te gusta el color verde?");
        pregunta1.setSesionConsulta(sesionConsulta);
        
        Pregunta pregunta2 = new Pregunta();
        pregunta2.setNum(2);
        pregunta2.setPregunta("Te gusta el mole?");
        pregunta2.setSesionConsulta(sesionConsulta);
        
        Pregunta pregunta3 = new Pregunta();
        pregunta3.setNum(3);
        pregunta3.setPregunta("Te gusta Zac Efron?");
        pregunta3.setSesionConsulta(sesionConsulta);
        
        listaPreguntas.add(pregunta1);
        listaPreguntas.add(pregunta2);
        listaPreguntas.add(pregunta3);
        
        sesionConsultaRN.iniciarPreconfiguracionSesion(listaPreguntas);
    }
    
    public static void eliminarPregunta(){
        
        SesionConsultaRN sesionConsultaRN = new SesionConsultaRN();
        SesionConsulta sesionConsulta = new SesionConsulta();
        sesionConsulta.setIdSesionConsulta("8b224ba6-782e-4187-a76e-a9a023ad5725");
        List<String> listaPreguntas = new ArrayList<>();
        
        listaPreguntas.add("9a2e463c-3bf4-4439-957f-6b5112b51ab3");
        sesionConsultaRN.elimarPreguntasPreconfiguracionSesion(listaPreguntas,"8b224ba6-782e-4187-a76e-a9a023ad5725");
        
    }
    
    public static void modificarPreconfiguracionSesion(){
        SesionConsultaRN sesionConsultaRN = new SesionConsultaRN();
        SesionConsulta sesionConsulta = new SesionConsulta();
        sesionConsulta.setIdSesionConsulta("8b224ba6-782e-4187-a76e-a9a023ad5725");
        List<Pregunta> listaPreguntas = new ArrayList<>();
        
        Pregunta pregunta1 = new Pregunta();
        pregunta1.setIdPregunta("7bd3a4f3-df40-4a58-a566-a23d1f524519");
        pregunta1.setPregunta("Te gusta el color verde azulado?");
        pregunta1.setSesionConsulta(sesionConsulta);
        
        Pregunta pregunta2 = new Pregunta();
        pregunta2.setIdPregunta("3eadcb9b-a05c-45da-956b-1c9fca0e18ed");
        pregunta2.setPregunta("Te gusta el mole sin pollo?");
        pregunta2.setSesionConsulta(sesionConsulta);
        
        Pregunta pregunta3 = new Pregunta();
        pregunta3.setIdPregunta("5fb028db-d5ef-4509-9586-52a1df9b9296");
        pregunta3.setPregunta("Te gusta Zac Efron o Chris Brawn?");
        pregunta3.setSesionConsulta(sesionConsulta);
        
        listaPreguntas.add(pregunta1);
        listaPreguntas.add(pregunta2);
        listaPreguntas.add(pregunta3);
        
        sesionConsultaRN.modificarPreconfiguracionSesion(listaPreguntas);
    }
    
    public static void obtenerListaPreguntas(String idSesionConsulta){
        SesionConsultaRN sesionConsultaRN = new SesionConsultaRN();
        List<Pregunta> lista = sesionConsultaRN.listaPreguntasPreconfiguracionSesion(idSesionConsulta);
        if(lista != null){
            
        }
    }
    
    public static void obtenerSesiones(){
        CRUD_SesionConsulta crud_SesionConsulta = new CRUD_SesionConsulta();
        crud_SesionConsulta.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
        crud_SesionConsulta.setTx(crud_SesionConsulta.getSesion().beginTransaction());
        
        List<SesionConsulta> listaSesionConsulta = crud_SesionConsulta.obtenerSesionesPorDia(new Date(),"111657ef-ec1e-42f3-b049-4c36c6eb99d9");
        if(listaSesionConsulta ==null||listaSesionConsulta.size()==0 )
        {
            System.out.println("No hay citas hoy en el momento del mundo mundial");
        
        }
        crud_SesionConsulta.getSesion().close();
        HibernateUtil.shutdown();
    }
    
    public static void agregarSesionConsulta()
    {
        SesionConsulta sesionconsul = new SesionConsulta();
        sesionconsul.setIdSesionConsulta("0000000000");
        sesionconsul.setObjetivo("coshar");
        sesionconsul.setIdPsicologofk("123435342563456");
        sesionconsul.setIdPacientefk("126875342563345");
        sesionconsul.setFecha(new Date());
        sesionconsul.setHora(new Date());
        Historial historia = new Historial();
        historia.setIdHistorial("2ee4bf86-6fa8-4c68-85f5-db5e1c0d31cb");
        sesionconsul.setHistorial(historia);
         Session sesion ;
        Transaction tx;
        CRUD_SesionConsulta crudSeCo= new CRUD_SesionConsulta();
        
       try
        {
            sesion = HibernateUtil.getSessionFactory().getCurrentSession();
            tx = sesion.beginTransaction();
            crudSeCo.setSesion(sesion);
            crudSeCo.setTx(tx);
            crudSeCo.CrearSesionConsulta(sesionconsul);
            crudSeCo.getTx().commit();
        }
        
        catch(HibernateException he)
        {
            if(crudSeCo.getTx()!=null)
                    {
                        crudSeCo.getTx().rollback();
                    }
        }
        
        finally
        {
            
         if(crudSeCo.getSesion()!=null)
                    {
                        crudSeCo.getSesion().close();    
                    }      
        }
        HibernateUtil.shutdown();
    }
    
    public static void consultarSesionConsulta()
    {
        SesionConsulta sesionconsul = new SesionConsulta();
        sesionconsul.setIdSesionConsulta("0000000000");
        sesionconsul.setObjetivo("coshar");
        sesionconsul.setIdPsicologofk("123435342563456");
        sesionconsul.setIdPacientefk("126875342563345");
        sesionconsul.setFecha(new Date());
        sesionconsul.setHora(new Date());
        Historial historia = new Historial();
        historia.setIdHistorial("2ee4bf86-6fa8-4c68-85f5-db5e1c0d31cb");
        sesionconsul.setHistorial(historia);
         Session sesion ;
        Transaction tx;
        CRUD_SesionConsulta crudSeCo= new CRUD_SesionConsulta();
        SesionConsulta sc;
        
       try
        {
            sesion = HibernateUtil.getSessionFactory().getCurrentSession();
            tx = sesion.beginTransaction();
            crudSeCo.setSesion(sesion);
            crudSeCo.setTx(tx);
            crudSeCo.CrearSesionConsulta(sesionconsul);
            sc=crudSeCo.ObtenerSesionConsulta("5e5e0d94-9114-498e-a979-977955749086");
        }
        
        catch(HibernateException he)
        {
            if(crudSeCo.getTx()!=null)
                    {
                        crudSeCo.getTx().rollback();
                    }
        }
        
        finally
        {
            
         if(crudSeCo.getSesion()!=null)
                    {
                        crudSeCo.getSesion().close();    
                    }      
        }
        HibernateUtil.shutdown();
    }
    
    public static void crearMonitoreoPregunta(){
        List<Monitoreo> preguntasMonitoreadas = new ArrayList<>();
        Monitoreo monitoreo = new Monitoreo();
        Pregunta pregunta = new Pregunta();
        pregunta.setIdPregunta("6127ba7d-008c-4024-b674-7a3dba7533db");
        monitoreo.setPregunta(pregunta);
        preguntasMonitoreadas.add(monitoreo);
        SesionConsultaRN sesionConsultaRN = new SesionConsultaRN();
        sesionConsultaRN.crearMonitoreo(preguntasMonitoreadas);
    }

    public static void listaMonitoreos()
    {
       SesionConsultaRN sesionConsultaRN=new SesionConsultaRN();
       Pregunta pregunta=new Pregunta();
       pregunta.setIdPregunta("6127ba7d-008c-4024-b674-7a3dba7533db");
       List<Pregunta> listaPregunta=new ArrayList<Pregunta>();
       listaPregunta.add(pregunta);
       List<Monitoreo>listMonitorieos= sesionConsultaRN.listarMonitoreos(listaPregunta);
               if(listMonitorieos!=null);
    }
}