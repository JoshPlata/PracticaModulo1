/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PruebasUnitariasSesion;

import Entidades.Historial;
import Entidades.SesionConsulta;
import Procesos.RN.SesionConsulta.SesionConsultaRN;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author stile
 */
public class PruebaUnitariaSesionConsultadaRN {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        boolean status = crearSesionConsulta();
    }
    
    public static boolean crearSesionConsulta(){
        SesionConsulta sesionConsulta = new SesionConsulta();
        SesionConsultaRN sesionConsultaRn = new SesionConsultaRN();
        sesionConsulta.setObjetivo("Verificar ejecucion metodos RN");
        sesionConsulta.setIdPacientefk("43201998-b453-442a-8b94-b38f521a97c7");
        sesionConsulta.setIdPsicologofk("111657ef-ec1e-42f3-b049-4c36c6eb99d9");
        Historial historial = new Historial();
        historial.setIdHistorial("c5ded970-9c1f-4254-ac2f-74c163ef6f83");
        sesionConsulta.setHistorial(historial);
        sesionConsulta.setStatusSesion(false);
        Calendar calendario = Calendar.getInstance();
        calendario.set(2018,05,06,18,20,0);
        Date date1=calendario.getTime();
        sesionConsulta.setFecha(date1);
        sesionConsulta.setHora(date1);
        
        return sesionConsultaRn.crearSesionConsulta(sesionConsulta);
    }
}
