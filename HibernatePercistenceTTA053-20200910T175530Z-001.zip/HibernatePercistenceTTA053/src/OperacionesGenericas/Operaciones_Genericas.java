/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OperacionesGenericas;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author stile
 */
public final class Operaciones_Genericas {
    
    public static String formatearFecha(Date Fecha){
        String newFecha = new SimpleDateFormat("yyyy-MM-dd").format(Fecha);
        return newFecha; 
    }
    
    public static Date formatearfechaTexto(String fecha) throws ParseException
    {
        return new SimpleDateFormat("yyyy-MM-dd").parse(fecha);
    }
    
    public static String obtenerFecha(Date fecha){
        DateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        return formatoFecha.format(fecha);
    }
}
