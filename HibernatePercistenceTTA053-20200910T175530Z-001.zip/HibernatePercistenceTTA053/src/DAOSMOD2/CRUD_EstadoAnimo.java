
package DAOSMOD2;


import Entidades.*;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class CRUD_EstadoAnimo {

   private Session sesion;
  private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    } 
  public CRUD_EstadoAnimo()
  {
  }
    public void CrearEstadoAnimo(EstadoAnimo estadoAnimo) {
        sesion.save(estadoAnimo);   
    }
    //Eliminamos Un Usuario
    public void EliminarEstadoAnimo(String idEstadoAnimo) {
            EstadoAnimo estadoAnimo = (EstadoAnimo) sesion.get(EstadoAnimo.class, idEstadoAnimo);
            sesion.delete(estadoAnimo);
    }

    public void ActualizarEstadoAnimo(EstadoAnimo estadoAnimo) {
            sesion.update(estadoAnimo);
          }

    public EstadoAnimo ObtenerEstadoAnimo(String IdEstadoAnimo) {
        EstadoAnimo estadoAnimo = null;
        estadoAnimo = (EstadoAnimo) sesion.get(EstadoAnimo.class, IdEstadoAnimo);
        return estadoAnimo;
    }

    public List<EstadoAnimo> ListaEstadosAnimoPorDia(String idDiaPaciente) {
        List<EstadoAnimo> listaEstadoAnimo= null;
        listaEstadoAnimo = sesion.createQuery("from EstadoAnimo where diaPaciente.idDiaPaciente='"+idDiaPaciente+"'").list();
        return listaEstadoAnimo;
    }
    
    public List<EstadoAnimo> ListaEstadosAnimoPacientePorPaciente(String idPaciente) {
        List<EstadoAnimo> listaEstadoAnimo= null;
        //Puede que falle el Query hay que probar
            String query="from EstadoAnimo where diaPaciente.diarioPaciente.paciente.idPaciente='"+idPaciente+"' order by diaPaciente.fecha desc";
            listaEstadoAnimo = sesion.createQuery(query).list();
        return listaEstadoAnimo;
    }
//    
//    public List<EstadoAnimo> ListaEstadosAnimoDiaPaciente(String idDiaPaciente) {
//        List<EstadoAnimo> listaEstadoAnimo= null;
//        //Puede que falle el Query hay que probar
//            String query="FROM EstadoAnimo WHERE idDiaPacientefk='"+idDiaPaciente+"'";
//            listaEstadoAnimo = sesion.createQuery(query).list();
//        return listaEstadoAnimo;
//    }
}
