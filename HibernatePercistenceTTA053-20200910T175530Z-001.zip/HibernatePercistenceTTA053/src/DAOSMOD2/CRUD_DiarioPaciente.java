package DAOSMOD2;


import Entidades.*;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class CRUD_DiarioPaciente {

    
  public CRUD_DiarioPaciente()
  {
  }
  private Session sesion;
  private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    } 
public void CrearDiarioPaciente(DiarioPaciente paciente) {
            sesion.save(paciente);
       }

    public void ActualizarDiariopPaciente(DiarioPaciente diarioPaciente) {
            sesion.update(diarioPaciente);
          }

    public DiarioPaciente ObtenerDiarioPaciente(String IdPaciente) {
       DiarioPaciente diarioPaciente = null;
       diarioPaciente = (DiarioPaciente)sesion.createQuery("from DiarioPaciente where idPaciente='"+IdPaciente+"'").uniqueResult();
        return diarioPaciente;
    }    
}
