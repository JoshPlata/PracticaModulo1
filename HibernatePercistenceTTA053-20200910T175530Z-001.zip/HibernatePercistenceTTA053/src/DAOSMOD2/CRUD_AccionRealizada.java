
package DAOSMOD2;


import Entidades.*;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class CRUD_AccionRealizada { 
  private Session sesion;
  private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    }
  public CRUD_AccionRealizada()
  {
      
  }
  
    public void CrearAccionRealizada(AccionRealizada accionRealizada) {
           sesion.save(accionRealizada);
    }

    //Eliminamos Un Usuario
//    public void EliminarAccionRealizada(String idAccionRealizada) {
//       AccionRealizadaId id=new AccionRealizadaId();
//       id.setIdAccionRealizada(idAccionRealizada);
//            AccionRealizada accionRealizada = (AccionRealizada) sesion.get(AccionRealizada.class, id);
//            sesion.delete(accionRealizada);
//    }

    public void ActualizarAccionRealizada(AccionRealizada accionRealizada) {
            sesion.update(accionRealizada);
          }

    public AccionRealizada ObtenerAccionRealizada(String IdAccionRealizada) {
       AccionRealizada accionRealizada = null;
        accionRealizada =(AccionRealizada)sesion.createQuery("SELECT a FROM AccionRealizada a "
                + "where a.idAccionRealizada='"+IdAccionRealizada+"'").uniqueResult();
        //usuario = (GenUsuario) session.get(GenUsuario.class, IdUsuario);
        return accionRealizada;
    }
    
    public AccionRealizada obtenerAccionesEstados(String idEstadoAnimo){
      AccionRealizada accionRealizada = null;
             
        accionRealizada =(AccionRealizada)sesion.createQuery("SELECT a FROM AccionRealizada a "
                + "where a.estadoAnimo.idEstadoAnimo='"+idEstadoAnimo+"'").uniqueResult();
        
        return accionRealizada;  
    }

}
