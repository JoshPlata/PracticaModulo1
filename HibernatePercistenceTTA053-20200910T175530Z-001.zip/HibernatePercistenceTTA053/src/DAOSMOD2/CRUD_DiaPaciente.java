package DAOSMOD2;


import Entidades.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class CRUD_DiaPaciente {
    
private Session sesion;
private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    }    
  public CRUD_DiaPaciente()
  {
  }
   public void CrearDiaPaciente(DiaPaciente diaPaciente) {
            sesion.save(diaPaciente);
      }
    public DiaPaciente ObtenerDiaPaciente(String idDiaPaciente) {
        DiaPaciente diaPaciente = null;
        diaPaciente = (DiaPaciente) sesion.createQuery("FROM DiaPaciente WHERE idDiaPaciente='"+idDiaPaciente+"'").uniqueResult();
        return diaPaciente;
    }

    public List<DiaPaciente> ListaDiaPaciente(String idDiarioPaciente) {
        List<DiaPaciente> listapersona = null;
        listapersona = sesion.createQuery("from DiaPaciente where idDiarioPacientefk='"+idDiarioPaciente+"' ORDER BY fecha DESC").list();
        return listapersona;
    }
    
    public List<DiaPaciente> ListaDiaPacienteFechaEspecifica(String idDiarioPaciente, int anio, int mes,int dia) {
        List<DiaPaciente> listapersona = null;
        Date fecha = new Date(anio,mes,dia);
        String newFecha = new SimpleDateFormat("yyyy-MM-dd").format(fecha);
        listapersona = sesion.createQuery("from DiaPaciente where idDiarioPacientefk='"+idDiarioPaciente+"' and fecha='"+newFecha+"'").list();
        return listapersona;
    }
    
    
    public List<DiaPaciente> ListaDiaPacienteRangoFechas(String idDiarioPaciente, Date ini,Date fin) {
        List<DiaPaciente> listapersona = null;
        
        String newIni = new SimpleDateFormat("yyyy-MM-dd").format(ini);
        String newFin = new SimpleDateFormat("yyyy-MM-dd").format(fin);
        String sql="from DiaPaciente where idDiarioPacientefk='"+idDiarioPaciente+"' and "+
               "fecha BETWEEN '"+newIni+"' and '"+newFin+"'";
       listapersona = sesion.createQuery(sql).list();
       
        //BETWEEN :startDate AND :endDate
   
        
        return listapersona;
    }
       
    public List<DiaPaciente> ListaDiaPacienteMes(String idDiarioPaciente, int mes, int anio) {
        
        Calendar calendar=Calendar.getInstance();
        calendar.set(anio,mes-1,1);
        
        
        
        List<DiaPaciente> listapersona = null;
        Date ini=calendar.getTime();
        int ultimoDia=calendar.getActualMaximum(calendar.DAY_OF_MONTH);
        calendar.set(anio,mes,ultimoDia);
        Date fin=calendar.getTime();
        String newIni = new SimpleDateFormat("yyyy-MM-dd").format(ini);
        String newFin = new SimpleDateFormat("yyyy-MM-dd").format(fin);
        String sql="from DiaPaciente where idDiarioPacientefk='"+idDiarioPaciente+"' and "+
               "fecha BETWEEN '"+newIni+"' and '"+newFin+"'";
       listapersona = sesion.createQuery(sql).list();
       
        //BETWEEN :startDate AND :endDate
   
        
        return listapersona;
    }
    
    //TRUE si existe la fecha
    public boolean validarDia(Date fecha, String idDiarioPaciente){
        DiaPaciente diaPaciente = null;
        boolean diaExiste = false;
        String newFecha = new SimpleDateFormat("yyyy-MM-dd").format(fecha);
        diaPaciente = (DiaPaciente) sesion.createQuery("FROM DiaPaciente WHERE fecha='"+newFecha+"'"
                + " AND idDiarioPacientefk='"+idDiarioPaciente+"'").uniqueResult();
        
        //System.out.println(diaPaciente.getDiarioPaciente());
        
        if(diaPaciente != null){
            diaExiste = true;
        }
        return diaExiste;
    }
    
    public DiaPaciente obtenerDiaPacientePorFecha(Date Fecha, String idDiarioPaciente){
        DiaPaciente diaPaciente = null;
        String newFecha = new SimpleDateFormat("yyyy-MM-dd").format(Fecha);
        diaPaciente = (DiaPaciente) sesion.createQuery("FROM DiaPaciente WHERE fecha='"+newFecha+"'"
                + " AND idDiarioPacientefk='"+idDiarioPaciente+"'").uniqueResult();
       return diaPaciente;
    }
}
