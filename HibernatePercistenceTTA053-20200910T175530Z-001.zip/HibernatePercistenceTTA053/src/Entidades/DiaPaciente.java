package Entidades;


import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class DiaPaciente  implements java.io.Serializable {


     private String idDiaPaciente;
     private DiarioPaciente diarioPaciente;
     private Date fecha;
//     private Set estadoAnimos = new HashSet(0);

    public DiaPaciente() {
        this.idDiaPaciente=UUID.randomUUID().toString();
    }

	
    public DiaPaciente(String idDiaPaciente, DiarioPaciente diarioPaciente, Date fecha) {
        this.idDiaPaciente = idDiaPaciente;
        this.diarioPaciente = diarioPaciente;
        this.fecha = fecha;
    }
    public DiaPaciente(String idDiaPaciente, DiarioPaciente diarioPaciente, Date fecha, Set estadoAnimos) {
       this.idDiaPaciente = idDiaPaciente;
       this.diarioPaciente = diarioPaciente;
       this.fecha = fecha;
//       this.estadoAnimos = estadoAnimos;
    }
   
    public String getIdDiaPaciente() {
        return this.idDiaPaciente;
    }
    
    public void setIdDiaPaciente(String idDiaPaciente) {
        this.idDiaPaciente = idDiaPaciente;
    }
    public DiarioPaciente getDiarioPaciente() {
        return this.diarioPaciente;
    }
    
    public void setDiarioPaciente(DiarioPaciente diarioPaciente) {
        this.diarioPaciente = diarioPaciente;
    }
    public Date getFecha() {
        return this.fecha;
    }
    
    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
//    public Set getEstadoAnimos() {
//        return this.estadoAnimos;
//    }
//    
//    public void setEstadoAnimos(Set estadoAnimos) {
//        this.estadoAnimos = estadoAnimos;
//    }




}


