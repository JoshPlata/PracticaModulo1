package PruebasUnitarias;

import DAOSMOD1.CRUD_Rol;
import Entidades.GenRol;
import InstanciarHibernate.HibernateUtil;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class PruCRUD_GENRol {

    public static void main(String[] args) {

        CRUD_Rol crudRol=new CRUD_Rol();
        Session ses=HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx=ses.beginTransaction();
        crudRol.setSesion(ses);
        crudRol.setTx(tx);
        GenRol rol=new GenRol();
        
        rol=crudRol.ObtenerRol("00000000-0000-0000-0000-000000000001");
        
        System.out.println("ROl:"+rol.getNombre());
//        List<GenRol> list=crudRol.ListaRoles();
//        rol.setNombre("Administrador");
//        rol.setDescripcion("Administrador del Sistema sobretodo Para Gestion Psicólogos");
//        
//        
//        rol.setNombre("Psicologo");
//        rol.setDescripcion("Este Rol podrá tener Aceso a los Pacientes propios del Psicólogo");
//        //crudRol.ActualizarRol(rol);
        
        
        
//        rol.setNombre("Paciente33333");
//        rol.setDescripcion("Este podrá tener Acceso a la aplicación del paciente");
//        //crudRol.CrearRol(rol);
//        
//        //
//       // rol.setIdRol(1);
//        String nombrerol=crudRol.ObtenerRol("00000000-0000-0000-0000-000000000000").getNombre();
//        System.out.println("Rol: " +nombrerol);
//        
//        System.out.println("ID \t Rol");
//        for(GenRol Grol:crudRol.ListaRoles())
//        {
//            System.out.println(Grol.getIdRol()+"\t"+Grol.getNombre());
//        }
//        
        //crudRol.EliminarTRol(5);
        System.out.println("Holiwi dijo el kiwi");
        HibernateUtil.shutdown();
    }
    
}
