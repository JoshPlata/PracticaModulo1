/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PruebasUnitarias;

import Procesos.RN.Usuario.ProcesoRNSesionUsuario;

/**
 *
 * @author stile
 */
public class PruebaUnitariaRNSesionUsuario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ProcesoRNSesionUsuario proceso=new ProcesoRNSesionUsuario();
        int a=proceso.iniciarSesion("stilermarco@hotmail.com", "1234","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000001");
        System.out.println(a);
    }
    
}
