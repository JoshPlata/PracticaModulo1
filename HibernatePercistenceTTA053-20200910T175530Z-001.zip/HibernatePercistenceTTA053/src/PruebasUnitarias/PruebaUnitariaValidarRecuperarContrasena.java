/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PruebasUnitarias;

import Procesos.RN.Usuario.ProcesoRNSesionUsuario;


public class PruebaUnitariaValidarRecuperarContrasena {

    public static void main(String[] args) {
        // TODO code application logic here
        ProcesoRNSesionUsuario rnU=new ProcesoRNSesionUsuario();
        boolean resultado=rnU.validaRecuperarContrasena("d308400d-8ce4-4f0e-8c8e-37a20e8e06b3", "988d6c88-6ad8-455f-907d-5d170579757a","stilermarco@hotmail.com");
        
        if(resultado)
        {
        
        }
    }
    
}
