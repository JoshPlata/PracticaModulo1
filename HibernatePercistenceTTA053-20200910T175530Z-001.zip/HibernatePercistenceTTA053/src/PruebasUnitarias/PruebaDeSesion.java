/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PruebasUnitarias;

import DAOSMOD1.CRUD_Rol;
import DAOSMOD1.CRUD_Usuario;
import Entidades.GenRol;
import Entidades.GenUsuario;
import InstanciarHibernate.HibernateUtil;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class PruebaDeSesion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         CRUD_Usuario crudU=new CRUD_Usuario();
         CRUD_Rol crudR=new CRUD_Rol();
         Session ses=HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx=ses.beginTransaction();
        crudU.setSesion(ses);
        crudU.setTx(tx);
        
        crudR.setTx(tx);
        crudR.setSesion(ses);
         GenUsuario usuario=crudU.ObtenerUsuarioporCorreo("stilermarco@hotmail.com");
   
         List<GenRol> roles=crudR.ListaRoles();
        HibernateUtil.shutdown();
         System.out.println("Prueba");
    }
    
}
