
package PruebasUnitarias;

import DAOSMOD1.CRUD_Usuario;
import Entidades.GenCuenta;
import Entidades.GenUsuario;
import InstanciarHibernate.HibernateUtil;
import InstanciarHibernate.InstanciaHibernate;
import java.util.Date;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class PruCRUD_GENUsuario {

    public static void main(String[] args) {
    
    
CRUD_Usuario crudUsuario=new CRUD_Usuario();
Session sesion=HibernateUtil.getSessionFactory().openSession();
Transaction tx=sesion.beginTransaction();
            

        try
        {
        crudUsuario.setSesion(sesion);
        crudUsuario.setTx(tx);
        
        GenUsuario usuario1=crudUsuario.ObtenerUsuarioporCorreo("osvaldo@gmail.com");
        
        HibernateUtil.shutdown();
        
        }catch(HibernateException he)
        {
           if(tx!=null)tx.rollback();
           he.printStackTrace();
           HibernateUtil.shutdown();
           throw new HibernateException("Ocurrió un error en la capa de acceso a datos", he); 
        }
    }
    
}
