
package PruebasUnitarias;

import DAOSMOD1.CRUD_RolUsuario;
import Entidades.GenRolUsuario;
import Entidades.GenRolUsuarioId;
import java.util.List;


public class PruCRUD_GENRolUsuario {

    
    public static void main(String[] args) {
        CRUD_RolUsuario rolUsuario=new CRUD_RolUsuario();
        //GenRolUsuarioId(int idRolfk, int idUsuariofk)
        //rolUsuario.CrearRolUsuario(new GenRolUsuarioId(1,8));
        //rolUsuario.EliminarRolUsuario(new GenRolUsuarioId(1,8));
        //GenRolUsuario rolusuario=rolUsuario.ObtenerRolUsuario(new GenRolUsuarioId(1,8));
         //List<GenRolUsuario> listaRoles=  rolUsuario.ListaRolUsuario("00000000-0000-0000-0000-000000000000");
         
         //for(GenRolUsuario rolusuario:listaRoles)
         {
//             System.out.println("idRol:"+rolusuario.getGenRol().getIdRol()+"Rol:"+rolusuario.getGenRol().getNombre());
         }
         //System.out.println("rolusuario:"+rolusuario.getGenRol().getIdRol()+" idUsuario:"+rolusuario.getGenUsuario().getIdUsuario());
    
    }
    
}
