package PruebasUnitarias;

import Procesos.Persistencia.Genericos.ProcesosConImagenes;
import java.io.FileNotFoundException;
import java.io.IOException;


public class PruImagen {

    
    public static void main(String[] args) throws FileNotFoundException, IOException {
    
        ProcesosConImagenes proceso=new ProcesosConImagenes();
        byte[] Bimage=proceso.convertirImagenaBytes("C:\\Users\\stile\\Pictures\\Programación_binario.jpg");
        proceso.covertirBytesaImagen(Bimage,"C:\\Users\\stile\\Music\\holi.jpg");
    }
    
}   
