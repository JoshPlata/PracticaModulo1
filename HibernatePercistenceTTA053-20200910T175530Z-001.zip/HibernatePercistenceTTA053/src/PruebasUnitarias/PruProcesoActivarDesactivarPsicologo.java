package PruebasUnitarias;

import Proceso.Administrador.ProcesoGestionPsicologo;

public class PruProcesoActivarDesactivarPsicologo {
    public static void main(String[] args) {
            ProcesoGestionPsicologo admin=new ProcesoGestionPsicologo();
           // admin.DesactivarPsicologo("stilermarco@hotmail.com");
            
            admin.ActivarPsicologo("stilermarco@hotmail.com");
    }
    
}
