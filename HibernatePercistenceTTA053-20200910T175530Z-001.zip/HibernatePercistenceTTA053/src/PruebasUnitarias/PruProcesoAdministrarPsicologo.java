package PruebasUnitarias;

import Entidades.GenUsuario;
import Entidades.Psicologo;
import Proceso.Administrador.ProcesoGestionPsicologo;
import java.util.Date;

public class PruProcesoAdministrarPsicologo {

    public static void main(String[] args) {
        
        
        ProcesoGestionPsicologo proAdminPsicologo=new ProcesoGestionPsicologo();
        
        GenUsuario usuario=new GenUsuario();
        usuario.setNombre("Marco Alberto");
        usuario.setApp("Navarro");
        usuario.setApm("Razo");
        usuario.setTel("68343534");
        usuario.setCel("5547607426");
        usuario.setDireccion("Oriente 257 #236 C-1 Col.Agricola Oriental, C.P. 08500.");
        usuario.setFechaNacimiento(new Date("03/05/1995"));
        usuario.setCorreo("stilermarco@hotmail.com");
        usuario.setContrasena("1234");
        
        
        Psicologo psicologo=new Psicologo();
        psicologo.setEspecialidad("Psicólogo General");
        psicologo.setCarrera("Lic. en Psicología");
        psicologo.setAniosexperiencia(2);

       proAdminPsicologo.AgregarPsicologo(usuario, psicologo);


    }
    
}
