/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PruebasUnitarias;

import Cabeceras.CabeceraUsuario;
import Entidades.Paciente;
import Entidades.Psicologo;
import Procesos.Persistencia.Usuario.ProcesoReutilizableUsuario;
import Procesos.RN.Usuario.ProcesoRNSesionUsuario;

/**
 *
 * @author stile
 */
public class PruebaUnitarioaReutilizableUsuario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ProcesoRNSesionUsuario pR= new ProcesoRNSesionUsuario();
        CabeceraUsuario<Psicologo> Ps=pR.ObtenerCabecera("stilermarco@hotmail.com");
        CabeceraUsuario<Paciente>  Pa=pR.ObtenerCabecera("osvaldo@gmail.com");
        if(Ps!=null)
        {
            System.out.println("Holiwiiiii ");
        }
        else
        {
        
        }
    }
    
    
}
