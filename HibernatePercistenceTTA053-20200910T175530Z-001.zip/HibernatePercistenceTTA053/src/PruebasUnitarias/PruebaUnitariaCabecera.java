/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PruebasUnitarias;

import Cabeceras.CabeceraUsuario;
import DAOSMOD1.CRUD_RolUsuario;
import Entidades.GenRol;
import Entidades.GenRolUsuario;
import Entidades.GenRolUsuarioId;
import Entidades.GenUsuario;
import Entidades.Psicologo;
import Procesos.Persistencia.Usuario.ProcesoReutilizableUsuario;
import Procesos.RN.Usuario.ProcesoRNSesionUsuario;
import java.util.List;

/**
 *
 * @author stile
 */
public class PruebaUnitariaCabecera {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        ProcesoReutilizableUsuario pr=new ProcesoReutilizableUsuario();
        ProcesoRNSesionUsuario pro=new ProcesoRNSesionUsuario();


        //Object objeto=pr.obtenerCabecera("eec7fff1-9961-45c5-9908-726794d2bb28");
        Object objeto1=pro.ObtenerCabecera("osvaldo@gmail.com");
        //CabeceraUsuario<Psicologo> cabecera=(CabeceraUsuario<Psicologo>) objeto;
        System.out.println("Holiwi");
    }
    
}
