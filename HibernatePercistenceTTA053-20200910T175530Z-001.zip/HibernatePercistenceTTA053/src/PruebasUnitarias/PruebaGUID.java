/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PruebasUnitarias;

import DAOSMOD1.CRUD_RolUsuario;
import Entidades.GenRolUsuarioId;
import InstanciarHibernate.InstanciaHibernate;
import java.util.UUID;

/**
 *
 * @author stile
 */
public class PruebaGUID {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*CRUD_RolUsuario crudRolUsuario=new CRUD_RolUsuario();
        InstanciaHibernate.iniciaOperacion();
        crudRolUsuario.CrearRolUsuario(new GenRolUsuarioId("00000000-0000-0000-0000-000000000001","eec7fff1-9961-45c5-9908-726794d2bb28"));
        InstanciaHibernate.finalizarOperacion();
        */
        for(int i=0;i<100;i++)
            //36 digitos
        System.out.println(UUID.randomUUID().toString());
        
       
    }
    
}
