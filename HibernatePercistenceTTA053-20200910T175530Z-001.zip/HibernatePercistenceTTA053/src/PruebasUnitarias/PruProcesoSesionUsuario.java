
package PruebasUnitarias;

import InstanciarHibernate.InstanciaHibernate;
import Procesos.RN.Usuario.ProcesoRNSesionUsuario;

/**
 *
 * @author stile
 */
public class PruProcesoSesionUsuario {

    public static void main(String[] args) {
      InstanciaHibernate conexion;
    
        
      conexion=new InstanciaHibernate();
    

        ProcesoRNSesionUsuario p=new ProcesoRNSesionUsuario();
        conexion.iniciaOperacion();
       // p.genRecuperarContrasena("d308400d-8ce4-4f0e-8c8e-37a20e8e06b3");
        conexion.finalizarOperacion();
        //genRecuperarContrasena("d308400d-8ce4-4f0e-8c8e-37a20e8e06b3");



    }
    
}
