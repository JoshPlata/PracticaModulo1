/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PruebasUnitarias;

import DAOSMOD1.CRUD_Cuenta;
import Entidades.GenCuenta;
import InstanciarHibernate.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author stile
 */
public class PruebaUnitariaCuenta {

   
    public static void main(String[] args) {
        CRUD_Cuenta pCuenta=new CRUD_Cuenta();
        Session ses=HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx=ses.beginTransaction();
        pCuenta.setSesion(ses);
        pCuenta.setTx(tx);
        
        GenCuenta cuenta1,cuenta2=new GenCuenta();
        
        cuenta1=pCuenta.ObtenerCuentaUsuario("eec7fff1-9961-45c5-9908-726794d2bb28");
        cuenta2=pCuenta.ObtenerCuenta("d308400d-8ce4-4f0e-8c8e-37a20e8e06b3");
        
        HibernateUtil.shutdown();
        System.out.println("Se pudo Obtener cuenta");
        
    
    }    
    
}
