package PruebasUnitarias;

import Procesos.RN.Usuario.ProcesoRNSesionUsuario;

/**
 *
 * @author stile
 */
public class PriuebaUnitariaModificarContraseña {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ProcesoRNSesionUsuario pRN=new ProcesoRNSesionUsuario();
       boolean estado=pRN.ModificarContrasena("d308400d-8ce4-4f0e-8c8e-37a20e8e06b3","coco","stilermarco@hotmail.com");
        if(estado)
        {
        
        }
        
    }
    
}
