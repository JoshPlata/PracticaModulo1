package DAOSMOD3;



import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;
import Entidades.*;

public class CRUD_Historial {
  
       private Session sesion;
  private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    } 
    public CRUD_Historial()
  {
   }
    public void CrearHistorial(Historial historial) {
           sesion.save(historial);
    }
    public void ActualizarHistorial(Historial historial) {
           sesion.update(historial);
          }

    public Historial ObtenerHistorial(String IdHistorial) {
       Historial historial = null;
            historial = (Historial) sesion.get(Historial.class, IdHistorial);
        return historial;
    }
    public Historial ObtenerHistorialPaciente(String IdPaciente) {
       Historial historial = null;
       String query="SELECT h FROM Historial h "
               + "JOIN FETCH h.diagnostico "
               + "WHERE h.idPacientefk='"+IdPaciente+"'";
       historial = (Historial)sesion.createQuery(query).uniqueResult();
       return historial;
       //diagnostico 
      
    }
    
}