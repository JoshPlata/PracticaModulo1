package DAOSMOD3;



import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;
import Entidades.*;

public class CRUD_AnalisisNeuronal {
    
  private Session sesion;
  private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    }  
  public CRUD_AnalisisNeuronal()
  {
  }
    public void CrearAnalisisNeuronal(AnalisisNeuronal analisisNeuronal) {
            sesion.save(analisisNeuronal);
           
    }

    //Eliminamos Un Usuario
    public void EliminarAnalisisNeuronal(String idAnalisisNeuronal) {
       
            AnalisisNeuronal analisisNeuronal = (AnalisisNeuronal)sesion.get(AnalisisNeuronal.class, idAnalisisNeuronal);
            sesion.delete(analisisNeuronal);
    }

    public void ActualizarAnalisisNeuronal(AnalisisNeuronal analisisNeuronal) {
            sesion.update(analisisNeuronal);
          }

    public AnalisisNeuronal ObtenerAnalisisNeuronal(String IdAnalisisNeuronal) {
        AnalisisNeuronal analisisNeuronal = null;
            analisisNeuronal = (AnalisisNeuronal) sesion.get(AnalisisNeuronal.class, IdAnalisisNeuronal);
        return analisisNeuronal;
    }

  
}