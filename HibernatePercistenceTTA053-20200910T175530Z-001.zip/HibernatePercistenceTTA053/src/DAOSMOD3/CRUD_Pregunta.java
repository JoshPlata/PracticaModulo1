package DAOSMOD3;



import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;
import Entidades.*;

public class CRUD_Pregunta {
 
 private Session sesion;
       private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    }   
    public CRUD_Pregunta()
  {
  }
    public void CrearPregunta(Pregunta pregunta) {
            sesion.save(pregunta);
    }

    //Eliminamos Un Usuario
    public void EliminarPregunta(String idPregunta) {
            Pregunta pregunta = (Pregunta) sesion.get(Pregunta.class, idPregunta);
            sesion.delete(pregunta);
    }

    public void ActualizarPregunta(Pregunta pregunta) {
            sesion.update(pregunta);
          }

    public Pregunta ObtenerPregunta(String IdPregunta) {
        Pregunta pregunta = null;
       pregunta = (Pregunta) sesion.get(Pregunta.class, IdPregunta);
        return pregunta;
    }

    public List<Pregunta> ListaPreguntas(String idSesionConsulta) {
        List<Pregunta> listapreguntas = null;
        String query="SELECT p from Pregunta p "
                + "JOIN FETCH p.sesionConsulta "
                + "where p.sesionConsulta.idSesionConsulta='"+idSesionConsulta+"' order by p.num asc";
        listapreguntas = sesion.createQuery(query).list();
        
        for(int i=0;i<listapreguntas.size();i++){
            Historial historial = new Historial();
            Diagnostico diagnostico = new Diagnostico();
            diagnostico.setResumenDiagnostico("");
            diagnostico.setDiagnostico("");
            historial.setDiagnostico(diagnostico);
            historial.setIdPacientefk("");
            listapreguntas.get(i).getSesionConsulta().setHistorial(historial);
        }    
        return listapreguntas;
    }
}