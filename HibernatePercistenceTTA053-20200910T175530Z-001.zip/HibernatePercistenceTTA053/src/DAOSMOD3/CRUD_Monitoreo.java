package DAOSMOD3;

import org.hibernate.Session;
import org.hibernate.Transaction;
import Entidades.*;

public class CRUD_Monitoreo {
   private Session sesion;
       private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    }  
  public CRUD_Monitoreo()
  {
  }
    public void CrearMonitoreo(Monitoreo monitoreo) {
            sesion.save(monitoreo);
    }
    

    //Eliminamos Un Usuario
    public void EliminarMonitoreo(String idMonitoreo) {
       Monitoreo monitoreo = (Monitoreo) sesion.get(Monitoreo.class, idMonitoreo);
       sesion.delete(monitoreo);
    }

    public void ActualizarMonitoreo(Monitoreo monitoreo) {
          sesion.update(monitoreo);
          }

    public Monitoreo ObtenerMonitoreo(String IdMonitoreo) {
        Monitoreo monitoreo = null;
        monitoreo = (Monitoreo) sesion.get(Monitoreo.class, IdMonitoreo);
        return monitoreo;
    }
    
    public Monitoreo obtenerMonitoreoporIdPregunta(String idPregunta) {
        Monitoreo monitoreo = null;
        String query="SELECT m from Monitoreo m "
                + "JOIN FETCH m.pregunta "
                + "where m.pregunta.idPregunta='"+idPregunta+"'";
        monitoreo = (Monitoreo)sesion.createQuery(query).uniqueResult();
        
        return monitoreo;
    }

}