package DAOSMOD3;



import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;
import Entidades.*;
import OperacionesGenericas.Operaciones_Genericas;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class CRUD_SesionConsulta {
  public CRUD_SesionConsulta()
  {
  }
 private Session sesion;
       private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    } 
  public void CrearSesionConsulta(SesionConsulta sesionConsulta) {
           sesion.save(sesionConsulta);
    }
    //Eliminamos Un Usuario
    public void EliminarSesionConsulta(String idSesionConsulta) {
        SesionConsulta sesionConsulta= (SesionConsulta) sesion.get(SesionConsulta.class, idSesionConsulta);
        sesion.delete(sesionConsulta);
    }

    public void ActualizarSesionConsulta(SesionConsulta sesionConsulta) {
            sesion.update(sesionConsulta);
          }

    public SesionConsulta ObtenerSesionConsulta(String IdSesionConsulta) {
       SesionConsulta sesionConsulta = null;
       sesionConsulta = (SesionConsulta) sesion.get(SesionConsulta.class, IdSesionConsulta);
       return sesionConsulta;
    }

    public SesionConsulta ObtenerSesionConsultaPorCita(String idCita) {
         SesionConsulta sesionConsulta = null;
         sesionConsulta = (SesionConsulta) sesion.createQuery("from SesionConsulta where cita.idCita='"+idCita+"'").uniqueResult();
     
        return sesionConsulta;
    }
      public List<SesionConsulta> ObtenerSesionConsultaPorPaciente(String idPaciente) {
         List<SesionConsulta> listSesionConsulta = null;
         listSesionConsulta = sesion.createQuery("select s from SesionConsulta s "
                 + "JOIN FETCH s.historial "
                 + "where s.idPacientefk='"+idPaciente+"'").list();
         
        for(int i=0;i<listSesionConsulta.size();i++)
        {
            Diagnostico diagnostico=new Diagnostico();
            diagnostico.setDiagnostico("");
            diagnostico.setResumenDiagnostico("");
            Historial historial=listSesionConsulta.get(i).getHistorial();
            historial.setDiagnostico(diagnostico);
            listSesionConsulta.get(i).setHistorial(historial);
        }
        return listSesionConsulta;
    }
      
      public List<SesionConsulta> obtenerSesionesPorDia(Date fecha, String idPsicologo){
          List<SesionConsulta> listaSesionConsulta = new ArrayList<>();
          
          String query = "FROM SesionConsulta WHERE idPsicologofk='"+idPsicologo+"' "
                 + "AND fecha='"+Operaciones_Genericas.formatearFecha(fecha)+"'";
          listaSesionConsulta = sesion.createQuery(query).list();
          return listaSesionConsulta;
          //historial
      }
    

}