package Procesos.RN.SesionConsulta;

import CabecerasSesion.CabeceraHistorial;
import CabecerasSesion.CabeceraSesionConsulta;
import Entidades.Diagnostico;
import Entidades.Historial;
import Entidades.Monitoreo;
import Entidades.Pregunta;
import Entidades.SesionConsulta;
import java.util.ArrayList;
import java.util.List;

public class CabeceraSesionConsultaRN {

    private CabeceraHistorial cabeceraHistorial;
    private CabeceraSesionConsulta cabeceraSesionConsulta;

    public CabeceraHistorial obtenerCabeceraSesionConsulta(String idPaciente) {

        HistorialDiagnosticoRN historialDiagnosticoRN = new HistorialDiagnosticoRN();
        SesionConsultaRN sesionConsultaRN = new SesionConsultaRN();
        List<SesionConsulta> listaSesionConsulta = new ArrayList<>();
        List<CabeceraSesionConsulta> listaCabeceraSesionConsultas = new ArrayList<>();

        cabeceraHistorial = new CabeceraHistorial();

        if (idPaciente != null) {

            Historial historial = historialDiagnosticoRN.obtenerHistorial(idPaciente);
            if (historial != null) {
                cabeceraHistorial.setHistorialPaciente(historial);
                cabeceraHistorial.setDiagnosticoPaciente(historial.getDiagnostico());
                listaSesionConsulta = sesionConsultaRN.obtenerCitasPorPaciente(idPaciente);

                if (listaSesionConsulta != null) {
                    if(listaSesionConsulta.size() != 0){
                    for (SesionConsulta sesionConsulta : listaSesionConsulta) {
                        cabeceraSesionConsulta = new CabeceraSesionConsulta();
                        sesionConsulta.setHistorial(historial);
                        cabeceraSesionConsulta.setSesionConsulta(sesionConsulta);
                        List<Pregunta> listaPreguntas = sesionConsultaRN.listaPreguntasPreconfiguracionSesion(sesionConsulta.getIdSesionConsulta());
                        List<Monitoreo> listaMonitoreo = sesionConsultaRN.listarMonitoreos(listaPreguntas);
                        cabeceraSesionConsulta.setListaPregunta(listaPreguntas);
                        cabeceraSesionConsulta.setListaMonitoreo(listaMonitoreo);
                        listaCabeceraSesionConsultas.add(cabeceraSesionConsulta);
                    }
                    
                    }
                    cabeceraHistorial.setListaCabeceraSesiones(listaCabeceraSesionConsultas);
                }

            }
        }
        return cabeceraHistorial;
    }

}
