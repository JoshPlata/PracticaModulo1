package Procesos.RN.SesionConsulta;

import DAOSMOD3.*;
import Entidades.*;
import InstanciarHibernate.HibernateUtil;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class HistorialDiagnosticoRN {

    public boolean AgregarDiagnosticoEnHistorial(String diagnostico,String resumenDiagnostico, String idPaciente) {
        CRUD_Diagnostico crudDiag = new CRUD_Diagnostico();
        CRUD_Historial crudHisto = new CRUD_Historial();
        
        Session sesion = null ;
        Transaction tx = null;
        boolean status = false;
        try
        {
         
            Diagnostico diag=new Diagnostico();
            diag.setDiagnostico(diagnostico);
            diag.setResumenDiagnostico(resumenDiagnostico);
            sesion = HibernateUtil.getSessionFactory().getCurrentSession();
            tx = sesion.beginTransaction();
            crudDiag.setSesion(sesion);
            crudDiag.setTx(tx);
            crudHisto.setSesion(sesion);
            crudHisto.setTx(tx);
            if (diag != null && !idPaciente.isEmpty())
            {
                if(crudHisto.ObtenerHistorialPaciente(idPaciente) == null)
                {
                crudDiag.CrearDiagnostico(diag);
                Historial historial = new Historial();
                historial.setIdPacientefk(idPaciente);
                historial.setDiagnostico(diag);
                crudHisto.CrearHistorial(historial);
                tx.commit();
                status = true;
                }
            }
        }
        
        catch(HibernateException he)
        {
            
            if(crudDiag.getTx()!=null && crudHisto.getTx()!=null && tx != null )
                    {
                        he.printStackTrace();
                        crudDiag.getTx().rollback();
                        crudHisto.getTx().rollback();
                        tx.rollback();
                    }
        }
        
        finally
        {
            if(crudDiag.getSesion()!=null && crudHisto.getSesion()!=null && sesion != null)
                    {
                        crudDiag.getSesion().close();    
                        crudHisto.getSesion().close();    
                        sesion.close();
                    } 
        }
        
        HibernateUtil.shutdown();
        return status;
    }
     
    public Historial obtenerHistorial(String idPaciente) {
        CRUD_Diagnostico crudDiag = new CRUD_Diagnostico();
        CRUD_Historial crudHisto = new CRUD_Historial();
        Session sesion = null ;
        Transaction tx = null;
        boolean status = false;
        Diagnostico diagnostico;
        Historial historial = null;
        
        try
        {
            
            sesion = HibernateUtil.getSessionFactory().getCurrentSession();
            tx = sesion.beginTransaction();
            crudDiag.setSesion(sesion);
            crudDiag.setTx(tx);
            crudHisto.setSesion(sesion);
            crudHisto.setTx(tx);
            if(idPaciente!=null)
            {
                historial=crudHisto.ObtenerHistorialPaciente(idPaciente);
                
            }
            
            
        }
        
        catch(HibernateException he)
        {
            
            if(crudDiag.getTx()!=null && crudHisto.getTx()!=null && tx != null )
                    {
                        he.printStackTrace();
                        crudDiag.getTx().rollback();
                        crudHisto.getTx().rollback();
                        tx.rollback();
                    }
        }
        
        finally
        {
            if(crudDiag.getSesion()!=null && crudHisto.getSesion()!=null && sesion != null)
                    {
                        crudDiag.getSesion().close();    
                        crudHisto.getSesion().close();    
                        sesion.close();
                    } 
        }
        
        HibernateUtil.shutdown();
       return historial;
    }
    

}