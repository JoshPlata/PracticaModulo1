package Procesos.RN.SesionConsulta;

import DAOSMOD3.CRUD_Monitoreo;
import DAOSMOD3.CRUD_Pregunta;
import DAOSMOD3.CRUD_SesionConsulta;
import Entidades.Historial;
import Entidades.Monitoreo;
import Entidades.Pregunta;
import Entidades.SesionConsulta;
import InstanciarHibernate.HibernateUtil;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.hibernate.HibernateException;
import OperacionesGenericas.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class SesionConsultaRN {

    //METODOS SESION CONSULTA
    public boolean crearSesionConsulta(SesionConsulta sesionConsulta) {
        CRUD_SesionConsulta crudSesionConsulta = new CRUD_SesionConsulta();
        boolean status = false;
        try {
            crudSesionConsulta.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
            crudSesionConsulta.setTx(crudSesionConsulta.getSesion().beginTransaction());

            /*Se verifica que el objeto recibido no sea nulo con todos los campos necesarias para la creacion
                * Fecha
                * Hora
                * Estatus
                * Objetivo
             */
            if (sesionConsulta != null && sesionConsulta.getFecha() != null && sesionConsulta.getHora() != null
                    && sesionConsulta.getObjetivo() != null && sesionConsulta.getObjetivo() != null) {
                // Verificamos que la fecha sea mayor la fecha y hora programada
                if (sesionConsulta.getFecha().after(Calendar.getInstance().getTime())) {
                    sesionConsulta.setHora(sesionConsulta.getFecha());
                    sesionConsulta.setStatusSesion(false);
                    crudSesionConsulta.CrearSesionConsulta(sesionConsulta);
                    crudSesionConsulta.getTx().commit();
                    status = true;
                }
            }

        } catch (HibernateException he) {

            if (crudSesionConsulta.getTx() != null) {
                he.printStackTrace();
                crudSesionConsulta.getTx().rollback();
            }
        } finally {
            if (crudSesionConsulta.getSesion() != null) {
                crudSesionConsulta.getSesion().close();
            }
        }

        HibernateUtil.shutdown();
        return status;
    }

    public boolean modificarSesionConsulta(SesionConsulta sesionConsulta) {
        boolean status = false;
        CRUD_SesionConsulta crud_SesionConsulta = new CRUD_SesionConsulta();
        try {
            if (sesionConsulta != null) {

                crud_SesionConsulta.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
                crud_SesionConsulta.setTx(crud_SesionConsulta.getSesion().beginTransaction());
                crud_SesionConsulta.ActualizarSesionConsulta(sesionConsulta);
                crud_SesionConsulta.getTx().commit();
                status = true;

            }
        } catch (HibernateException he) {
            if (crud_SesionConsulta.getTx() != null) {
                crud_SesionConsulta.getTx().rollback();
            }

        } finally {
            if (crud_SesionConsulta.getSesion() != null) {
                crud_SesionConsulta.getSesion().close();
            }
        }

        HibernateUtil.shutdown();

        return status;
    }
    
    public List<SesionConsulta> obtenerSesionesConsultaPorPsicologo(String idPsicologo, Date citafecha) {
        
        CRUD_SesionConsulta crudSesionConsulta = new CRUD_SesionConsulta();
        List<SesionConsulta> listaSesionConsulta = new ArrayList<>();
                
        Calendar calendarioCita1 = new GregorianCalendar();
        Date citaFecha1 = calendarioCita1.getTime();
        
        try {

            crudSesionConsulta.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
            crudSesionConsulta.setTx(crudSesionConsulta.getSesion().beginTransaction());

            if (idPsicologo != null && citafecha != null) {
                if(citafecha.equals(citaFecha1)){
                    for(SesionConsulta ex: crudSesionConsulta.obtenerSesionesPorDia(citafecha, idPsicologo)){
                        if(ex.getHora().after(citaFecha1)){
                            listaSesionConsulta.add(ex);
                        }
                    }
                }else if(citafecha.after(citaFecha1)){
                    listaSesionConsulta = crudSesionConsulta.obtenerSesionesPorDia(citafecha, idPsicologo);
                }
            }

        } catch (HibernateException he) {

            if (crudSesionConsulta.getTx() != null) {
                he.printStackTrace();
                crudSesionConsulta.getTx().rollback();
            }
        } finally {
            if (crudSesionConsulta.getSesion() != null) {
                crudSesionConsulta.getSesion().close();
            }
        }
        HibernateUtil.shutdown();
        return listaSesionConsulta;
    }

    //Nota importante la fecha se manda con formato yyyy-MM-dd y el Mes es de 0 a 11
    public List<Date> validarHoraCitaSesion(String idPsicologo, String fecha) throws ParseException {

        CRUD_SesionConsulta crud_SesionConsulta = new CRUD_SesionConsulta();
        List<Date> horasDisponible = new ArrayList<>();

        try {

            String[] fechaCompleta = fecha.split("-");

            int dia = Integer.parseInt(fechaCompleta[2]);
            int mes = Integer.parseInt(fechaCompleta[1])-1;
            int anio = Integer.parseInt(fechaCompleta[0]);

            Calendar calendarioCita = new GregorianCalendar(anio, mes, dia);
            Date citaFecha = calendarioCita.getTime();

            crud_SesionConsulta.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
            crud_SesionConsulta.setTx(crud_SesionConsulta.getSesion().beginTransaction());
            List<SesionConsulta> listaSesionConsulta = crud_SesionConsulta.obtenerSesionesPorDia(citaFecha, idPsicologo);

            for (int i = 7; i < 20; i++) {

                Calendar calendarioCita2 = new GregorianCalendar(anio, mes, dia, i, 0, 0);
                Date horasCitas = calendarioCita2.getTime();
                horasDisponible.add(horasCitas);
                
            }

            for (SesionConsulta sesionConsulta : listaSesionConsulta) {

                Calendar calendarioCita3 = new GregorianCalendar(
                        sesionConsulta.getFecha().getYear() + 1900,
                        sesionConsulta.getFecha().getMonth(),
                        sesionConsulta.getFecha().getDate(),
                        sesionConsulta.getHora().getHours(),
                        sesionConsulta.getHora().getMinutes(),
                        sesionConsulta.getHora().getSeconds());
                Date horaOcupada = calendarioCita3.getTime();

                if (horasDisponible.contains(horaOcupada)) {
                    horasDisponible.remove(horaOcupada);
                }

            }
        } catch (HibernateException he) {
            if (crud_SesionConsulta.getTx() != null) {
                crud_SesionConsulta.getTx().rollback();
            }

        } finally {
            if (crud_SesionConsulta.getSesion() != null) {
                crud_SesionConsulta.getSesion().close();
            }
        }

        HibernateUtil.shutdown();
        return horasDisponible;
    }

    public List<SesionConsulta> obtenerCitasPorPaciente(String idPaciente) {
        CRUD_SesionConsulta crudSesionConsulta = new CRUD_SesionConsulta();
        List<SesionConsulta> listaSesionConsulta = new ArrayList<>();
        try {

            crudSesionConsulta.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
            crudSesionConsulta.setTx(crudSesionConsulta.getSesion().beginTransaction());

            if (idPaciente != null) {
                listaSesionConsulta = crudSesionConsulta.ObtenerSesionConsultaPorPaciente(idPaciente);
            }

        } catch (HibernateException he) {

            if (crudSesionConsulta.getTx() != null) {
                he.printStackTrace();
                crudSesionConsulta.getTx().rollback();
            }
        } finally {
            if (crudSesionConsulta.getSesion() != null) {
                crudSesionConsulta.getSesion().close();
            }
        }
        HibernateUtil.shutdown();
        return listaSesionConsulta;
    }

    // METODOS PRECONFIGURACION
    public boolean iniciarPreconfiguracionSesion(List<Pregunta> listaPreguntas) {
        CRUD_Pregunta crudPregunta = new CRUD_Pregunta();
        boolean status = false;
        try {

            if (listaPreguntas != null && listaPreguntas.size() != 0) {
                crudPregunta.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
                crudPregunta.setTx(crudPregunta.getSesion().beginTransaction());
                int i = crudPregunta.ListaPreguntas(listaPreguntas.get(0).getSesionConsulta().getIdSesionConsulta()).size();
                crudPregunta.getSesion().close();
                crudPregunta.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
                crudPregunta.setTx(crudPregunta.getSesion().beginTransaction());
                for (Pregunta pregunta : listaPreguntas) {
                    pregunta.setNum(i + 1);
                    crudPregunta.CrearPregunta(pregunta);
                    i++;
                }
                crudPregunta.getTx().commit();
                status = true;
            }
        } catch (HibernateException he) {

            if (crudPregunta.getTx() != null) {
                he.printStackTrace();
                crudPregunta.getTx().rollback();
            }
        } finally {
            if (crudPregunta.getSesion() != null) {
                crudPregunta.getSesion().close();
            }
        }

        HibernateUtil.shutdown();
        return status;
    }

    public boolean modificarPreconfiguracionSesion(List<Pregunta> listaPreguntas) {
        CRUD_Pregunta crudPregunta = new CRUD_Pregunta();
        boolean status = false;

        try {

            if (listaPreguntas != null && listaPreguntas.size() != 0) {
                crudPregunta.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
                crudPregunta.setTx(crudPregunta.getSesion().beginTransaction());
                int i = crudPregunta.ListaPreguntas(listaPreguntas.get(0).getSesionConsulta().getIdSesionConsulta()).size();
                crudPregunta.getSesion().close();
                crudPregunta.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
                crudPregunta.setTx(crudPregunta.getSesion().beginTransaction());
                int j = 0;
                for (Pregunta pregunta : listaPreguntas) {
                    pregunta.setNum(j + 1);
                    crudPregunta.ActualizarPregunta(pregunta);
                    j++;
                }
                crudPregunta.getTx().commit();
                status = true;
            }
        } catch (HibernateException he) {

            if (crudPregunta.getTx() != null) {
                he.printStackTrace();
                crudPregunta.getTx().rollback();
            }
        } finally {
            if (crudPregunta.getSesion() != null) {
                crudPregunta.getSesion().close();
            }
        }

        HibernateUtil.shutdown();
        return status;
    }

    public boolean elimarPreguntasPreconfiguracionSesion(List<String> listPregunta, String idSesionConsulta) {
        CRUD_Pregunta crudPregunta = new CRUD_Pregunta();
        boolean status = false;

        try {

            crudPregunta.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
            crudPregunta.setTx(crudPregunta.getSesion().beginTransaction());

            if (listPregunta != null && listPregunta.size() != 0) {
                for (String idPregunta : listPregunta) {
                    crudPregunta.EliminarPregunta(idPregunta);
                }

                crudPregunta.getTx().commit();
                crudPregunta.getSesion().close();

                crudPregunta.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
                crudPregunta.setTx(crudPregunta.getSesion().beginTransaction());

                List<Pregunta> listaPreguntas = crudPregunta.ListaPreguntas(idSesionConsulta);
                crudPregunta.getSesion().close();

                status = modificarPreconfiguracionSesion(listaPreguntas);
            }
        } catch (HibernateException he) {

            if (crudPregunta.getTx() != null) {
                he.printStackTrace();
                crudPregunta.getTx().rollback();
            }
        } finally {
            if (crudPregunta.getSesion() != null) {
                crudPregunta.getSesion().close();
            }
        }
        HibernateUtil.shutdown();
        return status;
    }

    public List<Pregunta> listaPreguntasPreconfiguracionSesion(String idSesionConsulta) {
        CRUD_Pregunta crudPregunta = new CRUD_Pregunta();
        List<Pregunta> listaPreguntas = new ArrayList<>();
        try {

            crudPregunta.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
            crudPregunta.setTx(crudPregunta.getSesion().beginTransaction());

            if (idSesionConsulta != null) {
                listaPreguntas = crudPregunta.ListaPreguntas(idSesionConsulta);
            }

        } catch (HibernateException he) {

            if (crudPregunta.getTx() != null) {
                he.printStackTrace();
                crudPregunta.getTx().rollback();
            }
        } finally {
            if (crudPregunta.getSesion() != null) {
                crudPregunta.getSesion().close();
            }
        }
        HibernateUtil.shutdown();
        return listaPreguntas;
    }

    //METODOS MONITOREO
    public boolean crearMonitoreo(List<Monitoreo> preguntaMonitoreo) {

        CRUD_Monitoreo crudMonitoreo = new CRUD_Monitoreo();
        boolean status = false;

        try {

            crudMonitoreo.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
            crudMonitoreo.setTx(crudMonitoreo.getSesion().beginTransaction());

            if (preguntaMonitoreo != null && preguntaMonitoreo.size() != 0) {
                for (Monitoreo pMonitoreo : preguntaMonitoreo) {
                    crudMonitoreo.CrearMonitoreo(pMonitoreo);
                }
                crudMonitoreo.getTx().commit();
                status = true;
            }

        } catch (HibernateException he) {
            if (crudMonitoreo.getTx() != null) {
                crudMonitoreo.getTx().rollback();
            }

        } finally {
            if (crudMonitoreo.getSesion() != null) {
                crudMonitoreo.getSesion().close();
            }
        }

        HibernateUtil.shutdown();
        return status;
    }

    public List<Monitoreo> listarMonitoreos(List<Pregunta> listaPreguntas) {

        CRUD_Monitoreo crudMonitoreo = new CRUD_Monitoreo();
        CRUD_SesionConsulta crudSesionConsulta = new CRUD_SesionConsulta();
        List<Monitoreo> preguntasMonitoreadas = new ArrayList<>();

        try {

            crudMonitoreo.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
            crudMonitoreo.setTx(crudMonitoreo.getSesion().beginTransaction());
            crudSesionConsulta.setSesion(crudMonitoreo.getSesion());
            crudSesionConsulta.setTx(crudMonitoreo.getTx());
            if (listaPreguntas != null && listaPreguntas.size() != 0) {
                for (Pregunta pregunta : listaPreguntas) {
                    Monitoreo monitoreo = crudMonitoreo.obtenerMonitoreoporIdPregunta(pregunta.getIdPregunta());
                    if (monitoreo != null) {
                        preguntasMonitoreadas.add(monitoreo);
                    }
                }
            }
        } catch (HibernateException he) {
            if (crudMonitoreo.getTx() != null) {
                crudMonitoreo.getTx().rollback();
            }

        } finally {
            if (crudMonitoreo.getSesion() != null) {
                crudMonitoreo.getSesion().close();
            }
        }

        HibernateUtil.shutdown();
        //Se hace con el Objetivo que no nos rellene valores null
        for (int i = 0; i < preguntasMonitoreadas.size(); i++) {
            Historial historial = new Historial();
            historial.setIdPacientefk("");
            SesionConsulta sesionConsulta = new SesionConsulta();
            sesionConsulta.setHistorial(historial);
            sesionConsulta.setObjetivo("");
            sesionConsulta.setDescripcion("");
            sesionConsulta.setIdPacientefk("");
            sesionConsulta.setIdPsicologofk("");
            sesionConsulta.setObjetivoCumplido(false);
            sesionConsulta.setResumen("");
            sesionConsulta.setFecha(new Date());
            sesionConsulta.setHora(new Date());
            sesionConsulta.setTiempo(new Date());
            sesionConsulta.setStatusSesion(false);
            preguntasMonitoreadas.get(i).getPregunta().setSesionConsulta(sesionConsulta);
        }
        return preguntasMonitoreadas;
    }

    public boolean eliminarSesionConsulta(String idSesionConsulta) {
       boolean status = false;
        CRUD_SesionConsulta crud_SesionConsulta= new CRUD_SesionConsulta();
        try{
            if(idSesionConsulta!=null)
            {
                
                crud_SesionConsulta.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
                crud_SesionConsulta.setTx(crud_SesionConsulta.getSesion().beginTransaction());
                crud_SesionConsulta.EliminarSesionConsulta(idSesionConsulta);
                crud_SesionConsulta.getTx().commit();
                status = true;
                
            }
           } catch (HibernateException he) {
            if (crud_SesionConsulta.getTx() != null) {
                crud_SesionConsulta.getTx().rollback();
            }

        } finally {
            if (crud_SesionConsulta.getSesion() != null) {
                crud_SesionConsulta.getSesion().close();
            }
        }

        HibernateUtil.shutdown();
        
        return status;
    }
}
