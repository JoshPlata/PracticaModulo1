package Procesos.RN.Paciente.Diario;

import InstanciarHibernate.HibernateUtil;
import CabeceraDiario.CabeceraDia;
import CabeceraDiario.CabeceraDiarioPaciente;
import DAOSMOD2.*;
import Entidades.*;
import java.util.ArrayList;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.Date;
import java.util.List;

public class ProcesoRNDiarioEstados {

    public boolean agregarDiarioPaciente(String idPaciente, String estado,
            String accion, String comentario) {

        CRUD_DiarioPaciente crudDiario = new CRUD_DiarioPaciente();
        CRUD_DiaPaciente crudDia = new CRUD_DiaPaciente();
        CRUD_EstadoAnimo crudEstado = new CRUD_EstadoAnimo();
        CRUD_AccionRealizada crudAccion = new CRUD_AccionRealizada();
        AccionRealizada accionRealizada;
        EstadoAnimo estadoAnimo;

        boolean status = false;

        Session sesion = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = sesion.beginTransaction();
        crudDiario.setSesion(sesion);

        crudDiario.setTx(tx);
        crudDia.setSesion(sesion);
        crudDia.setTx(tx);
        crudEstado.setSesion(sesion);
        crudEstado.setTx(tx);
        crudAccion.setSesion(sesion);
        crudAccion.setTx(tx);

        try {
            //Si no existe el diario se procede a crearlo...
//        DiarioPaciente diarioPrueba = crudDiario.ObtenerDiarioPaciente(idPaciente);
//        System.out.println(diarioPrueba.getIdDiarioPaciente());

            DiarioPaciente diarioPaciente = null;

            if (crudDiario.ObtenerDiarioPaciente(idPaciente) == null) {
                diarioPaciente = new DiarioPaciente();
                diarioPaciente.setNombre("Diario TCC");
                diarioPaciente.setIdPaciente(idPaciente);
                crudDiario.CrearDiarioPaciente(diarioPaciente);

                //False no existe el dia y se procede a crear...
                if (crudDia.validarDia(new Date(), diarioPaciente.getIdDiarioPaciente()) == false) {
                    DiaPaciente diaPaciente = new DiaPaciente();
                    diaPaciente.setDiarioPaciente(diarioPaciente);
                    diaPaciente.setFecha(new Date());
                    crudDia.CrearDiaPaciente(diaPaciente);

                    estadoAnimo = new EstadoAnimo();
                    estadoAnimo.setDiaPaciente(diaPaciente);
                    estadoAnimo.setNombre(estado);
                    crudEstado.CrearEstadoAnimo(estadoAnimo);

                    accionRealizada = new AccionRealizada(estadoAnimo);
                    accionRealizada.setComentario(comentario);
                    accionRealizada.setAccion(accion);
                    crudAccion.CrearAccionRealizada(accionRealizada);
                }
                crudDiario.getTx().commit();
            } else {
                diarioPaciente = crudDiario.ObtenerDiarioPaciente(idPaciente);
                //False no existe el dia y se procede a crear...
                DiaPaciente diaPaciente = null;

                if (crudDia.validarDia(new Date(), diarioPaciente.getIdDiarioPaciente()) == false) {
                    diaPaciente = new DiaPaciente();
                    diaPaciente.setDiarioPaciente(diarioPaciente);
                    diaPaciente.setFecha(new Date());
                    crudDia.CrearDiaPaciente(diaPaciente);

                    estadoAnimo = new EstadoAnimo();
                    estadoAnimo.setDiaPaciente(diaPaciente);
                    estadoAnimo.setNombre(estado);
                    crudEstado.CrearEstadoAnimo(estadoAnimo);

                    accionRealizada = new AccionRealizada(estadoAnimo);
                    accionRealizada.setComentario(comentario);
                    accionRealizada.setAccion(accion);
                    crudAccion.CrearAccionRealizada(accionRealizada);
                } else {
                    diaPaciente = crudDia.obtenerDiaPacientePorFecha(new Date(), diarioPaciente.getIdDiarioPaciente());
                    estadoAnimo = new EstadoAnimo();
                    estadoAnimo.setDiaPaciente(diaPaciente);
                    estadoAnimo.setNombre(estado);
                    crudEstado.CrearEstadoAnimo(estadoAnimo);

                    accionRealizada = new AccionRealizada(estadoAnimo);
                    accionRealizada.setComentario(comentario);
                    accionRealizada.setAccion(accion);
                    crudAccion.CrearAccionRealizada(accionRealizada);
                }
                crudDiario.getTx().commit();
            }
            status = true;
            //Hay Diario para el paciente?
            //Agregamos Diario
        } catch (HibernateException he) {
            if (crudDiario.getTx() != null
                    && crudDia.getTx() != null
                    && crudEstado.getTx() != null
                    && crudAccion.getTx() != null) {
                crudDiario.getTx().rollback();
                crudDia.getTx().rollback();
                crudEstado.getTx().rollback();
                crudAccion.getTx().rollback();

            }
            //Creamos Diario

        } finally {
            if (crudDiario.getSesion() != null
                    && crudDia.getSesion() != null
                    && crudEstado.getSesion() != null
                    && crudAccion.getSesion() != null) {
                crudDiario.getSesion().close();
                crudDia.getSesion().close();
                crudEstado.getSesion().close();
                crudAccion.getSesion().close();
            }
        }
        HibernateUtil.shutdown();
        return status;
    }

    public CabeceraDiarioPaciente mostrarDiarioPaciente(String idPaciente) {
        //RestCabeceraDiarioPaciente restCabeceraDiarioPaciente = new RestCabeceraDiarioPaciente();

        CabeceraDiarioPaciente diarioPacienteC = new CabeceraDiarioPaciente();
        CabeceraDia diasEstadosAccionesC = new CabeceraDia();
        CRUD_DiarioPaciente crudDiarioPaciente = new CRUD_DiarioPaciente();
        CRUD_DiaPaciente crudDiaPaciente = new CRUD_DiaPaciente();
        CRUD_EstadoAnimo crudEstadoAnimo = new CRUD_EstadoAnimo();
        CRUD_AccionRealizada crudAccionRealizada = new CRUD_AccionRealizada();

        try {

            Session sesion = HibernateUtil.getSessionFactory().getCurrentSession();
            Transaction Tx = sesion.beginTransaction();

            crudDiarioPaciente.setSesion(sesion);
            crudDiarioPaciente.setTx(Tx);
            crudDiaPaciente.setSesion(sesion);
            crudDiaPaciente.setTx(Tx);
            crudEstadoAnimo.setSesion(sesion);
            crudEstadoAnimo.setTx(Tx);
            crudAccionRealizada.setSesion(sesion);
            crudAccionRealizada.setTx(Tx);

            DiarioPaciente diarioPaciente = crudDiarioPaciente.ObtenerDiarioPaciente(idPaciente);
            diarioPacienteC.setDiario(diarioPaciente);

            List<DiaPaciente> listaDiasPaciente = crudDiaPaciente.ListaDiaPaciente(diarioPaciente.getIdDiarioPaciente());
            List<CabeceraDia> listaCabeceraDia = new ArrayList<CabeceraDia>();

            for (int i = 0; i < listaDiasPaciente.size(); i++) {
                String id = listaDiasPaciente.get(i).getIdDiaPaciente();
                List<EstadoAnimo> estadosAnimo = crudEstadoAnimo.ListaEstadosAnimoPorDia(id);
                List<AccionRealizada> acciones = new ArrayList<AccionRealizada>();
                //= crudAccionRealizada.obtenerAccionesEstados(idEstadoAnimo);
                for (int j = 0; j < estadosAnimo.size(); j++) {
                    acciones.add(crudAccionRealizada.obtenerAccionesEstados(estadosAnimo.get(j).getIdEstadoAnimo()));
                }
                CabeceraDia cabeceraDia = new CabeceraDia();
                cabeceraDia.setDia(listaDiasPaciente.get(i));
                cabeceraDia.setAccionesEstado(acciones);
                cabeceraDia.setEstadosDia(estadosAnimo);
                listaCabeceraDia.add(cabeceraDia);
            }
            diarioPacienteC.setDias(listaCabeceraDia);
            //restCabeceraDiarioPaciente.setCabeceraDiarioPaciente(diarioPacienteC);
        } catch (HibernateException he) {
            if (crudDiarioPaciente.getTx() != null
                    && crudDiaPaciente.getTx() != null
                    && crudEstadoAnimo.getTx() != null
                    && crudAccionRealizada.getTx() != null) {
                crudDiarioPaciente.getTx().rollback();
                crudDiaPaciente.getTx().rollback();
                crudEstadoAnimo.getTx().rollback();
                crudAccionRealizada.getTx().rollback();

            }
            //Creamos Diario
        } finally {
            if (crudDiarioPaciente.getSesion() != null
                    && crudDiaPaciente.getSesion() != null
                    && crudEstadoAnimo.getSesion() != null
                    && crudAccionRealizada.getSesion() != null) {
                crudDiarioPaciente.getSesion().close();
                crudDiaPaciente.getSesion().close();
                crudEstadoAnimo.getSesion().close();
                crudAccionRealizada.getSesion().close();
            }
        }
        HibernateUtil.shutdown();
        return diarioPacienteC;
        // return restCabeceraDiarioPaciente;
    }

    public CabeceraDiarioPaciente mostrarDiarioPacienteMes(String idPaciente, int mes, int anio) {
        //RestCabeceraDiarioPaciente restCabeceraDiarioPaciente = new RestCabeceraDiarioPaciente();

        CabeceraDiarioPaciente diarioPacienteC = new CabeceraDiarioPaciente();
        CabeceraDia diasEstadosAccionesC = new CabeceraDia();
        CRUD_DiarioPaciente crudDiarioPaciente = new CRUD_DiarioPaciente();
        CRUD_DiaPaciente crudDiaPaciente = new CRUD_DiaPaciente();
        CRUD_EstadoAnimo crudEstadoAnimo = new CRUD_EstadoAnimo();
        CRUD_AccionRealizada crudAccionRealizada = new CRUD_AccionRealizada();

        try {
            Session sesion = HibernateUtil.getSessionFactory().getCurrentSession();
            Transaction Tx = sesion.beginTransaction();

            crudDiarioPaciente.setSesion(sesion);
            crudDiarioPaciente.setTx(Tx);
            crudDiaPaciente.setSesion(sesion);
            crudDiaPaciente.setTx(Tx);
            crudEstadoAnimo.setSesion(sesion);
            crudEstadoAnimo.setTx(Tx);
            crudAccionRealizada.setSesion(sesion);
            crudAccionRealizada.setTx(Tx);

            DiarioPaciente diarioPaciente = crudDiarioPaciente.ObtenerDiarioPaciente(idPaciente);
            diarioPacienteC.setDiario(diarioPaciente);

            List<DiaPaciente> listaDiasPaciente = crudDiaPaciente.ListaDiaPacienteMes(diarioPaciente.getIdDiarioPaciente(), mes, anio);
            List<CabeceraDia> listaCabeceraDia = new ArrayList<CabeceraDia>();

            for (int i = 0; i < listaDiasPaciente.size(); i++) {
                String id = listaDiasPaciente.get(i).getIdDiaPaciente();
                List<EstadoAnimo> estadosAnimo = crudEstadoAnimo.ListaEstadosAnimoPorDia(id);
                List<AccionRealizada> acciones = new ArrayList<AccionRealizada>();
                for (int j = 0; j < estadosAnimo.size(); j++) {
                    acciones.add(crudAccionRealizada.obtenerAccionesEstados(estadosAnimo.get(j).getIdEstadoAnimo()));
                }
                CabeceraDia cabeceraDia = new CabeceraDia();
                cabeceraDia.setDia(listaDiasPaciente.get(i));
                cabeceraDia.setAccionesEstado(acciones);
                cabeceraDia.setEstadosDia(estadosAnimo);
                listaCabeceraDia.add(cabeceraDia);
            }
            diarioPacienteC.setDias(listaCabeceraDia);
            //restCabeceraDiarioPaciente.setCabeceraDiarioPaciente(diarioPacienteC);
        } catch (HibernateException he) {
            if (crudDiarioPaciente.getTx() != null
                    && crudDiaPaciente.getTx() != null
                    && crudEstadoAnimo.getTx() != null
                    && crudAccionRealizada.getTx() != null) {
                crudDiarioPaciente.getTx().rollback();
                crudDiaPaciente.getTx().rollback();
                crudEstadoAnimo.getTx().rollback();
                crudAccionRealizada.getTx().rollback();

            }
            //Creamos Diario
        } finally {
            if (crudDiarioPaciente.getSesion() != null
                    && crudDiaPaciente.getSesion() != null
                    && crudEstadoAnimo.getSesion() != null
                    && crudAccionRealizada.getSesion() != null) {
                crudDiarioPaciente.getSesion().close();
                crudDiaPaciente.getSesion().close();
                crudEstadoAnimo.getSesion().close();
                crudAccionRealizada.getSesion().close();
            }
        }
        HibernateUtil.shutdown();
        return diarioPacienteC;
    }

    public CabeceraDiarioPaciente mostrarDiarioPacienteRango(String idPaciente, Date ini, Date fin) {
        //RestCabeceraDiarioPaciente restCabeceraDiarioPaciente = new RestCabeceraDiarioPaciente();

        CabeceraDiarioPaciente diarioPacienteC = new CabeceraDiarioPaciente();
        CabeceraDia diasEstadosAccionesC = new CabeceraDia();
        CRUD_DiarioPaciente crudDiarioPaciente = new CRUD_DiarioPaciente();
        CRUD_DiaPaciente crudDiaPaciente = new CRUD_DiaPaciente();
        CRUD_EstadoAnimo crudEstadoAnimo = new CRUD_EstadoAnimo();
        CRUD_AccionRealizada crudAccionRealizada = new CRUD_AccionRealizada();

        try {
            Session sesion = HibernateUtil.getSessionFactory().getCurrentSession();
            Transaction Tx = sesion.beginTransaction();

            crudDiarioPaciente.setSesion(sesion);
            crudDiarioPaciente.setTx(Tx);
            crudDiaPaciente.setSesion(sesion);
            crudDiaPaciente.setTx(Tx);
            crudEstadoAnimo.setSesion(sesion);
            crudEstadoAnimo.setTx(Tx);
            crudAccionRealizada.setSesion(sesion);
            crudAccionRealizada.setTx(Tx);

            DiarioPaciente diarioPaciente = crudDiarioPaciente.ObtenerDiarioPaciente(idPaciente);
            diarioPacienteC.setDiario(diarioPaciente);

            List<DiaPaciente> listaDiasPaciente = crudDiaPaciente.ListaDiaPacienteRangoFechas(diarioPaciente.getIdDiarioPaciente(), ini, fin);
            List<CabeceraDia> listaCabeceraDia = new ArrayList<CabeceraDia>();

            for (int i = 0; i < listaDiasPaciente.size(); i++) {
                String id = listaDiasPaciente.get(i).getIdDiaPaciente();
                List<EstadoAnimo> estadosAnimo = crudEstadoAnimo.ListaEstadosAnimoPorDia(id);
                List<AccionRealizada> acciones = new ArrayList<AccionRealizada>();
                for (int j = 0; j < estadosAnimo.size(); j++) {
                    acciones.add(crudAccionRealizada.obtenerAccionesEstados(estadosAnimo.get(j).getIdEstadoAnimo()));
                }
                CabeceraDia cabeceraDia = new CabeceraDia();
                cabeceraDia.setDia(listaDiasPaciente.get(i));
                cabeceraDia.setAccionesEstado(acciones);
                cabeceraDia.setEstadosDia(estadosAnimo);
                listaCabeceraDia.add(cabeceraDia);
            }
            
            diarioPacienteC.setDias(listaCabeceraDia);
            if(listaCabeceraDia.size()==0)
            {
                diarioPacienteC=null;
            }

            //restCabeceraDiarioPaciente.setCabeceraDiarioPaciente(diarioPacienteC);
        } catch (HibernateException he) {
            if (crudDiarioPaciente.getTx() != null
                    && crudDiaPaciente.getTx() != null
                    && crudEstadoAnimo.getTx() != null
                    && crudAccionRealizada.getTx() != null) {
                crudDiarioPaciente.getTx().rollback();
                crudDiaPaciente.getTx().rollback();
                crudEstadoAnimo.getTx().rollback();
                crudAccionRealizada.getTx().rollback();

            }
            //Creamos Diario
        } finally {
            if (crudDiarioPaciente.getSesion() != null
                    && crudDiaPaciente.getSesion() != null
                    && crudEstadoAnimo.getSesion() != null
                    && crudAccionRealizada.getSesion() != null) {
                crudDiarioPaciente.getSesion().close();
                crudDiaPaciente.getSesion().close();
                crudEstadoAnimo.getSesion().close();
                crudAccionRealizada.getSesion().close();
            }
        }
        HibernateUtil.shutdown();
        return diarioPacienteC;
    }
}
