package Procesos.RN.Paciente;

import DAOSMOD1.CRUD_Paciente;
import Procesos.RN.Psicologo.*;
import DAOSMOD1.CRUD_Psicologo;
import DAOSMOD1.CRUD_Usuario;
import Entidades.GenUsuario;
import Entidades.Paciente;
import Entidades.Psicologo;
import InstanciarHibernate.HibernateUtil;
import InstanciarHibernate.InstanciaHibernate;
import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class ProcesoRNGestionCuentaPropiaPaciente {

  private Session sesion;
       private Transaction tx;

    public Session getSesion() {
        return sesion;
    }

    public void setSesion(Session sesion) {
        this.sesion = sesion;
    }

    public Transaction getTx() {
        return tx;
    }

    public void setTx(Transaction tx) {
        this.tx = tx;
    }   
    public void ActualizarInformacion(GenUsuario user,Paciente paciente)
    {
        CRUD_Usuario crudUser=new CRUD_Usuario();
        CRUD_Paciente crudPac=new CRUD_Paciente();
       
        Session ses=HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx=ses.beginTransaction();
       
        crudUser.setSesion(ses);
        crudUser.setTx(tx);
        crudPac.setSesion(ses);
        crudPac.setTx(tx);
        
        try
        {
            crudUser.ActualizarUsuario(user);
            crudPac.ActualizarPaciente(paciente);
            tx.commit();
            HibernateUtil.shutdown();
        }catch(HibernateException he)
        {
           if(tx!=null)tx.rollback();
           he.printStackTrace();
           HibernateUtil.shutdown();
           throw new HibernateException("Ocurrió un error en la capa de acceso a datos", he); 
            
        }
    }
    public void ActualizarContrasena(String IdUsuario,String password)
    {
        CRUD_Usuario crudUser=new CRUD_Usuario();
        Session ses=HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx=ses.beginTransaction();
        crudUser.setSesion(ses);
        crudUser.setTx(tx);
        try
        {
            GenUsuario user=crudUser.ObtenerUsuario(IdUsuario);
            user.setContrasena(password);
            crudUser.ActualizarUsuario(user);
            tx.commit();
            HibernateUtil.shutdown();
        }catch(HibernateException he)
        {
              if(tx!=null)tx.rollback();
           he.printStackTrace();
           HibernateUtil.shutdown();
           throw new HibernateException("Ocurrió un error en la capa de acceso a datos", he); 
        }
    }
    public void SubirFotoPerfil(byte [] foto,String IdUsuario)
    {
         CRUD_Usuario crudUser=new CRUD_Usuario();
         Session ses=HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx=ses.beginTransaction();
        crudUser.setSesion(ses);
        crudUser.setTx(tx);
        try
        {
            GenUsuario user=crudUser.ObtenerUsuario(IdUsuario);
            user.setFoto(foto);
            crudUser.ActualizarUsuario(user);
            tx.commit();
            HibernateUtil.shutdown();
        }catch(HibernateException he)
        {
               if(tx!=null)tx.rollback();
           he.printStackTrace();
           HibernateUtil.shutdown();
           throw new HibernateException("Ocurrió un error en la capa de acceso a datos", he);
        }
        
    }
    
}
