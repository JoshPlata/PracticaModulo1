
package Procesos.RN.Usuario;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class ProcesoRNEnviarCorreo {
    
      private Properties props;
      private Session session;
      private Message message;
      // Sender's email ID needs to be mentioned
      final String from = "tta0532017@gmail.com";
      final String password="ESCOM2014630346.";
      
      public String to = "";
      public String subjet="";
      public String mensaje="";
      
      public ProcesoRNEnviarCorreo()
      {
          props = new Properties();
          
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
                props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		
      }
      
      
      public void enviarCorreo(String to,String subject,String mensaje)
      {
          session = Session.getInstance(props,
		  new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(from,password);
			}
		  });
          this.to=to;
          this.subjet=subject;
          this.mensaje=mensaje;
          
          try
          {
              message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.setRecipients(Message.RecipientType.TO,
				InternetAddress.parse(to));
			message.setSubject(subject);
			message.setContent(mensaje,"text/html");

			Transport.send(message);

			System.out.println("Mensaje Enviado...");
              

          }catch(MessagingException e)
          {
              throw new RuntimeException(e);
          }
      
          
      }
      
   
      public void enviarCorreoRecuContrasena(String to,String CodContrasena,String idCuenta,String fechLim,String correo)
      {
          String asunto="Recuperación Contraseña TTA053";
          String mensaje="<p>"
                  + "Para cambiar su contraseña es necesario darle click en Recuperar Contraseña<br>"
                  +"<a href=\"http://tt.solutionsmx.com/ws/Sesion/RecuperarContrasena/'"+CodContrasena+"','"+idCuenta+"','"+correo+"'\">Recuperar Contrasena</a>"
                  + "Este es un link que le rediccionara para que pueda restablecer su contraseña.<br>"
                  + "<br><h3>Su Fecha limite para restablecer Contraseña es</h3>"
                  + "<br><h4>"+fechLim+"</h4>"
                  + "</p>";
          enviarCorreo(to,asunto,mensaje);
      
      }
    
}
    

