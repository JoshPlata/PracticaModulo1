package Procesos.RN.Usuario;

import Cabeceras.CabeceraUsuario;
import DAOSMOD1.CRUD_CodigoReContrasena;
import DAOSMOD1.CRUD_Cuenta;
import DAOSMOD1.CRUD_Sesion;
import DAOSMOD1.CRUD_Usuario;
import Entidades.GenCodigoReContrasena;
import Entidades.GenCuenta;
import Entidades.GenCuentaAplicacion;
import Entidades.GenRolUsuario;
import Entidades.GenUsuario;
import Entidades.Paciente;
import Entidades.Psicologo;
import Entidades.Sesion;
import InstanciarHibernate.HibernateUtil;
import InstanciarHibernate.InstanciaHibernate;
import Procesos.Persistencia.Genericos.ProcesoGeneradorCodigos;
import Procesos.Persistencia.Usuario.ProcesoReutilizableUsuario;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class ProcesoRNSesionUsuario {

    /*
        Retorna 0 cuando correo y contrasena no esta registrado o se encuentra activo
        Retorna -1 cuando se equivoco en correo o contraseña
        Retorna -2 Cuando la Aplicacio no tiene Acceso
        Retorna -3 Cuando el usuario no tiene el Rol
        Retorna 1000 Error en el Servidor
        Retorna 1 cuando se encuentran correctos
     */
    public int iniciarSesion(String correo, String contrasena, String idAplicacion, String idRol) {
        ProcesoReutilizableUsuario proceso = new ProcesoReutilizableUsuario();
        CRUD_Sesion crudSesion = new CRUD_Sesion();
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        crudSesion.setSesion(session);
        crudSesion.setTx(tx);
        int validacion = 1000;
        try {
            validacion = proceso.verificarUsuarioContrasena(correo, contrasena);
            if (validacion == 1) {
                CabeceraUsuario cabecera = this.ObtenerCabecera(correo);
                //proceso.obtenerCabecera(proceso.obtenerUsuario(correo).getIdUsuario());
                List<Sesion> sesion = cabecera.getListSesion();
                GenCuenta cuenta = cabecera.getCuenta();
                GenUsuario usuario = cabecera.getUsuario();
                List<GenRolUsuario> listrolusuario = cabecera.getListRolUsuario();
                List<GenCuentaAplicacion> listCuentaAplicacion = cabecera.getListCuentaAplicacion();
                if (cuenta.isEstado()) {
                    int a = 0, b = 0;
                    for (int i = 0; i < listrolusuario.size(); i++) {
                        if (listrolusuario.get(i).getId().getIdRolfk().equals(idRol)) {
                            a = 1;
                        }
                    }
                    for (int i = 0; i < listCuentaAplicacion.size(); i++) {
                        if (listCuentaAplicacion.get(i).getId().getIdAplicacionfk().equals(idAplicacion)) {
                            b = 1;
                        }
                    }
                    if (a == b) {
                        try {

                            List<Sesion> listsesion = crudSesion.ObtenerSesionesIdCuenta(cuenta.getIdCuenta());
                            for (Sesion s : listsesion) {
                                if (!s.isEstado()) {
                                    s.setEstado(true);
                                    crudSesion.ActualizarSesion(s);
                                    tx.commit();
                                }
                                validacion = 1;
                            }
                        } catch (Exception ex) {
                            if (tx != null) {
                                tx.rollback();
                            }

                            // throw new HibernateException("Ocurrió un error en la capa de acceso a datos", ex);
                            validacion = 0;
                        }

                    } else if (a == 1 && b == 0) {
                        validacion = -3;
                    } else if (b == 1 && a == 0) {
                        validacion = -2;
                    }
                } else {
                    validacion = 0;
                }
            } else {
                return validacion;
            }

        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
        } finally {
            if (session != null) {
                session.close();
            }
        }

        HibernateUtil.shutdown();

        return validacion;
    }

    public void cerrarSesion(String idCuenta) {
        CRUD_Sesion crudSesion = new CRUD_Sesion();
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        crudSesion.setSesion(session);
        crudSesion.setTx(tx);
        try {
            List<Sesion> listsesion = crudSesion.ObtenerSesionesIdCuenta(idCuenta);
            for (Sesion s : listsesion) {
                if (s.isEstado()) {
                    s.setEstado(false);
                    crudSesion.ActualizarSesion(s);
                    tx.commit();

                }
            }

        } catch (Exception ex) {
            if (tx != null) {
                tx.rollback();
            }

        } finally {
            if (session != null) {
                session.close();
            }

        }
        HibernateUtil.shutdown();

    }

    public boolean genRecuperarContrasena(String correo) {
        String idCuenta = "";

        CRUD_CodigoReContrasena crudCodigo = new CRUD_CodigoReContrasena();
        CRUD_Usuario crudUsuario = new CRUD_Usuario();
        CRUD_Cuenta crudCuenta = new CRUD_Cuenta();

        boolean estado = false;
        crudCodigo.setSesion(HibernateUtil.getSessionFactory().openSession());
        crudCodigo.setTx(crudCodigo.getSesion().beginTransaction());

        crudUsuario.setSesion(HibernateUtil.getSessionFactory().openSession());
        crudUsuario.setTx(crudUsuario.getSesion().beginTransaction());

        crudCuenta.setSesion(HibernateUtil.getSessionFactory().openSession());
        crudCuenta.setTx(crudCuenta.getSesion().beginTransaction());

        try {

            GenCodigoReContrasena codigo = new GenCodigoReContrasena();
            GenCuenta cuenta = new GenCuenta();
            GenUsuario usuario = crudUsuario.ObtenerUsuarioporCorreo(correo);

            cuenta = crudCuenta.ObtenerCuentaUsuario(usuario.getIdUsuario());
            idCuenta = cuenta.getIdCuenta();
            List<GenCodigoReContrasena> listCodigo = crudCodigo.ObtenerCodigoReContrasenaPoridCuenta(idCuenta);
            crudCodigo.getSesion().close();
            crudCodigo.setSesion(HibernateUtil.getSessionFactory().openSession());
            crudCodigo.setTx(crudCodigo.getSesion().beginTransaction());

            if (listCodigo.size() > 0 && listCodigo.size() == 1) {

                cuenta.setIdCuenta(idCuenta);
                codigo.setIdCodigoReContrasena(listCodigo.get(0).getIdCodigoReContrasena());
                //System.out.println("Id:"+listCodigo.get(0).getGenCuenta().getIdCuenta());
                codigo.setGenCuenta(cuenta);
                codigo.setCodigoContrasenacol(UUID.randomUUID().toString());
                codigo.setFechalim(new ProcesoGeneradorCodigos().EstablecerFechaReContrasena());

                crudCodigo.ActualizarCodigoReContrasena(codigo);
                estado = true;
            } else {

                cuenta.setIdCuenta(idCuenta);
                codigo.setGenCuenta(cuenta);
                codigo.setCodigoContrasenacol(UUID.randomUUID().toString());
                codigo.setFechalim(new ProcesoGeneradorCodigos().EstablecerFechaReContrasena());
                crudCodigo.CrearCodigoReContrasena(codigo);

                estado = true;

            }

            GenCuenta cuentaUsuario = crudCuenta.ObtenerCuenta(idCuenta);

            GenUsuario user = new GenUsuario();
            if (cuentaUsuario != null) {
                user = crudUsuario.ObtenerUsuarioporCorreo(correo);
            }
            if (user != null) {

                //(String to,String CodContrasena,String idCuenta,String fechLim)
                new ProcesoRNEnviarCorreo().enviarCorreoRecuContrasena(user.getCorreo(), codigo.getCodigoContrasenacol(), cuenta.getIdCuenta(), codigo.getFechalim().toString(), correo);

                estado = true;
            } else {
                estado = false;
            }

            crudUsuario.getTx().commit();
            crudCuenta.getTx().commit();
            crudCodigo.getTx().commit();

        } catch (HibernateException he) {
            if (crudUsuario.getTx() != null && crudCuenta.getTx() != null && crudCodigo.getTx() != null) {
                crudUsuario.getTx().rollback();
                crudCuenta.getTx().rollback();
                crudCodigo.getTx().rollback();
            }
            estado = false;

        } finally {
            if (crudUsuario.getSesion() != null && crudCuenta.getSesion() != null && crudCodigo.getSesion() != null) {
                crudUsuario.getSesion().close();
                crudCuenta.getSesion().close();
                crudCodigo.getSesion().close();
            }
        }
        HibernateUtil.shutdown();

        return estado;
    }

    public boolean validaRecuperarContrasena(String idCuenta, String codigo, String correo) {
        CRUD_CodigoReContrasena crudCodigo = new CRUD_CodigoReContrasena();
        CRUD_Cuenta crudCuenta = new CRUD_Cuenta();
        CRUD_Usuario crudUsuario = new CRUD_Usuario();
        Session ses = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = ses.beginTransaction();
        boolean estado = false;

        crudCodigo.setSesion(ses);
        crudCodigo.setTx(tx);
        crudUsuario.setSesion(ses);
        crudUsuario.setTx(tx);
        crudCuenta.setSesion(ses);
        crudCuenta.setTx(tx);

        try {
            GenUsuario user = crudUsuario.ObtenerUsuarioporCorreo(correo);
            GenCuenta cuenta = crudCuenta.ObtenerCuenta(idCuenta);

            List<GenCodigoReContrasena> codigoReContrasena = crudCodigo.ObtenerCodigoReContrasenaPoridCuenta(idCuenta);
            GenCodigoReContrasena c = codigoReContrasena.get(0);

            if (c != null) {

                /*
            date1.compareTo(date2); //date1 < date2, devuelve un valor menor que 0
date2.compareTo(date1); //date2 > date1, devuelve un valor mayor que 0
date1.compareTo(date3); //date1 = date3, se mostrará un 0 en la consola
                 */
                if ((new Date().before((c.getFechalim()))) || (new Date().compareTo(c.getFechalim()) == 0)) {
                    if (codigoReContrasena.get(0).getCodigoContrasenacol().equals(codigo)) {
                        HibernateUtil.shutdown();
                        estado = true;
                    }
                }

            }
        } catch (HibernateException he) {
            if (crudUsuario.getTx() != null && crudCuenta.getTx() != null && crudCodigo.getTx() != null) {
                crudUsuario.getTx().rollback();
                crudCuenta.getTx().rollback();
                crudCodigo.getTx().rollback();
            }
        } finally {
            if (crudUsuario.getSesion() != null && crudCuenta.getSesion() != null && crudCodigo.getSesion() != null) {
                crudUsuario.getSesion().close();
                crudCuenta.getSesion().close();
                crudCodigo.getSesion().close();
            }
        }
        HibernateUtil.shutdown();
        return estado;

    }

    public CabeceraUsuario ObtenerCabecera(String correo) {
        try {
            ProcesoReutilizableUsuario pReutilizable = new ProcesoReutilizableUsuario();
            CabeceraUsuario cabecera;

            if (pReutilizable.obtenerCabecera(pReutilizable.obtenerUsuario(correo).getIdUsuario()).get("Psicologo") != null) {
                cabecera = (CabeceraUsuario<Psicologo>) pReutilizable.obtenerCabecera(pReutilizable.obtenerUsuario(correo).getIdUsuario()).get("Psicologo");

            } else {

                cabecera = (CabeceraUsuario<Paciente>) pReutilizable.obtenerCabecera(pReutilizable.obtenerUsuario(correo).getIdUsuario()).get("Paciente");

            }
            return cabecera;
        } catch (HibernateException ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public boolean ModificarContrasena(String idCuenta, String password, String correo) {
        CRUD_Cuenta crudCuenta = new CRUD_Cuenta();
        CRUD_Usuario crudUsuario = new CRUD_Usuario();
        Session ses = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = ses.beginTransaction();
        boolean estado = false;
        crudUsuario.setSesion(ses);
        crudUsuario.setTx(tx);
        crudCuenta.setSesion(ses);
        crudCuenta.setTx(tx);

        try {
            GenCuenta cuenta = null;//crudCuenta.ObtenerCuenta(idCuenta);
            GenUsuario usuario = crudUsuario.ObtenerUsuarioporCorreo(correo);
            cuenta = crudCuenta.ObtenerCuentaUsuario(usuario.getIdUsuario());
            if (cuenta != null) {

                if (usuario != null && cuenta.getIdCuenta().equals(idCuenta)) {

                    usuario.setContrasena(password);
                    crudUsuario.ActualizarUsuario(usuario);
                    crudUsuario.getTx().commit();
                    estado = true;
                }
            }
        } catch (HibernateException e) {
            if (crudUsuario.getTx() != null && crudCuenta.getTx() != null) {
                crudUsuario.getTx().rollback();
                crudCuenta.getTx().rollback();
            }
        } finally {
            if (crudUsuario.getSesion() != null && crudCuenta.getSesion() != null) {
                crudUsuario.getSesion().close();
                crudCuenta.getSesion().close();

            }
        }
        HibernateUtil.shutdown();
        return estado;

    }

    public GenUsuario obtenerUsuario(String idUsuario) {
        CRUD_Usuario crudUsuario = new CRUD_Usuario();
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        crudUsuario.setSesion(session);
        crudUsuario.setTx(tx);

        GenUsuario usuario = null;
        try {

            usuario = crudUsuario.ObtenerUsuario(idUsuario);
            tx = crudUsuario.getTx();
            tx.commit();
            session.close();
        } catch (HibernateException he) {
            if (tx != null) {
                tx.rollback();
            }
            he.printStackTrace();
            session.close();
            throw new HibernateException("Ocurrió un error en la capa de acceso a datos", he);

        }
        return usuario;
    }

    public boolean modificarUsuario(GenUsuario usuario) {
        CRUD_Usuario crudUsuario = new CRUD_Usuario();
        boolean status = false;
        try {

            if (usuario != null) {
                crudUsuario.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
                crudUsuario.setTx(crudUsuario.getSesion().beginTransaction());
                crudUsuario.ActualizarUsuario(usuario);
                crudUsuario.getTx().commit();
                status = true;

            }

        } catch (HibernateException ex) {

            if (crudUsuario.getTx() != null) {
                crudUsuario.getTx().rollback();
            }
        } finally {
            if (crudUsuario.getSesion() != null) {
                crudUsuario.getSesion().close();
            }

        }
        HibernateUtil.shutdown();
        return status;
    }

}
