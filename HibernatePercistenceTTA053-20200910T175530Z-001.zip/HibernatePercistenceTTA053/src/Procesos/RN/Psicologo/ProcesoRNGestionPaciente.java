package Procesos.RN.Psicologo;

import Cabeceras.CabeceraUsuario;
import DAOSMOD1.CRUD_CodigoReContrasena;
import DAOSMOD1.CRUD_Cuenta;
import DAOSMOD1.CRUD_CuentaAplicacion;
import DAOSMOD1.CRUD_Paciente;
import DAOSMOD1.CRUD_Psicologo;
import DAOSMOD1.CRUD_Rol;
import DAOSMOD1.CRUD_RolUsuario;
import DAOSMOD1.CRUD_Sesion;
import DAOSMOD1.CRUD_Tutor;
import DAOSMOD1.CRUD_Usuario;
import Entidades.GenCodigoReContrasena;
import Entidades.GenCuenta;
import Entidades.GenCuentaAplicacionId;
import Entidades.GenRolUsuarioId;
import Entidades.GenUsuario;
import Entidades.Paciente;
import Entidades.Psicologo;
import Entidades.Sesion;
import Entidades.Tutor;
import InstanciarHibernate.HibernateUtil;
import InstanciarHibernate.InstanciaHibernate;
import Procesos.Persistencia.Genericos.ProcesoGeneradorCodigos;
import Procesos.Persistencia.Usuario.ProcesoReutilizableUsuario;
import Procesos.RN.Usuario.ProcesoRNSesionUsuario;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class ProcesoRNGestionPaciente {

    public boolean AgregarPaciente(GenUsuario usuario, Psicologo psicologo, Paciente paciente, Tutor tutor) {

        CRUD_Usuario crudUsuario = new CRUD_Usuario();
        CRUD_Cuenta crudCuenta = new CRUD_Cuenta();
        CRUD_Psicologo crudPsicologo = new CRUD_Psicologo();
        CRUD_CuentaAplicacion crudCuentaAplicacion = new CRUD_CuentaAplicacion();
        CRUD_CodigoReContrasena crudCodigoReContrasena = new CRUD_CodigoReContrasena();
        CRUD_Sesion crudSesion = new CRUD_Sesion();
        CRUD_RolUsuario crudRolUsuario = new CRUD_RolUsuario();
        CRUD_Paciente crudPaciente = new CRUD_Paciente();
        CRUD_Tutor crudTutor = new CRUD_Tutor();
        ProcesoGeneradorCodigos recuperarContra = new ProcesoGeneradorCodigos();
        boolean estado = false;
        try {
            Session session = HibernateUtil.getSessionFactory().getCurrentSession();
            Transaction tx = session.beginTransaction();
            crudUsuario.setSesion(session);//HibernateUtil.getSessionFactory().openSession());
            crudUsuario.setTx(tx);//crudUsuario.getSesion().beginTransaction());
            crudCuenta.setSesion(session);//HibernateUtil.getSessionFactory().openSession());
            crudCuenta.setTx(tx);//crudCuenta.getSesion().beginTransaction());
            crudPsicologo.setSesion(session);//HibernateUtil.getSessionFactory().openSession());
            crudPsicologo.setTx(tx);//crudPsicologo.getSesion().beginTransaction());
            crudCuentaAplicacion.setSesion(session);//HibernateUtil.getSessionFactory().openSession());
            crudCuentaAplicacion.setTx(tx);//crudCuentaAplicacion.getSesion().beginTransaction());
            crudCodigoReContrasena.setSesion(session);//HibernateUtil.getSessionFactory().openSession());
            crudCodigoReContrasena.setTx(tx);//crudCodigoReContrasena.getSesion().beginTransaction());
            crudSesion.setSesion(session);//HibernateUtil.getSessionFactory().openSession());
            crudSesion.setTx(tx);//crudSesion.getSesion().beginTransaction());
            crudRolUsuario.setSesion(session);//HibernateUtil.getSessionFactory().openSession());
            crudRolUsuario.setTx(tx);//crudRolUsuario.getSesion().beginTransaction());
            crudPaciente.setSesion(session);//HibernateUtil.getSessionFactory().openSession());
            crudPaciente.setTx(tx);//crudPaciente.getSesion().beginTransaction());
            crudTutor.setSesion(session);//HibernateUtil.getSessionFactory().openSession());
            crudTutor.setTx(tx);//crudTutor.getSesion().beginTransaction());
            //creamos el Usuario
            if (crudUsuario.CrearUsuario(usuario)) {
                //Optenemos el usuario para poder optener el IdUsuario
                //se inicializa cuenta y con estado true de activado
                //crudUsuario.getTx().commit();
                GenCuenta cuenta = new GenCuenta();
                cuenta.setGenUsuario(usuario);
                cuenta.setEstado(true);

                crudCuenta.CrearCuenta(cuenta);

                //El IdRol del paciente es '00000000-0000-0000-0000-000000000002'
                crudRolUsuario.CrearRolUsuario(new GenRolUsuarioId("00000000-0000-0000-0000-000000000002", usuario.getIdUsuario()));
                //id cuenta, id aplicacioón 1 default de appPaciente
                crudCuentaAplicacion.CrearCuentaAplicacion(new GenCuentaAplicacionId(cuenta.getIdCuenta(), "00000000-0000-0000-0000-000000000001"));
                //Creamos una sesion en la cual podrá acceder
                Sesion sesion = new Sesion();
                sesion.setEstado(false);
                sesion.setTipo("movil");
                sesion.setGenCuenta(cuenta);

                crudSesion.CrearSesion(sesion);
                //aquí ahora Crearemos un código regeneracion contraseña
                GenCodigoReContrasena codigoReContrasena = new GenCodigoReContrasena();
                //Fecha Actual
                //String stringFechaConHora = "2014-09-15 15:03:23";
                //Date fechaConHora = sdf.parse(stringFechaConHora);
                codigoReContrasena.setFechalim(recuperarContra.EstablecerFechaReContrasena());
                codigoReContrasena.setGenCuenta(cuenta);
                codigoReContrasena.setCodigoContrasenacol(UUID.randomUUID().toString());

                //Agregamos el codigo y fecha
                crudCodigoReContrasena.CrearCodigoReContrasena(codigoReContrasena);

                //crudPsicologo.CrearPsicologo(psicologo);
                //pasaremos como parametro al psicologo para saber que sicologo agrego al paciente
                crudUsuario.getTx().commit();

                crudPaciente.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
                crudPaciente.setTx(crudPaciente.getSesion().beginTransaction());
                paciente.setPsicologo(psicologo);

                crudPaciente.CrearPaciente(paciente);
                crudPaciente.getTx().commit();

                crudTutor.setSesion(HibernateUtil.getSessionFactory().getCurrentSession());
                crudTutor.setTx(crudTutor.getSesion().beginTransaction());
                //Asignamos un tutor al paciente
                tutor.setPaciente(paciente);

                crudTutor.CrearTutor(tutor);
                crudTutor.getTx().commit();
                estado = true;

                //tx.commit();
            }

        } catch (HibernateException he) {
            if (crudUsuario.getTx() != null
                    && crudCuenta.getTx() != null
                    && crudPsicologo.getTx() != null
                    && crudCuentaAplicacion.getTx() != null
                    && crudCodigoReContrasena.getTx() != null
                    && crudSesion.getTx() != null
                    && crudRolUsuario.getTx() != null
                    && crudPaciente.getTx() != null
                    && crudTutor.getTx() != null) {
                crudUsuario.getTx().rollback();
                crudCuenta.getTx().rollback();
                crudPsicologo.getTx().rollback();
                crudCuentaAplicacion.getTx().rollback();
                crudCodigoReContrasena.getTx().rollback();
                crudSesion.getTx().rollback();
                crudRolUsuario.getTx().rollback();
                crudPaciente.getTx().rollback();
                crudTutor.getTx().rollback();
            }
        } finally {
            if (crudUsuario.getSesion() != null
                    && crudCuenta.getSesion() != null
                    && crudPsicologo.getSesion() != null
                    && crudCuentaAplicacion.getSesion() != null
                    && crudCodigoReContrasena.getSesion() != null
                    && crudSesion.getSesion() != null
                    && crudRolUsuario.getSesion() != null
                    && crudPaciente.getSesion() != null
                    && crudTutor.getSesion() != null) {
                crudUsuario.getSesion().close();
                crudCuenta.getSesion().close();
                crudPsicologo.getSesion().close();
                crudCuentaAplicacion.getSesion().close();
                crudCodigoReContrasena.getSesion().close();
                crudSesion.getSesion().close();
                crudRolUsuario.getSesion().close();
                crudPaciente.getSesion().close();
                crudTutor.getSesion().close();

            }
        }
        HibernateUtil.shutdown();
        return estado;
    }

    public void DesactivarPaciente(String idUsuario) {
        CRUD_Psicologo crudPsicologo = new CRUD_Psicologo();
        CRUD_Usuario crudUsuario = new CRUD_Usuario();
        CRUD_Cuenta crudCuenta = new CRUD_Cuenta();
        CRUD_Rol crudRol = new CRUD_Rol();
        CRUD_RolUsuario crudRolUsuario = new CRUD_RolUsuario();
        CRUD_Paciente crudPaciente = new CRUD_Paciente();

        try {
            Session session = HibernateUtil.getSessionFactory().getCurrentSession();
            Transaction tx = session.beginTransaction();
            crudUsuario.setSesion(session);
            crudUsuario.setTx(tx);
            crudCuenta.setSesion(session);
            crudCuenta.setTx(tx);
            crudPsicologo.setSesion(session);
            crudPsicologo.setTx(tx);
            crudRolUsuario.setSesion(session);
            crudRolUsuario.setTx(tx);
            crudPaciente.setSesion(session);
            crudPaciente.setTx(tx);

            GenUsuario usuario = crudUsuario.ObtenerUsuario(idUsuario);

            if (usuario != null && (crudRolUsuario.ObtenerRolUsuario(new GenRolUsuarioId("00000000-0000-0000-0000-000000000002", usuario.getIdUsuario()))) != null) {
                Psicologo psicologo = crudPsicologo.ObtenerPsicologoporIdUser(usuario.getIdUsuario());
                Paciente paciente = crudPaciente.ObtenerPacienteporIdUser(idUsuario);

                if (paciente != null) {
                    GenCuenta cuenta = null;
                    cuenta = crudCuenta.ObtenerCuentaUsuario(usuario.getIdUsuario());
                    if (cuenta != null && cuenta.isEstado() != false) {
                        cuenta.setEstado(false);
                        crudCuenta.ActualizarCuenta(cuenta);
                        tx.commit();
                    }
                }

            }

        } catch (HibernateException he) {
            if (crudUsuario.getTx() != null
                    && crudCuenta.getTx() != null
                    && crudPsicologo.getTx() != null
                    && crudRolUsuario.getTx() != null
                    && crudPaciente.getTx() != null) {
                crudUsuario.getTx().rollback();
                crudCuenta.getTx().rollback();
                crudPsicologo.getTx().rollback();
                crudRolUsuario.getTx().rollback();
                crudPaciente.getTx().rollback();
            }
        } finally {

            if (crudUsuario.getSesion() != null
                    && crudCuenta.getSesion() != null
                    && crudPsicologo.getSesion() != null
                    && crudRolUsuario.getSesion() != null
                    && crudPaciente.getSesion() != null) {
                crudUsuario.getSesion().close();
                crudCuenta.getSesion().close();
                crudPsicologo.getSesion().close();
                crudRolUsuario.getSesion().close();
                crudPaciente.getSesion().close();
            }

        }
        HibernateUtil.shutdown();

    }

    public void ActivarPaciente(String idUsuario) {
        CRUD_Psicologo crudPsicologo = new CRUD_Psicologo();
        CRUD_Usuario crudUsuario = new CRUD_Usuario();
        CRUD_Cuenta crudCuenta = new CRUD_Cuenta();
        CRUD_Rol crudRol = new CRUD_Rol();
        CRUD_RolUsuario crudRolUsuario = new CRUD_RolUsuario();
        CRUD_Paciente crudPaciente = new CRUD_Paciente();

        try {
            Session session = HibernateUtil.getSessionFactory().getCurrentSession();
            Transaction tx = session.beginTransaction();
            crudUsuario.setSesion(session);
            crudUsuario.setTx(tx);
            crudCuenta.setSesion(session);
            crudCuenta.setTx(tx);
            crudPsicologo.setSesion(session);
            crudPsicologo.setTx(tx);
            crudRolUsuario.setSesion(session);
            crudRolUsuario.setTx(tx);
            crudPaciente.setSesion(session);
            crudPaciente.setTx(tx);

            GenUsuario usuario = crudUsuario.ObtenerUsuario(idUsuario);

            if (usuario != null && (crudRolUsuario.ObtenerRolUsuario(new GenRolUsuarioId("00000000-0000-0000-0000-000000000002", usuario.getIdUsuario()))) != null) {
                Paciente paciente = crudPaciente.ObtenerPacienteporIdUser(idUsuario);
                if (paciente != null) {
                    GenCuenta cuenta = null;
                    cuenta = crudCuenta.ObtenerCuentaUsuario(usuario.getIdUsuario());
                    if (cuenta != null && cuenta.isEstado() != true) {
                        cuenta.setEstado(true);
                        crudCuenta.ActualizarCuenta(cuenta);
                        tx.commit();
                    }
                }
            }

        } catch (HibernateException he) {
            if (crudUsuario.getTx() != null
                    && crudCuenta.getTx() != null
                    && crudPsicologo.getTx() != null
                    && crudRolUsuario.getTx() != null
                    && crudPaciente.getTx() != null) {
                crudUsuario.getTx().rollback();
                crudCuenta.getTx().rollback();
                crudPsicologo.getTx().rollback();
                crudRolUsuario.getTx().rollback();
                crudPaciente.getTx().rollback();
            }
        } finally {
            if (crudUsuario.getSesion() != null
                    && crudCuenta.getSesion() != null
                    && crudPsicologo.getSesion() != null
                    && crudRolUsuario.getSesion() != null
                    && crudPaciente.getSesion() != null) {
                crudUsuario.getSesion().close();
                crudCuenta.getSesion().close();
                crudPsicologo.getSesion().close();
                crudRolUsuario.getSesion().close();
                crudPaciente.getSesion().close();
            }
        }
        HibernateUtil.shutdown();

    }

    //Nadamás se podrá modificar Alias y Grado Escolar
    public boolean ModificarPaciente(Paciente paciente) {
        CRUD_Paciente crudPaciente = new CRUD_Paciente();
        boolean estado = false;
        try {
            Session session = HibernateUtil.getSessionFactory().getCurrentSession();
            Transaction tx = session.beginTransaction();
            crudPaciente.setSesion(session);
            crudPaciente.setTx(tx);
            crudPaciente.ActualizarPaciente(paciente);
            tx.commit();
            estado = true;
        } catch (HibernateException he) {
            if (crudPaciente.getTx() != null) {
                crudPaciente.getTx().rollback();
            }

        } finally {
            if (crudPaciente.getSesion() != null) {
                crudPaciente.getSesion().close();
            }

        }
        HibernateUtil.shutdown();
        return estado;
    }

    public void CambiarFoto(byte[] foto, String idUsuario) {
        CRUD_Usuario crudUsuario = new CRUD_Usuario();
        GenUsuario user = new GenUsuario();

        try {
            Session session = HibernateUtil.getSessionFactory().getCurrentSession();
            Transaction tx = session.beginTransaction();
            crudUsuario.setSesion(session);
            crudUsuario.setTx(tx);
            user = crudUsuario.ObtenerUsuario(idUsuario);
            user.setFoto(foto);
            crudUsuario.ActualizarUsuario(user);
            tx.commit();
        } catch (HibernateException he) {
            if (crudUsuario.getTx() != null) {
                crudUsuario.getTx().rollback();
            }
        } finally {
            if (crudUsuario.getSesion() != null) {
                crudUsuario.getSesion().close();
            }

        }
        HibernateUtil.shutdown();

    }

    public void ModificarInfoTutorPaciente(Tutor tutor) {
        CRUD_Tutor crudTutor = new CRUD_Tutor();
        try {
            Session session = HibernateUtil.getSessionFactory().getCurrentSession();
            Transaction tx = session.beginTransaction();
            crudTutor.setSesion(session);
            crudTutor.setTx(tx);
            crudTutor.ActualizarTutor(tutor);
            tx.commit();

        } catch (HibernateException he) {
            if (crudTutor.getTx() != null) {
                crudTutor.getTx().rollback();
            }

        } finally {
            if (crudTutor.getSesion() != null) {
                crudTutor.getSesion().close();
            }
        }
        HibernateUtil.shutdown();
    }

    public CabeceraUsuario<Paciente> ObtenerCabeceraPaciente(String idUsuario) {
        CabeceraUsuario<Paciente> cabeceraPaciente = null;
        ProcesoRNSesionUsuario rnUsuario = new ProcesoRNSesionUsuario();
        try {

            cabeceraPaciente = rnUsuario.ObtenerCabecera(rnUsuario.obtenerUsuario(idUsuario).getCorreo());
        } catch (Exception he) {
        } finally {
        }
        return cabeceraPaciente;
    }

    public List<CabeceraUsuario<Paciente>> ObtenerListaCabecerasPaciente(String idPsicologo) {
        CabeceraUsuario<Paciente> cabeceraPaciente = null;
        CRUD_Paciente crudPaciente = new CRUD_Paciente();
        List<CabeceraUsuario<Paciente>> listCabeceraPacientes = new ArrayList<CabeceraUsuario<Paciente>>();
        List<Paciente> listPacientes = new ArrayList<Paciente>();
        ProcesoRNSesionUsuario rnUsuario = new ProcesoRNSesionUsuario();
        try {
            crudPaciente.setSesion(HibernateUtil.getSessionFactory().openSession());
            crudPaciente.setTx(crudPaciente.getSesion().beginTransaction());
            listPacientes = crudPaciente.ListaPacientesPorIdPsicologo(idPsicologo);

            for (Paciente p : listPacientes) {
                if (p.getGenUsuario() != null) {
                    cabeceraPaciente=new CabeceraUsuario<Paciente>();
                    cabeceraPaciente = rnUsuario.ObtenerCabecera(p.getGenUsuario().getCorreo());
                  
                    GenUsuario usuar=new GenUsuario();
                        usuar.setNombre("");
                        usuar.setApp("");
                        usuar.setApm("");
                        usuar.setTel("");
                        usuar.setCel("");
                        usuar.setDireccion("");
                        usuar.setFechaNacimiento(new Date(1995,6,25));
                        usuar.setCorreo("");
                        usuar.setContrasena("");
                        cabeceraPaciente.getTipocabecera().setGenUsuario(usuar);
                        cabeceraPaciente.getTipocabecera().getPsicologo().setGenUsuario(usuar);
                        
                   listCabeceraPacientes.add(cabeceraPaciente);
                   
                   cabeceraPaciente=null; 
                    
                    //}
                       
                }
            }

        } catch (Exception he) {
            if (crudPaciente.getTx() != null) {
                crudPaciente.getTx().rollback();
            }
        } finally {
            if (crudPaciente.getSesion() != null) {
                crudPaciente.getSesion().close();
            }
        }
        HibernateUtil.shutdown();
        return listCabeceraPacientes;
    }

}
