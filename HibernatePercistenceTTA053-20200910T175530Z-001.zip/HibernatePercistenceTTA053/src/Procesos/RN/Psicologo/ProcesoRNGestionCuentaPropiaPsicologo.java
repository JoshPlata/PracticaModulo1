package Procesos.RN.Psicologo;

import DAOSMOD1.CRUD_Psicologo;
import DAOSMOD1.CRUD_Usuario;
import Entidades.GenUsuario;
import Entidades.Psicologo;
import InstanciarHibernate.HibernateUtil;
import InstanciarHibernate.InstanciaHibernate;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class ProcesoRNGestionCuentaPropiaPsicologo {
    public void ActualizarInformacion(GenUsuario user,Psicologo psicologo)
    {
        CRUD_Usuario crudUser=new CRUD_Usuario();
        CRUD_Psicologo crudPsic=new CRUD_Psicologo();
        Session ses=HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx=ses.beginTransaction();
        crudUser.setSesion(ses);
        crudUser.setTx(tx);
        try
        {
            crudUser.ActualizarUsuario(user);
            crudPsic.ActualizarPsicologo(psicologo);
            tx.commit();
            HibernateUtil.shutdown();
            
        }catch(HibernateException he)
        {
            if(tx!=null)tx.rollback();
           he.printStackTrace();
           HibernateUtil.shutdown();
           throw new HibernateException("Ocurrió un error en la capa de acceso a datos", he); 
        }
    }
    public void ActualizarContrasena(String IdUsuario,String password)
    {
        CRUD_Usuario crudUser=new CRUD_Usuario();
        Session ses=HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx=ses.beginTransaction();
        crudUser.setSesion(ses);
        crudUser.setTx(tx);
        try
        {
            
            GenUsuario user=crudUser.ObtenerUsuario(IdUsuario);
            user.setContrasena(password);
            crudUser.ActualizarUsuario(user);
            tx.commit();
            HibernateUtil.shutdown();
           }catch(HibernateException he)
        {
            if(tx!=null)tx.rollback();
           he.printStackTrace();
           HibernateUtil.shutdown();
           throw new HibernateException("Ocurrió un error en la capa de acceso a datos", he); 
        }
    }
    public void SubirFotoPerfil(byte [] foto,String IdUsuario)
    {
         CRUD_Usuario crudUser=new CRUD_Usuario();
         Session ses=HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx=ses.beginTransaction();
        crudUser.setSesion(ses);
        crudUser.setTx(tx);
        try
        {
            GenUsuario user=crudUser.ObtenerUsuario(IdUsuario);
            user.setFoto(foto);
            crudUser.ActualizarUsuario(user);
            tx.commit();
            HibernateUtil.shutdown();
        }catch(HibernateException he)
        {
           if(tx!=null)tx.rollback();
           he.printStackTrace();
           HibernateUtil.shutdown();
           throw new HibernateException("Ocurrió un error en la capa de acceso a datos", he);
        }
        
    }
    
}
