package Procesos.Persistencia.Genericos;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ProcesosConImagenes {

    public byte[] convertirImagenaBytes(String ruta) throws FileNotFoundException, IOException {
        
        File image = new File(ruta);
        byte[] Bimage = new byte[(int) image.length()];
        try
        {
            FileInputStream fileInputStream = new FileInputStream(image);
	     //convert file into array of bytes
            fileInputStream.read(Bimage);
            fileInputStream.close();
            
            return Bimage;
        }
        catch(Exception ex)
        {
           ex.printStackTrace();
           return null;
        } 
        
    }

    public void covertirBytesaImagen(byte[] Bimage,String ruta) throws FileNotFoundException {
        try{
            FileOutputStream fos = new FileOutputStream(ruta);
            fos.write(Bimage);
            fos.close();
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }


}
