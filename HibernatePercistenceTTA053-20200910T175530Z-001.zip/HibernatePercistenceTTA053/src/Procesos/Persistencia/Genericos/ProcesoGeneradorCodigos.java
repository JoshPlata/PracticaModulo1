package Procesos.Persistencia.Genericos;

import java.util.Calendar;
import java.util.Date;


public class ProcesoGeneradorCodigos {
/*
    
char[] elementos={'0','1','2','3','4','5','6','7','8','9' ,'a',
'b','c','d','e','f','g','h','i','j','k','l','m','n ','ñ','o','p','q','r','s','t',
'u','v','w','x','y','z'};  
char[] conjunto = new char[8];
String pass;

public String creaPass(){
for(int i=0;i<8;i++){
int el = (int)(Math.random()*37);
conjunto.[i] = (char)elementos[el];
}
return pass = new String(conjunto);
}
    */

 //Este código va ser para Recuperar Contraseña será una cadena de 36 digitos aleatorios
public ProcesoGeneradorCodigos()
{

}
public String GenerarCodigo()
{
char elementos[]={'0','1','2','3','4','5','6','7','8','9','a','b','c','d','f','g','h','i','j','k','l','m','n','ñ','o','p','q','r','s','t','u','v','w','x','y','z',
'A','B','C','D','F','G','H','I','J','K','L','M','N','Ñ','O','P','Q','R','S','T','U','V','W','X','Y','Z'};

char []conjunto =new char[elementos.length];
for(int i=0;i<elementos.length;i++)
{  
    int el=(int)(Math.random()*elementos.length);
    conjunto[i]=elementos[el];
    System.out.println(el);
}

return new String(conjunto);
}
public Date EstablecerFechaReContrasena()
 {
      Date fecha=new Date();
      int horasAumentar=12;
      Calendar calendar = Calendar.getInstance();
      calendar.setTime(fecha); // Configuramos la fecha que se recibe
      calendar.add(Calendar.HOUR, horasAumentar);  // numero de horas a añadir, o restar en caso de horas<0
 
      return calendar.getTime();
 }





}
