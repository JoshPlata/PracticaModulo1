package Procesos.Persistencia.Usuario;

import Cabeceras.CabeceraUsuario;
import DAOSMOD1.CRUD_Cuenta;
import DAOSMOD1.CRUD_CuentaAplicacion;
import DAOSMOD1.CRUD_Paciente;
import DAOSMOD1.CRUD_Psicologo;
import DAOSMOD1.CRUD_Rol;
import DAOSMOD1.CRUD_RolUsuario;
import DAOSMOD1.CRUD_Sesion;
import DAOSMOD1.CRUD_Usuario;
import Entidades.GenCuenta;
import Entidades.GenCuentaAplicacion;
import Entidades.GenRolUsuario;
import Entidades.GenUsuario;
import Entidades.Paciente;
import Entidades.Psicologo;
import Entidades.Sesion;
import InstanciarHibernate.HibernateUtil;
import InstanciarHibernate.InstanciaHibernate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class ProcesoReutilizableUsuario {

    public HashMap obtenerCabecera(String idUsuario) {
        
        CRUD_Usuario crudUsuario = new CRUD_Usuario();
        CRUD_Cuenta crudCuenta = new CRUD_Cuenta();
        CRUD_RolUsuario crudRolUsuario = new CRUD_RolUsuario();
        CRUD_Rol crudRol = new CRUD_Rol();
        CRUD_Sesion crudSesion = new CRUD_Sesion();
        CRUD_Psicologo crudPsicologo = new CRUD_Psicologo();
        CRUD_Paciente crudPaciente = new CRUD_Paciente();
        CRUD_CuentaAplicacion crudCuentaAplicacion=new CRUD_CuentaAplicacion();
        HashMap hmap=new HashMap();
        hmap=null;
        
        Session session=null;
        Transaction tx=null;
        CabeceraUsuario cabecera=null;
       
        try{
            session=HibernateUtil.getSessionFactory().openSession();
            tx=session.beginTransaction();
            crudUsuario.setSesion(session);
            crudCuenta.setSesion(session);
            crudRolUsuario.setSesion(session);
            crudRol.setSesion(session);
            crudSesion.setSesion(session);
            crudPsicologo.setSesion(session);
            crudPaciente.setSesion(session);
            crudCuentaAplicacion.setSesion(session);
            
            
            GenUsuario usuario = crudUsuario.ObtenerUsuario(idUsuario);
            crudCuenta.setSesion(crudUsuario.getSesion());
            GenCuenta cuenta = crudCuenta.ObtenerCuentaUsuario(idUsuario);
            crudSesion.setSesion(crudCuenta.getSesion());
            List<Sesion> listsesion = crudSesion.ObtenerSesionesIdCuenta(cuenta.getIdCuenta());
            crudRolUsuario.setSesion(crudSesion.getSesion());
            List<GenRolUsuario> listrolusuario = crudRolUsuario.ListaRolUsuario(usuario.getIdUsuario());
            crudCuentaAplicacion.setSesion(crudRolUsuario.getSesion());
            List<GenCuentaAplicacion> listCuentaAplicacion= crudCuentaAplicacion.ListaCuentaAplicacion(cuenta.getIdCuenta());
            Psicologo psicologo = null;
            Paciente paciente = null;
            
            
            crudPsicologo.setSesion(crudCuentaAplicacion.getSesion());
            crudPaciente.setSesion(crudCuentaAplicacion.getSesion());
             for(GenRolUsuario item:listrolusuario)
              {
                  if (item.getId().getIdRolfk().equals("00000000-0000-0000-0000-000000000001")) {
                      
                      psicologo = crudPsicologo.ObtenerPsicologoporIdUser(usuario.getIdUsuario());
                      
                } //Paciente
                else if (item.getId().getIdRolfk().equals("00000000-0000-0000-0000-000000000002")) {
                    paciente = crudPaciente.ObtenerPacienteporIdUser(usuario.getIdUsuario());
                    //Aquí habia inicializado el genUsuario
                }
              }
            
            
            if (paciente == null && psicologo != null) {
                psicologo.setGenUsuario(new GenUsuario());
                cabecera = new CabeceraUsuario(psicologo);
                cabecera.setCuenta(cuenta);
                cabecera.setListSesion(listsesion);
                cabecera.setUsuario(usuario);
                cabecera.setListRolUsuario(listrolusuario);
                cabecera.setListCuentaAplicacion(listCuentaAplicacion);
                hmap=new HashMap<String,CabeceraUsuario<Psicologo>>();
                hmap.put("Psicologo",cabecera);
                
            } else if (paciente != null && psicologo == null) {
                paciente.setGenUsuario(new GenUsuario());
                paciente.getPsicologo().setGenUsuario(new GenUsuario());
                cabecera = new CabeceraUsuario(paciente);                
                cabecera.setCuenta(cuenta);
                cabecera.setListSesion(listsesion);
                cabecera.setUsuario(usuario);
                cabecera.setListRolUsuario(listrolusuario);
                cabecera.setListCuentaAplicacion(listCuentaAplicacion);
                hmap=new HashMap<String,CabeceraUsuario<Paciente>>();
                hmap.put("Paciente", cabecera);
                
                
            }
        
        }
        catch(HibernateException he)
        {
            if (tx != null) {
            tx.rollback();
            }
        }finally
        {
            if (session != null) {
            session.close();
            }          
        }
        HibernateUtil.shutdown();
        
        
        return hmap;
        
    }

    public GenUsuario obtenerUsuario(String correo) {
        CRUD_Usuario crudUsuario = new CRUD_Usuario();
        Session session=HibernateUtil.getSessionFactory().openSession();
        Transaction tx=session.beginTransaction();
        
        crudUsuario.setSesion(session);
        crudUsuario.setTx(tx);
        
        GenUsuario usuario = null;
        try {

            usuario = crudUsuario.ObtenerUsuarioporCorreo(correo);
            tx=crudUsuario.getTx();
            tx.commit();
            session.close();
        } catch (HibernateException he) {
             if(tx!=null)tx.rollback();
           he.printStackTrace();
           session.close();
           throw new HibernateException("Ocurrió un error en la capa de acceso a datos", he); 
       
        }
        return usuario;
    }

    public void actualizarInfo(GenUsuario usuario) {

        CRUD_Usuario crudUsuario=new CRUD_Usuario();
        Session session=HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx=session.beginTransaction();
       
        crudUsuario.setSesion(session);
        crudUsuario.setTx(tx);
        
        
        try{
            crudUsuario.ActualizarUsuario(usuario);
            tx.commit();
            HibernateUtil.shutdown();
            
        }catch(HibernateException he)
        {
           if(tx!=null)tx.rollback();
           he.printStackTrace();
           HibernateUtil.shutdown();
           throw new HibernateException("Ocurrió un error en la capa de acceso a datos", he); 
       
        }
    }

    public int verificarUsuarioContrasena(String correo,String contrasena) {
        CRUD_Usuario crudUsuario = new CRUD_Usuario();
        GenUsuario usuario = null;
        Session session=HibernateUtil.getSessionFactory().openSession();
        Transaction tx=session.beginTransaction();
        crudUsuario.setSesion(session);
        crudUsuario.setTx(tx);
        int valor=-1;
        
        try{
            usuario = crudUsuario.ObtenerUsuarioporCorreo(correo);
            HibernateUtil.shutdown();
            if (usuario != null) {
                if (usuario.getContrasena().equals(contrasena)) {
                    
                    valor=1;
                } else {
                    valor=0;
                }
            }       
        }
        catch(Exception ex)
        {
            if (tx != null) {
            tx.rollback();
            }
        }
        finally
        {
            if (session != null) {
            session.close();
            }  
        }
        
        return valor;
        
        
    }
}
