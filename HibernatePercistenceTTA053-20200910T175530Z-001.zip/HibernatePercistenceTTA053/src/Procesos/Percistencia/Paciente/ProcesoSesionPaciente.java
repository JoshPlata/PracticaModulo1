package Procesos.Percistencia.Paciente;

import DAOSMOD1.CRUD_CodigoReContrasena;
import DAOSMOD1.CRUD_Cuenta;
import DAOSMOD1.CRUD_CuentaAplicacion;
import DAOSMOD1.CRUD_Psicologo;
import DAOSMOD1.CRUD_Rol;
import DAOSMOD1.CRUD_RolUsuario;
import DAOSMOD1.CRUD_Sesion;
import DAOSMOD1.CRUD_Usuario;
import Entidades.GenCodigoReContrasena;
import Entidades.GenCuenta;
import Entidades.GenCuentaAplicacionId;
import Entidades.GenRolUsuarioId;
import Entidades.GenUsuario;
import Entidades.Psicologo;
import Entidades.Sesion;
import InstanciarHibernate.InstanciaHibernate;
import Procesos.Persistencia.Genericos.ProcesoGeneradorCodigos;
import java.util.UUID;
import org.hibernate.HibernateException;

public class ProcesoSesionPaciente {
    public InstanciaHibernate conexion;
    public ProcesoSesionPaciente()
    {
        
      conexion=new InstanciaHibernate();
    }
    public boolean AgregarPaciente(GenUsuario usuario, Psicologo psicologo) {
        
        boolean estado=false;
        
        CRUD_Usuario crudUsuario = new CRUD_Usuario();
        CRUD_Cuenta crudCuenta = new CRUD_Cuenta();
        CRUD_Psicologo crudPaciente = new CRUD_Psicologo();
        CRUD_CuentaAplicacion crudCuentaAplicacion = new CRUD_CuentaAplicacion();
        CRUD_CodigoReContrasena crudCodigoReCotrasena=new CRUD_CodigoReContrasena();
        CRUD_Sesion crudSesion=new CRUD_Sesion();
        CRUD_RolUsuario crudRolUsuario=new CRUD_RolUsuario();
        
        //crudCuenta.conexion=crudRolUsuario.conexion=crudPaciente.conexion=crudUsuario.conexion;
        
        
        ProcesoGeneradorCodigos recuperarContra=new ProcesoGeneradorCodigos();      
        try {
            conexion.iniciaOperacion();
            
            //creamos el Usuario
            if (crudUsuario.CrearUsuario(usuario)){
                //Optenemos el usuario para poder optener el IdUsuario
                //se inicializa cuenta y con estado true de activado
                GenCuenta cuenta = new GenCuenta();
                cuenta.setGenUsuario(usuario);
                cuenta.setEstado(true);
                crudCuenta.CrearCuenta(cuenta);
                
                crudRolUsuario.CrearRolUsuario(new GenRolUsuarioId("00000000-0000-0000-0000-000000000001",usuario.getIdUsuario()));

                //id cuenta, id aplicacioón 1 default de appPsicologo
                crudCuentaAplicacion.CrearCuentaAplicacion(new GenCuentaAplicacionId(cuenta.getIdCuenta(),"00000000-0000-0000-0000-000000000000"));
              
                
                
                //Creamos una sesion en la cual podrá acceder
                Sesion sesion=new Sesion();
                sesion.setEstado(false);
                sesion.setTipo("movil");
                sesion.setGenCuenta(cuenta);
                
                crudSesion.CrearSesion(sesion);
                //aquí ahora Crearemos un código regeneracion contraseña
                
                GenCodigoReContrasena codigoReContrasena=new GenCodigoReContrasena();
                //Fecha Actual
                //String stringFechaConHora = "2014-09-15 15:03:23";
                //Date fechaConHora = sdf.parse(stringFechaConHora);
                
                codigoReContrasena.setFechalim(recuperarContra.EstablecerFechaReContrasena());
                codigoReContrasena.setGenCuenta(cuenta);
                codigoReContrasena.setCodigoContrasenacol(UUID.randomUUID().toString());
                //Agregamos el codigo y fecha
                crudCodigoReCotrasena.CrearCodigoReContrasena(codigoReContrasena);
                
                psicologo.setGenUsuario(usuario);
                crudPaciente.CrearPsicologo(psicologo);
                conexion.finalizarOperacion();
                
                
            } 
        } catch (HibernateException he) {
           conexion.manejaExcepcion(he);
           conexion.finalizarOperacion();
        }
        return estado;
    }

    public void DesactivarPsicologo(String correo) {
        CRUD_Psicologo crudPsicologo=new CRUD_Psicologo();
        CRUD_Usuario crudUsuario=new CRUD_Usuario();
        CRUD_Cuenta crudCuenta=new CRUD_Cuenta();
        CRUD_Rol crudRol=new CRUD_Rol();
        CRUD_RolUsuario crudRolUsuario=new CRUD_RolUsuario();
        
        conexion.iniciaOperacion();
        try{
            GenUsuario usuario=crudUsuario.ObtenerUsuarioporCorreo(correo);
        
        if(usuario!=null&&(crudRolUsuario.ObtenerRolUsuario(new GenRolUsuarioId("00000000-0000-0000-0000-000000000001",usuario.getIdUsuario())))!=null)
        {
            Psicologo psicologo=crudPsicologo.ObtenerPsicologoporIdUser(usuario.getIdUsuario());
            if(psicologo!=null)
            {
                GenCuenta cuenta=null;
                cuenta=crudCuenta.ObtenerCuentaUsuario(usuario.getIdUsuario());
                if(cuenta!=null&&cuenta.isEstado()!=false)
                {
                    cuenta.setEstado(false);
                    crudCuenta.ActualizarCuenta(cuenta);
                
                }
            }
        
        
        }
        conexion.finalizarOperacion();
        }catch(HibernateException he)
        {
            conexion.manejaExcepcion(he);
            conexion.finalizarOperacion();
            
        }
        
        
    }
    
    public void ActivarPsicologo(String correo) {
        CRUD_Psicologo crudPsicologo=new CRUD_Psicologo();
        CRUD_Usuario crudUsuario=new CRUD_Usuario();
        CRUD_Cuenta crudCuenta=new CRUD_Cuenta();
        CRUD_Rol crudRol=new CRUD_Rol();
        CRUD_RolUsuario crudRolUsuario=new CRUD_RolUsuario();
        
        conexion.iniciaOperacion();
        try{
            GenUsuario usuario=crudUsuario.ObtenerUsuarioporCorreo(correo);
        
        if(usuario!=null&&(crudRolUsuario.ObtenerRolUsuario(new GenRolUsuarioId("00000000-0000-0000-0000-000000000001",usuario.getIdUsuario())))!=null)
        {
            Psicologo psicologo=crudPsicologo.ObtenerPsicologoporIdUser(usuario.getIdUsuario());
            if(psicologo!=null)
            {
                GenCuenta cuenta=null;
                cuenta=crudCuenta.ObtenerCuentaUsuario(usuario.getIdUsuario());
                if(cuenta!=null&&cuenta.isEstado()!=true)
                {
                    cuenta.setEstado(true);
                    crudCuenta.ActualizarCuenta(cuenta);
                
                }
            }
        
        
        }
        conexion.finalizarOperacion();
        }catch(HibernateException he)
        {
            conexion.manejaExcepcion(he);
            conexion.finalizarOperacion();
            
        }
        
        
    }

    public void ListaPsicologosActivados() {
    }

    public void ListaPsicologosDesactivados() {
    }

    public void ObtenerCabeceraPsicologo() {
    }
}
