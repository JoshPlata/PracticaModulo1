package PruebasUnitariasPsicologo;

import DAOSMOD1.CRUD_Psicologo;
import Entidades.GenUsuario;
import Entidades.Paciente;
import Entidades.Psicologo;
import Entidades.Tutor;
import InstanciarHibernate.HibernateUtil;
import Procesos.RN.Psicologo.ProcesoRNGestionPaciente;
import java.util.Date;

/**
 *
 * @author stile
 */
public class PruebaUnitariaAgregarPaciente {

    public static void main(String[] args) {

        ProcesoRNGestionPaciente proGestionPaciente=new ProcesoRNGestionPaciente();
       /* CRUD_Psicologo crudPsicologo=new CRUD_Psicologo();
        crudPsicologo.setSesion(HibernateUtil.getSessionFactory().openSession());
        crudPsicologo.setTx(crudPsicologo.getSesion().beginTransaction());
        crudPsicologo*/
        GenUsuario usuario=new GenUsuario();
        Psicologo psicologo=new Psicologo();
        Paciente paciente=new Paciente();
        Tutor tutor=new Tutor();
        
        
        usuario.setNombre("Juan");
        usuario.setApp("Gutierrez");
        usuario.setApm("Lopez");
        usuario.setCel("5547607426");
        usuario.setContrasena("1234");
        usuario.setCorreo("juan.gtz.lopez95@gmail.com");
        usuario.setDireccion("C. Alvaro Obregón no. 91");
        usuario.setFechaNacimiento(new Date(1990,8,16));
        usuario.setTel("68343534");
    
        psicologo.setIdPsicologo("111657ef-ec1e-42f3-b049-4c36c6eb99d9");
        paciente.setAlias("Anita");
        paciente.setGradoEscolar("1° Secundaria");
        paciente.setPsicologo(psicologo);
        paciente.setGenUsuario(usuario);
        
        tutor.setNombre("Mirandam");
        tutor.setApellidoP("Lopz");
        tutor.setApellidoM("Sánchez");
        tutor.setCel("5547607426");
        tutor.setPaciente(paciente);
        tutor.setTel("68343534");
        tutor.setCorreo("happy@hotmail.com");
        
        proGestionPaciente.AgregarPaciente(usuario, psicologo, paciente, tutor);
        
        
        
    }
    
}
