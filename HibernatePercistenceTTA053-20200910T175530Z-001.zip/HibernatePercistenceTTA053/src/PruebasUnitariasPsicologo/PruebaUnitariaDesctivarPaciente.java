/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PruebasUnitariasPsicologo;

import Procesos.RN.Psicologo.ProcesoRNGestionPaciente;

/**
 *
 * @author stile
 */
public class PruebaUnitariaDesctivarPaciente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ProcesoRNGestionPaciente pG=new ProcesoRNGestionPaciente();
        pG.DesactivarPaciente("4ab55394-24bc-4049-b684-8056cc446d15");
        pG.ActivarPaciente("4ab55394-24bc-4049-b684-8056cc446d15");
    }
    
}
