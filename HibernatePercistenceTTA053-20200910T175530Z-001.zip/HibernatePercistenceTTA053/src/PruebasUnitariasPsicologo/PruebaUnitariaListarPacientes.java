/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PruebasUnitariasPsicologo;

import DAOSMOD1.CRUD_Paciente;
import Entidades.Paciente;
import InstanciarHibernate.HibernateUtil;
import java.util.List;

/**
 *
 * @author stile
 */
public class PruebaUnitariaListarPacientes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CRUD_Paciente crudPaciente=new CRUD_Paciente();
        crudPaciente.setSesion(HibernateUtil.getSessionFactory().openSession());
        crudPaciente.setTx(crudPaciente.getSesion().beginTransaction());
        List<Paciente> listPaciente=crudPaciente.ListaPacientesPorIdPsicologo("abd2ae44-d478-48fa-84f7-84abc69f5299");
        crudPaciente.getSesion().close();
        HibernateUtil.shutdown();
    }
    
}
