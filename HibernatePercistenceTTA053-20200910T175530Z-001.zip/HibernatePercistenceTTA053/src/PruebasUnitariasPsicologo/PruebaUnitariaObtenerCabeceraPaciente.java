/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PruebasUnitariasPsicologo;

import Cabeceras.CabeceraUsuario;
import Entidades.Paciente;
import Procesos.RN.Psicologo.ProcesoRNGestionPaciente;
import java.util.List;

/**
 *
 * @author stile
 */
public class PruebaUnitariaObtenerCabeceraPaciente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ProcesoRNGestionPaciente pRN=new ProcesoRNGestionPaciente();
        CabeceraUsuario cU=pRN.ObtenerCabeceraPaciente("2f170acb-63f0-4fee-8675-2af5fbc74f93");
        List<CabeceraUsuario<Paciente>> listCU=pRN.ObtenerListaCabecerasPaciente("abd2ae44-d478-48fa-84f7-84abc69f5299");
        
    if(cU!=null&&listCU!=null)
    {
        
    }
        
    }
    
}
